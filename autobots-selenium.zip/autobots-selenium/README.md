# Summary #

* AutoBots Selenium is an automation framework for web applications automation, API test automation, JSON schema validation and accessibility testing. 
* Framework supports Behavior-Driven Development and Page Object Model.
* Framework provides rich features like test logger, test recording, parallel test execution, and test reporting. 
* Framework supports log defect into JIRA for failed cases, update test case status in TestRail, an option to re-run the failed cases in the same session. 
* Framework supports the script execution on the LambdaTest digital platform. Publish the results in live dashboards and AI-powered test automation dashboard.
* Supports the LambdaTest HyperExecute to optimize the execution of automated tests in the cloud.
* Test data extractor, dynamic script execution based on the configuration and update test results back to the the Excel report.
* Test Executor interface allows to configure test execution environments, select test cases, save or edit configurations, and execute tests with options for parallel execution and retries. Also, provides an UI to view the latest reports. 
* Page Object Scanner to scan the web page of the application to analyze missing locators and generate report.
* Framework supports Allure report generation.
* Automation Execution Time Trends Report is available to see the execution time history and the individual test case execution time history.

* Version: 2.2.8
* Author(s): Sanoj Swaminathan, Aiswarya Thandassery, Sruthy Viju, Tom Saju.