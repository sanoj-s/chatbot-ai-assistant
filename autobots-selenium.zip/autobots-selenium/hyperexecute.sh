#!/bin/bash
cd "$(dirname "$0")"
./hyperexecute --config hyperexecutesequential.yaml --user sanoj.swaminathan --key Kc7tZLfuVmz65AdK0j960CYlusuyaJ8SaKm4tCPdWcVk7dUDDH