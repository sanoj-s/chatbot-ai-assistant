package com.autobots.testhelpers;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.autobots.exception.AutomationException;
import com.autobots.keywords.UIActions;
import com.autobots.keywords.Validations;
import com.autobots.testobjects.SampleTestObjects;
import com.autobots.utils.Log;

public class SampleTestHelper {

	UIActions uiActions = new UIActions();
	Validations validation = new Validations();

	/**
	 * To search data
	 * 
	 * @author sanojs
	 * @since 09-03-2023
	 * @param driver
	 * @param searchKey
	 */
	public void searchData(WebDriver driver, String searchKey) {
		try {
			uiActions.type(driver, SampleTestObjects.txt_search, searchKey);
			uiActions.click(driver, SampleTestObjects.txt_search, Keys.ENTER);
			validation.verifyElementVisible(driver, SampleTestObjects.lnk_aspireSystems, "Search failed");
			validation.verifyEquals("Login field", "Login field", "Login field is not displayed");
			Log.message("Search successful");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to access the JMeter
	 * 
	 * @author sanoj.swaminathan
	 * @since 09-05-2023
	 * @param driver
	 * @throws AutomationException
	 */
	public void accessJMeter(WebDriver driver) throws AutomationException {
		try {
			uiActions.click(driver, SampleTestObjects.lnk_jmeter);
		} catch (Exception e) {
			throw new AutomationException(e);
		}
	}
}
