package com.autobots.stepdefinitions;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.v129.network.Network;
import org.openqa.selenium.devtools.v129.network.model.Response;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Reporter;

import com.autobots.base.AutomationBase;
import com.autobots.exception.AutomationException;
import com.autobots.keywords.DataHandler;
import com.autobots.keywords.Utilities;
import com.autobots.keywords.WebActions;
import com.autobots.utils.AutomationConstants;

import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class Hook {
	protected static WebDriver driver;
	FileWriter fileWriter;
	String needNetworkLogs;

	@Before
	public void setUp(Scenario scenario) throws AutomationException, InterruptedException, IOException {
		String browserName = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest()
				.getParameter("browserName");
		String browserVersion = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest()
				.getParameter("browserVersion");
		String gridIP = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("gridIP");
		String gridPort = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest().getParameter("gridPort");
		String platformName = Reporter.getCurrentTestResult().getTestContext().getCurrentXmlTest()
				.getParameter("platformName");
		if (browserName != null) {
			driver = new AutomationBase().startSession(platformName, browserName, browserVersion, gridIP, gridPort);
			setDriver(driver);

			// Track the network logs
			needNetworkLogs = new DataHandler().getProperty(AutomationConstants.FRAMEWORK_CONFIG,
					AutomationConstants.NEED_NETWORK_LOGS);
			if (needNetworkLogs.equals("")) {
				needNetworkLogs = "No";
			}
			if (needNetworkLogs.equalsIgnoreCase("yes")) {
				trackNetworkLogs(driver, scenario.getName());
			}
		}
	}

	/**
	 * Method to track the network logs and generate log files in the project
	 * structure under //Logs//Network_logs folder
	 * 
	 * @author sanoj.swaminathan
	 * @since 27-06-2023
	 * @param result
	 * @param testName
	 */
	private void trackNetworkLogs(WebDriver driver, String scenarioName) {
		try {
			DevTools devTools = null;
			if (driver instanceof EdgeDriver) {
				devTools = ((EdgeDriver) driver).getDevTools();
			} else if (driver instanceof ChromeDriver) {
				devTools = ((ChromeDriver) driver).getDevTools();
			} else {
				System.out.println("Network logs supported for Edge and Chrome browsers");
			}
			if (devTools != null) {
				devTools.createSession();
				devTools.send(Network.enable(Optional.empty(), Optional.empty(), Optional.empty()));

				if (!new File(System.getProperty("user.dir") + "//Logs//Network_logs").exists()) {
					(new File(System.getProperty("user.dir") + "//Logs")).mkdir();
					(new File(System.getProperty("user.dir") + "//Logs//Network_logs")).mkdir();
				}
				fileWriter = new FileWriter(new File(System.getProperty("user.dir") + "\\Logs\\Network_logs\\"
						+ scenarioName + "_" + getCurrentDateAndTime() + ".txt"));

				devTools.addListener(Network.responseReceived(), responseReceived -> {
					Response response = responseReceived.getResponse();
					String log = "Network Log: " + response.getUrl() + "\n";

					try {
						fileWriter.write(log);
					} catch (IOException e) {
						e.printStackTrace();
					}
					try {
						fileWriter.flush();
					} catch (IOException e) {
						e.printStackTrace();
					}
				});
				System.out.println("********************************************");
				System.out.println(
						"Network logs for " + scenarioName + " is avaialble at " + System.getProperty("user.dir")
								+ "\\Logs\\Network_logs\\" + scenarioName + "_" + getCurrentDateAndTime() + ".txt");
				System.out.println("********************************************");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to get the current date and time
	 * 
	 * @author sanoj.swaminathan
	 * @since 27-06-2023
	 * @return
	 */
	private static String getCurrentDateAndTime() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		DateFormat timeFormat = new SimpleDateFormat("HH-mm-ss");
		Date date = new Date();
		String currdate = dateFormat.format(date);
		String currtime = timeFormat.format(date);
		return currdate + "_" + currtime;
	}

	@After()
	public void tearDownAfterScenario(Scenario scenario) throws AutomationException {
		if (driver != null) {
			if (scenario.isFailed()) {
				try {
					scenario.attach(new Utilities().captureScreenAsByteArray(driver), "image/png",
							"click below thumbnail to see the screenshot in full screen");
				} catch (FileNotFoundException | AutomationException e) {
					e.printStackTrace();
				}
			}

			// Close the network logs
			try {
				if (needNetworkLogs.equalsIgnoreCase("yes") && fileWriter != null) {
					fileWriter.close();
				}
			} catch (IOException e) {
			}

			new WebActions().closeBrowser(driver);
		}
	}

	@AfterStep
	public void tearDownAfterStep(Scenario scenario) {
		try {
			String needVisualStepsInReport = new DataHandler().getProperty(AutomationConstants.FRAMEWORK_CONFIG,
					"needVisualStepsInReport");
			if (needVisualStepsInReport.toLowerCase().equals("yes") && driver != null) {
				scenario.attach(new Utilities().captureScreenAsByteArray(driver), "image/png", "");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to get the driver instance
	 * 
	 * @author sanoj.swaminathan
	 * @since 04-05-2023
	 * @return
	 */
	public static WebDriver getDriver() {
		return driver;
	}

	/***
	 * Method to set the driver instance
	 * 
	 * @author sanoj.swaminathan
	 * @since 04-05-2023
	 * @param driver
	 */
	public void setDriver(WebDriver driver) {
		Hook.driver = driver;
	}
}
