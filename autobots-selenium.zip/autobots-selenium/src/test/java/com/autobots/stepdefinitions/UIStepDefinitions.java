package com.autobots.stepdefinitions;

import org.openqa.selenium.WebDriver;

import com.autobots.exception.AutomationException;
import com.autobots.keywords.Validations;
import com.autobots.keywords.WebActions;
import com.autobots.testhelpers.SampleTestHelper;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class UIStepDefinitions {

	public WebDriver driver;

	public UIStepDefinitions() {
		this.driver = Hook.getDriver();
	}

	@Given("Go to {string}")
	public void go_to(String uri) throws AutomationException {
		new WebActions().loadWebApplication(driver, uri);
	}

	@When("Click on {string} link")
	public void click_on_link(String JMeter) throws AutomationException {
		new SampleTestHelper().accessJMeter(driver);
	}

	@Then("Able to see {string} page")
	public void able_to_see_page(String expectedPage) throws AutomationException {
		String actualPage = new WebActions().getWebUrl(driver);
		new Validations().verifyEquals(actualPage, expectedPage, "Page not displayed as expected");
	}
}
