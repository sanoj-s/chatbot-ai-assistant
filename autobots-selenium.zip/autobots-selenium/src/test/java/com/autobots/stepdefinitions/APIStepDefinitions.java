package com.autobots.stepdefinitions;

import com.autobots.exception.AutomationException;
import com.autobots.keywords.APIActions;
import com.autobots.keywords.APIUtilities;
import com.autobots.keywords.APIValidations;
import com.autobots.keywords.Validations;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;

public class APIStepDefinitions {

	Response resp;

	public APIStepDefinitions() {
	}

	@Given("I send a request to the URL to get user details")
	public void i_send_a_request_to_the_url_to_get_user_details() throws AutomationException {
		String baseURI = "http://dummy.restapiexample.com";
		String endPoint = "/api/v1/employee/1";
		resp = new APIActions().getRequest(baseURI, endPoint);
		System.out.println("Response :" + resp.asPrettyString());
	}

	@Then("the response will return status {int} and id {int} and salary {int} and name {string} and age {int} and message {string}")
	public void verifyStatus(int statusCode, int id, int emp_Salary, String emp_name, int emp_age, String message)
			throws AutomationException {
		new APIValidations().validateStatusCode(resp, statusCode);
		String salary = new APIUtilities().getValueFromResponse(resp, "data.employee_salary");
		new Validations().verifyEquals(salary, String.valueOf(emp_Salary), "Salary not matches");

		String name = new APIUtilities().getValueFromResponse(resp, "data.employee_name");
		new Validations().verifyEquals(name, String.valueOf(emp_name), "Name not matches");

		String age = new APIUtilities().getValueFromResponse(resp, "data.employee_age");
		new Validations().verifyEquals(age, String.valueOf(emp_age), "Age not matches");

		String actual_message = new APIUtilities().getValueFromResponse(resp, "message");
		new Validations().verifyEquals(actual_message, String.valueOf(message), "Message not matches");
	}
}
