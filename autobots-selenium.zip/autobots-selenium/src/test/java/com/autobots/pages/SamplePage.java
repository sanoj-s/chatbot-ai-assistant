package com.autobots.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.autobots.exception.AutomationException;
import com.autobots.keywords.UIActions;
import com.autobots.keywords.Validations;
import com.autobots.pageobjectscanner.PageObjectScannerCore;

public class SamplePage {

	private WebDriver driver;
	UIActions ui_actions = new UIActions();
	Validations validation = new Validations();

	public SamplePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		try {
			new PageObjectScannerCore().findMissingObjects(driver, this.getClass());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@FindBy(xpath = "//input[@id='user-name']")
	private WebElement txt_usernameField;

	@FindBy(xpath = "//input[@id='password']")
	private WebElement txt_passwordField;

	@FindBy(xpath = "//input[@id='login-button']")
	private WebElement btn_loginButton;

	/**
	 * Method to login
	 * 
	 * @author sanoj.swaminathan
	 * @since 12-08-2024
	 * @param message
	 * @throws AutomationException
	 */
	public void loginToApplication(String username, String password) throws AutomationException {
		ui_actions.type(driver, txt_usernameField, username);
		ui_actions.type(driver, txt_passwordField, password);
		ui_actions.click(driver, btn_loginButton);
	}
}
