package com.autobots.solutions;

import com.autobots.pageobjectscanner.PageObjectScannerUI;

public class PageObjectScanner {
	public static void main(String[] args) {
		PageObjectScannerUI.findMissingObjectsUI();
	}
}
