package com.autobots.solutions;

import com.autobots.inspect.WebInspectUI;

public class AutoBotsWebInspector {
	public static void main(String[] args) {
		WebInspectUI.scanObjectLocators();
	}
}
