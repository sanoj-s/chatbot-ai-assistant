package com.autobots.solutions;

import com.autobots.jsonpathgenerator.JSONXMLPathGeneratorUI;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

public class GenerateJSONXMLPathObjects {
	public static void main(String[] args) throws JsonMappingException, JsonProcessingException {
		JSONXMLPathGeneratorUI.generateJSONXMLPathObjects();
	}
}
