package com.autobots.solutions;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class VisualValidator extends JFrame {

    private JTextField urlField;
    private JButton startButton, validateButton;
    private JLabel baselineImageLabel, obtainedImageLabel, resultImageLabel;
    private JLabel baselineLabel, obtainedLabel, resultLabel, resultMessageLabel;

    private WebDriver driver;
    private BufferedImage baselineImage, obtainedImage, resultImage;

    public VisualValidator() {
        setTitle("Visual Validator");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridBagLayout()); // Using GridBagLayout for flexible alignment

        // Initialize components
        urlField = new JTextField(30);
        startButton = new JButton("Start");
        validateButton = new JButton("Validate");

        baselineImageLabel = new JLabel();
        obtainedImageLabel = new JLabel();
        resultImageLabel = new JLabel();

        baselineLabel = new JLabel("Baseline Image");
        obtainedLabel = new JLabel("Obtained Image");
        resultLabel = new JLabel("Result Image");
        resultMessageLabel = new JLabel(""); // Label to show result messages

        // Initially hide the labels until "Validate" button is clicked
        baselineLabel.setVisible(false);
        obtainedLabel.setVisible(false);
        resultLabel.setVisible(false);

        // GridBagConstraints for layout control
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;

        // Row 0: URL field, start button, validate button with padding
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(10, 10, 10, 10); // Adds padding around components
        add(new JLabel("Enter Web URL:"), gbc);

        gbc.gridx = 1;
        gbc.gridwidth = 3;
        add(urlField, gbc);

        gbc.gridx = 4;
        gbc.gridwidth = 1;
        add(startButton, gbc);

        gbc.gridx = 5;
        add(validateButton, gbc);

        // Row 1: Adding images in a single row with spacing
        gbc.gridy = 1;
        gbc.gridx = 0;
        gbc.insets = new Insets(10, 10, 10, 10); // Add spacing between images
        add(baselineImageLabel, gbc);

        gbc.gridx = 2;
        add(obtainedImageLabel, gbc);

        gbc.gridx = 4;
        add(resultImageLabel, gbc);

        // Row 2: Adding labels for each image below the images with padding
        gbc.gridy = 2;
        gbc.gridx = 0;
        add(baselineLabel, gbc);

        gbc.gridx = 2;
        add(obtainedLabel, gbc);

        gbc.gridx = 4;
        add(resultLabel, gbc);

        // Row 3: Result message at the bottom
        gbc.gridy = 3;
        gbc.gridx = 0;
        gbc.gridwidth = 6;
        resultMessageLabel.setHorizontalAlignment(JLabel.CENTER); // Center the result message
        add(resultMessageLabel, gbc);

        // Action Listeners
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startBrowser();
            }
        });

        validateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    captureAndCompare();
                    // Display labels after validation
                    baselineLabel.setVisible(true);
                    obtainedLabel.setVisible(true);
                    resultLabel.setVisible(true);
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
            }
        });

        // Add Mouse Listeners for Zoom functionality
        baselineImageLabel.addMouseListener(new ImageZoomListener(baselineImage));
        obtainedImageLabel.addMouseListener(new ImageZoomListener(obtainedImage));
        resultImageLabel.addMouseListener(new ImageZoomListener(resultImage));

        setVisible(true);
    }

    // Start the browser with the URL
    private void startBrowser() {
        String url = urlField.getText();
        if (!url.isEmpty()) {
            driver = new ChromeDriver();
            driver.get(url);
        } else {
            JOptionPane.showMessageDialog(this, "Please enter a valid URL.");
        }
    }

    // Capture and Compare Images
    private void captureAndCompare() throws IOException {
        // Capture screenshot as obtained image
        File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        obtainedImage = ImageIO.read(screenshot);

        // Load baseline image for comparison (you can modify this path)
        File baselineFile = new File("baseline_image.png");
        if (!baselineFile.exists()) {
            // If baseline image doesn't exist, save current as baseline
            FileUtils.copyFile(screenshot, baselineFile);
            baselineImage = obtainedImage;
        } else {
            baselineImage = ImageIO.read(baselineFile);
        }

        // Display images on the UI
        displayImages();

        // Compare images and display result
        compareImages();
    }

    // Display baseline and obtained images on UI
    private void displayImages() throws IOException {
        baselineImageLabel.setIcon(new ImageIcon(baselineImage.getScaledInstance(200, 200, Image.SCALE_SMOOTH)));
        obtainedImageLabel.setIcon(new ImageIcon(obtainedImage.getScaledInstance(200, 200, Image.SCALE_SMOOTH)));
    }

    // Compare the two images pixel by pixel
    private void compareImages() {
        int width1 = baselineImage.getWidth();
        int height1 = baselineImage.getHeight();
        int width2 = obtainedImage.getWidth();
        int height2 = obtainedImage.getHeight();

        // Ensure images are the same size for comparison
        if (width1 == width2 && height1 == height2) {
            resultImage = new BufferedImage(width1, height1, BufferedImage.TYPE_INT_RGB);
            boolean imagesMatch = true;

            for (int y = 0; y < height1; y++) {
                for (int x = 0; x < width1; x++) {
                    int pixel1 = baselineImage.getRGB(x, y);
                    int pixel2 = obtainedImage.getRGB(x, y);

                    if (pixel1 != pixel2) {
                        // Mark different pixels in red in result image
                        resultImage.setRGB(x, y, Color.RED.getRGB());
                        imagesMatch = false;
                    } else {
                        resultImage.setRGB(x, y, pixel1);
                    }
                }
            }

            // Display the result image
            resultImageLabel.setIcon(new ImageIcon(resultImage.getScaledInstance(200, 200, Image.SCALE_SMOOTH)));

            // Update result message label
            if (imagesMatch) {
                resultMessageLabel.setText("Images match perfectly!");
                resultMessageLabel.setForeground(Color.GREEN); // Set text color to green
            } else {
                resultMessageLabel.setText("Images do not match. Check the result image for differences.");
                resultMessageLabel.setForeground(Color.RED); // Set text color to red
            }
        } else {
            resultMessageLabel.setText("Images are of different sizes. Comparison cannot be performed.");
            resultMessageLabel.setForeground(Color.RED); // Set text color to red
        }
    }

    // Inner class to handle image zoom functionality
    class ImageZoomListener extends MouseAdapter {
        private BufferedImage image;

        public ImageZoomListener(BufferedImage image) {
            this.image = image;
        }

        @Override
        public void mouseClicked(MouseEvent e) {
            if (image != null) {
                // Open a new frame to show zoomed image
                JFrame zoomFrame = new JFrame("Zoomed Image");
                zoomFrame.setSize(600, 600);
                JLabel zoomLabel = new JLabel(new ImageIcon(image.getScaledInstance(600, 600, Image.SCALE_SMOOTH)));
                zoomFrame.add(zoomLabel);
                zoomFrame.setVisible(true);
            }
        }
    }

    public static void main(String[] args) {
        new VisualValidator();
    }
}

