package com.autobots.solutions;

import com.autobots.stepdefgenerator.StepDefinitionGeneratorUI;

import io.cucumber.core.internal.com.fasterxml.jackson.core.JsonProcessingException;
import io.cucumber.core.internal.com.fasterxml.jackson.databind.JsonMappingException;

public class GenerateStepDefinitions {
	public static void main(String[] args) throws JsonMappingException, JsonProcessingException {
		StepDefinitionGeneratorUI.generateFeatureFiles();
	}
}
