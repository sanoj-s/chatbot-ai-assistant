package com.autobots.solutions;

import com.autobots.testexecutor.TestSuiteExecutorUI;
import com.autobots.testexecutor.TestSuiteExtractorCore;

public class GenerateTestExecutor {

	public static void main(String[] args) {
		// create test suite executor data map
		TestSuiteExtractorCore.testExecutorDataCreator();

		// select the required test cases and execute the script
		TestSuiteExecutorUI.getTestSuiteExecutor();
	}
}