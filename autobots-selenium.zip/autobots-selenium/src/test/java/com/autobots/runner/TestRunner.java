package com.autobots.runner;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;

import com.autobots.base.AutomationBase;
import com.autobots.exception.AutomationException;
import com.autobots.keywords.WebActions;
import com.autobots.reporting.AutomationReport;
import com.autobots.reporting.AutomationReportPortal;

@Listeners({ AutomationReport.class, AutomationReportPortal.class })
public class TestRunner extends AutomationBase {

	@BeforeMethod
	@Parameters({ "platformName", "browserName", "browserVersion", "gridIP", "gridPort" })
	public void setup(String platformName, String browserName, String browserVersion, String gridIP, String gridPort)
			throws Exception {
		startSession(platformName, browserName, browserVersion, gridIP, gridPort);
	}

	@AfterMethod
	public void tearDownMethod() throws AutomationException, InterruptedException {
		WebActions webObj = new WebActions();
		if (getDriver() != null) {
			webObj.quitBrowser(getDriver());
		}
		// Remove the WebDriver instance from ThreadLocal
		removeDriver();
	}
}
