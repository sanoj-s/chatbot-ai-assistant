package com.autobots.testsuites;

import java.io.IOException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.autobots.exception.AutomationException;
import com.autobots.keywords.APIValidations;
import com.autobots.reporting.AutomationReport;
import com.autobots.reporting.AutomationReportPortal;

@Listeners({ AutomationReport.class, AutomationReportPortal.class })
public class SampleAPISchemaTests {
	String baseURI;

	@BeforeClass
	public void setup() {
		baseURI = "https://reqres.in";
	}

	@Test(enabled = true, description = "Validate GET Request Response Schema")
	public void TC001_testGetResponseSchema() throws AutomationException, IOException, InterruptedException {
		new AutomationReport().assignCategory("JSON Schema Validation");
		new APIValidations().validateGetResponseSchema(baseURI, "/api/users/2", "get_response_schema");
	}

	@Test(enabled = true, description = "Validate POST Request Response Schema")
	public void TC002_testPostResponseSchema() throws AutomationException, IOException, InterruptedException {
		new AutomationReport().assignCategory("JSON Schema Validation");
		new APIValidations().validatePostResponseSchema(baseURI, "/api/users", "updateJob_payload", "application/json",
				"post_response_schema");
	}

	@Test(enabled = true, description = "Validate PUT Request Response Schema")
	public void TC003_testPutResponseSchema() throws AutomationException, IOException, InterruptedException {
		new AutomationReport().assignCategory("JSON Schema Validation");
		new APIValidations().validatePutResponseSchema(baseURI, "/api/users/2", "updateJob_payload", "application/json",
				"put_response_schema");
	}

	@Test(enabled = true, description = "Validate PATCH Request Response Schema")
	public void TC004_testPatchResponseSchema() throws AutomationException, IOException, InterruptedException {
		new AutomationReport().assignCategory("JSON Schema Validation");
		new APIValidations().validatePatchResponseSchema(baseURI, "/api/users/2", "updateJob_payload",
				"application/json", "patch_response_schema");
	}

	@Test(enabled = true, description = "Validate GET Request JSON Schema Data")
	public void TC005_testGetResponseJSONSchemaData() throws AutomationException, IOException, InterruptedException {
		new AutomationReport().assignCategory("JSON Schema Validation");
		String JSONSchemaData = "{\r\n" + "  \"$schema\": \"http://json-schema.org/draft-04/schema#\",\r\n"
				+ "  \"type\": \"object\",\r\n" + "  \"properties\": {\r\n" + "    \"data\": {\r\n"
				+ "      \"type\": \"object\",\r\n" + "      \"properties\": {\r\n" + "        \"id\": {\r\n"
				+ "          \"type\": \"integer\"\r\n" + "        },\r\n" + "        \"email\": {\r\n"
				+ "          \"type\": \"string\"\r\n" + "        },\r\n" + "        \"first_name\": {\r\n"
				+ "          \"type\": \"string\"\r\n" + "        },\r\n" + "        \"last_name\": {\r\n"
				+ "          \"type\": \"string\"\r\n" + "        },\r\n" + "        \"avatar\": {\r\n"
				+ "          \"type\": \"string\"\r\n" + "        }\r\n" + "      },\r\n" + "      \"required\": [\r\n"
				+ "        \"id\",\r\n" + "        \"email\",\r\n" + "        \"first_name\",\r\n"
				+ "        \"last_name\",\r\n" + "        \"avatar\"\r\n" + "      ]\r\n" + "    },\r\n"
				+ "    \"support\": {\r\n" + "      \"type\": \"object\",\r\n" + "      \"properties\": {\r\n"
				+ "        \"url\": {\r\n" + "          \"type\": \"string\"\r\n" + "        },\r\n"
				+ "        \"text\": {\r\n" + "          \"type\": \"string\"\r\n" + "        }\r\n" + "      },\r\n"
				+ "      \"required\": [\r\n" + "        \"url\",\r\n" + "        \"text\"\r\n" + "      ]\r\n"
				+ "    }\r\n" + "  },\r\n" + "  \"required\": [\r\n" + "    \"data\",\r\n" + "    \"support\"\r\n"
				+ "  ]\r\n" + "}";
		new APIValidations().validateGetResponseJSONSchemaData(baseURI, "/api/users/2", JSONSchemaData);
	}
}
