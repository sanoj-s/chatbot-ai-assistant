package com.autobots.testsuites;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.autobots.exception.AutomationException;
import com.autobots.keywords.Utilities;
import com.autobots.keywords.Validations;
import com.autobots.keywords.WebActions;
import com.autobots.reporting.AutomationReport;
import com.autobots.runner.TestRunner;
import com.autobots.utils.Log;

public class SampleQRCodeTests extends TestRunner {

	@Test(enabled = true, description = "Sample test case for  QR code test")
	public void TC001_sampleTestCaseWeb() throws AutomationException, IOException, InterruptedException {
		new AutomationReport().assignCategory("Generic - Web");
		WebDriver driver = getDriver();
		new WebActions().loadWebApplication(driver, "https://qrcode.meetheed.com/qrcode_examples.php");
		Log.message(new Utilities().getQRCodeData(driver, "//img[@alt='QR Contact Example']"));
		new Validations().verifyQRCodeData(driver, "//img[@alt='QR Contact Example']",
				"MECARD:N:Joe;EMAIL:Joe@bloggs.com;;", "Data not matches");
	}
}
