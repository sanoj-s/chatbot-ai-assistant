package com.autobots.testsuites;

import java.awt.AWTException;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.autobots.exception.AutomationException;
import com.autobots.keywords.TestDataUtility;
import com.autobots.keywords.Utilities;
import com.autobots.keywords.WebActions;
import com.autobots.pages.SamplePage;
import com.autobots.reporting.AutomationReport;
import com.autobots.runner.TestRunner;
import com.autobots.testhelpers.SampleTestHelper;
import com.autobots.utils.Log;
import com.autobots.utils.TestCaseConfig;

import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;

public class SampleTests extends TestRunner {
	@Epic("Google")
	@Feature("Google Search")
	@Story("User search in google")
	@Severity(SeverityLevel.NORMAL)
	@Description("User is logged into google and user is searching for aspire system")
	@TestCaseConfig(testRailTestCaseID = 1)
	@Test(description = "Google Search", enabled = true)
	public void TC001_testSample()
			throws AutomationException, IOException, AWTException, InterruptedException, GeneralSecurityException {
		new Utilities().startRecording("Google");
		new AutomationReport().assignCategory("Generic");
		WebDriver driver = getDriver();
		new WebActions().loadWebApplication(driver, "https://www.google.com/");
		HashMap<String, String> testData = TestDataUtility.getTestData(new Utilities().getTestDataPath("testDataPath"),
				"SampleTests");
		String searchKey = testData.get("searchKey");
		System.out.println(searchKey);
		new SampleTestHelper().searchData(driver, searchKey);
		new Utilities().startAccessibilityAudit(driver, "searchPage");
		new Utilities().stopRecording();
	}

	@TestCaseConfig(testRailTestCaseID = 2)
	@Test(description = "Google Search New", enabled = true)
	public void TC002_testSample()
			throws AutomationException, IOException, AWTException, InterruptedException, GeneralSecurityException {
		new AutomationReport().assignCategory("Generic");
		HashMap<String, String> testData = TestDataUtility.getTestData(new Utilities().getTestDataPath("testDataPath"),
				"SampleTests");
		WebDriver driver = getDriver();
		new WebActions().loadWebApplication(driver, "https://www.google.com/");
		String searchKey = testData.get("searchKey");
		new WebActions().loadWebApplication(driver, "https://google.in/");
		String totalElements = Integer.toString(new Utilities().waitForAllElementsLoaded(driver, 20).size());
		Log.message("Total web elements loaded: " + totalElements);
		new SampleTestHelper().searchData(driver, searchKey);
		Assert.assertTrue(false, "Failed");
	}

	@Epic("User Authentication")
	@Feature("Login")
	@Story("User logs in with valid credentials")
	@Severity(SeverityLevel.TRIVIAL)
	@Description("User is successfully logged in to application after entering the valid cerdentials")
	@TestCaseConfig(testRailTestCaseID = 3)
	@Test(enabled = false, description = "Sample test case for Web Page Object Model")
	public void TC003_sampleTestCasePageObjectModel()
			throws AutomationException, IOException, GeneralSecurityException {
		int i = 1;
		new AutomationReport().assignCategory("Page Object Model - Web");
		HashMap<String, String> testData = TestDataUtility.getTestData(new Utilities().getTestDataPath("testDataPath"),
				"SampleTests");
		WebDriver driver = getDriver();
		new WebActions().loadWebApplication(driver, "https://www.saucedemo.com/");
		Log.message((i++) + ". Accessed the web application");
		SamplePage samplePage = new SamplePage(driver);
		samplePage.loginToApplication(testData.get("Username"), testData.get("Password"));
		Log.message(driver, (i++) + ". Login to the web application");
	}

	@Epic("Google")
	@Feature("Google Search")
	@Story("User search in google")
	@Severity(SeverityLevel.NORMAL)
	@Description("User is logged into google and user is searching for aspire system")
	@TestCaseConfig(testRailTestCaseID = 1)
	@Test(description = "Google Search", enabled = false)
	public void TC004_testSample()
			throws AutomationException, IOException, AWTException, InterruptedException, GeneralSecurityException {
		new Utilities().startRecording("Google");
		new AutomationReport().assignCategory("Generic");
		WebDriver driver = getDriver();
		new WebActions().loadWebApplication(driver, "https://www.google.com/");
		HashMap<String, String> testData = TestDataUtility.getTestData(new Utilities().getTestDataPath("testDataPath"),
				"SampleTests");
		String searchKey = testData.get("searchKey");
		System.out.println(searchKey);
		new SampleTestHelper().searchData(driver, searchKey);
		new Utilities().startAccessibilityAudit(driver, "searchPage");
		new Utilities().stopRecording();
	}

	@TestCaseConfig(testRailTestCaseID = 2)
	@Test(description = "Google Search New", enabled = false)
	public void TC005_testSample()
			throws AutomationException, IOException, AWTException, InterruptedException, GeneralSecurityException {
		new AutomationReport().assignCategory("Generic");
		HashMap<String, String> testData = TestDataUtility.getTestData(new Utilities().getTestDataPath("testDataPath"),
				"SampleTests");
		WebDriver driver = getDriver();
		new WebActions().loadWebApplication(driver, "https://www.google.com/");
		String searchKey = testData.get("searchKey");
		new WebActions().loadWebApplication(driver, "https://google.in/");
		String totalElements = Integer.toString(new Utilities().waitForAllElementsLoaded(driver, 20).size());
		Log.message("Total web elements loaded: " + totalElements);
		new SampleTestHelper().searchData(driver, searchKey);
		Assert.assertTrue(false, "Failed");
	}

	@Epic("User Authentication")
	@Feature("Login")
	@Story("User logs in with valid credentials")
	@Severity(SeverityLevel.TRIVIAL)
	@Description("User is successfully logged in to application after entering the valid cerdentials")
	@TestCaseConfig(testRailTestCaseID = 3)
	@Test(enabled = false, description = "Sample test case for Web Page Object Model")
	public void TC006_sampleTestCasePageObjectModel()
			throws AutomationException, IOException, GeneralSecurityException {
		int i = 1;
		new AutomationReport().assignCategory("Page Object Model - Web");
		HashMap<String, String> testData = TestDataUtility.getTestData(new Utilities().getTestDataPath("testDataPath"),
				"SampleTests");
		WebDriver driver = getDriver();
		new WebActions().loadWebApplication(driver, "https://www.saucedemo.com/");
		Log.message((i++) + ". Accessed the web application");
		SamplePage samplePage = new SamplePage(driver);
		samplePage.loginToApplication(testData.get("Username"), testData.get("Password"));
		Log.message(driver, (i++) + ". Login to the web application");
	}
}
