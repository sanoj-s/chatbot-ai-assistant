package com.autobots.testsuites;

import java.io.IOException;
import java.util.ArrayList;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.autobots.exception.AutomationException;
import com.autobots.keywords.APIActions;
import com.autobots.keywords.APIUtilities;
import com.autobots.keywords.APIValidations;
import com.autobots.keywords.Validations;
import com.autobots.reporting.AutomationReport;
import com.autobots.reporting.AutomationReportPortal;
import com.autobots.utils.Log;

import io.restassured.http.Header;
import io.restassured.response.Response;

@Listeners({ AutomationReport.class, AutomationReportPortal.class })
public class SampleAPITests {
	String baseURI;

	@BeforeClass
	public void setup() {
		baseURI = "https://reqres.in";
	}

	@Test(enabled = true, description = "Retrieve user")
	public void TC001_testGetAPIRequest() throws AutomationException {
		new AutomationReport().assignCategory("GET Request");

		Response resp = new APIActions().getRequest(baseURI, "/api/users/2");
		// Validate the response data against the expected JSON file data.
		new APIValidations().validateJsonResponseMatch(resp, "user_payload");

		new APIValidations().validateStatusCode(resp, 200);
		Log.message("Response code 200 is matched");
		String id = new APIUtilities().getValueFromResponse(resp, "data.id");
		String email = new APIUtilities().getValueFromResponse(resp, "data.email");
		String firstName = new APIUtilities().getValueFromResponse(resp, "data.first_name");
		String lastName = new APIUtilities().getValueFromResponse(resp, "data.last_name");
		String avatar = new APIUtilities().getValueFromResponse(resp, "data.avatar");
		String url = new APIUtilities().getValueFromResponse(resp, "support.url");
		String text = new APIUtilities().getValueFromResponse(resp, "support.text");

		// Validation after fetching data separately
		new Validations().verifyEquals(id, "2", "Id not matches");
		Log.message("Id " + id + " is matched");
		new Validations().verifyEquals(email, "janet.weaver@reqres.in", "Email not matches");
		Log.message("Email " + email + " is matched");
		new Validations().verifyEquals(firstName, "Janet", "First Name not matches");
		Log.message("First Name " + firstName + " is matched");
		new Validations().verifyEquals(lastName, "Weaver", "Last Name not matches");
		Log.message("Last Name " + lastName + " is matched");
		new Validations().verifyEquals(avatar, "https://reqres.in/img/faces/2-image.jpg", "Avatar not matches");
		Log.message("Avatar " + avatar + " is matched");
		new Validations().verifyEquals(url, "https://reqres.in/#support-heading", "URL not matches");
		Log.message("URL " + url + " is matched");
		new Validations().verifyEquals(text, "To keep ReqRes free, contributions towards server costs are appreciated!",
				"Text not matches");
		Log.message("Text " + text + " is matched");

		// In-line validations
		boolean isDataIDExists = new APIValidations().validateJsonPath(resp, "data.id");
		new Validations().verifyEquals(isDataIDExists, true, "data.id is not exists");
		new APIValidations().validateJsonPathToIntegerValue(resp, "data.id", 2);
		new APIValidations().validateInResponseBody(resp, "janet.weaver@reqres.in");
		new APIValidations().validateResponseData(resp, "data.first_name", "Janet");

		Log.message("User data retrieved successfully");

		// Negative testing
		Response response = new APIActions().getRequest(baseURI, "/api/users/23");
		new APIValidations().validateStatusCode(response, 404);
		Log.message("Response code 404 is matched and user not found");
		boolean isEmpty = new APIValidations().validateEmptyResponse(response);
		new Validations().verifyEquals(isEmpty, true, "Response body is not empty");
	}

	@Test(enabled = true, description = "Register user")
	public void TC002_testPostAPIRequest() throws AutomationException {
		new AutomationReport().assignCategory("POST Request");

		Response resp = new APIActions().postRequest(baseURI, "/api/register", "register_payload.json",
				"application/json");

		new APIValidations().validateStatusCode(resp, 200);
		Log.message("Response code 200 is matched");

		// Validation after registration
		String id = new APIUtilities().getValueFromResponse(resp, "id");
		String token = new APIUtilities().getValueFromResponse(resp, "token");
		new Validations().verifyEquals(id, "4", "Id not matches");
		Log.message("Id " + id + " is matched");
		new Validations().verifyEquals(token, "QpwL5tke4Pnpja7X4", "Token not matches");
		Log.message("Token " + token + " is matched");

		// In-line validations
		new APIValidations().validateJsonPathToIntegerValue(resp, "id", 4);
		new APIValidations().validateResponseData(resp, "token", "QpwL5tke4Pnpja7X4");

		Log.message("User registered successfully");
	}

	@Test(enabled = true, description = "Update job")
	public void TC003_testPutAPIRequest() throws AutomationException {
		new AutomationReport().assignCategory("PUT Request");

		Response resp = new APIActions().putRequest(baseURI, "/api/users/2", "updateJob_payload.json",
				"application/json");

		new APIValidations().validateStatusCode(resp, 200);
		Log.message("Response code 200 is matched");

		// Validation after job update
		String name = new APIUtilities().getValueFromResponse(resp, "name");
		String job = new APIUtilities().getValueFromResponse(resp, "job");
		new Validations().verifyEquals(name, "morpheus", "Name not matches");
		Log.message("Name " + name + " is matched");
		new Validations().verifyEquals(job, "zion resident", "Job not not updated");
		Log.message("Job " + job + " is not updated");

		// In-line validations
		new APIValidations().validateResponseData(resp, "name", "morpheus");
		new APIValidations().validateResponseData(resp, "job", "zion resident");

		Log.message("Job details updated successfully");
	}

	@Test(enabled = true, description = "Update job using Patch request")
	public void TC004_testPatchAPIRequest() throws AutomationException {
		new AutomationReport().assignCategory("PATCH Request");

		Response resp = new APIActions().patchRequest(baseURI, "/api/users/2", "updateJob_payload.json",
				"application/json");

		new APIValidations().validateStatusCode(resp, 200);
		Log.message("Response code 200 is matched");

		// Validation after job update
		String name = new APIUtilities().getValueFromResponse(resp, "name");
		String job = new APIUtilities().getValueFromResponse(resp, "job");
		new Validations().verifyEquals(name, "morpheus", "Name not matches");
		Log.message("Name " + name + " is matched");
		new Validations().verifyEquals(job, "zion resident", "Job not not updated");
		Log.message("Job " + job + " is not updated");

		// In-line validations
		new APIValidations().validateResponseData(resp, "name", "morpheus");
		new APIValidations().validateResponseData(resp, "job", "zion resident");

		Log.message("Job details updated successfully");
	}

	@Test(enabled = true, description = "Delete user")
	public void TC005_testDeleteAPIRequest() throws AutomationException {
		new AutomationReport().assignCategory("DELETE Request");

		Response resp = new APIActions().deleteRequest(baseURI, "/api/users/2");

		new APIValidations().validateStatusCode(resp, 204);
		Log.message("Response code 204 is matched and user deleted successfully");
	}

	@Test(enabled = true, description = "Delete user")
	public void TC006_testJSONDataUpdate() throws AutomationException, IOException {
		new AutomationReport().assignCategory("JSON Data Update");

		Response resp = new APIActions().getRequest(baseURI, "/api/users/2");

		new APIUtilities().updateJSONDataWithGivenFileName("simple_payload", null, "job", "Designer");
		new APIUtilities().updateJSONArrayDataWithGivenFileName("complex_payload", null, "topping", 1, "type", "Cool");
		ArrayList<String> data = new ArrayList<>();
		data.add("data");
		new APIUtilities().updateJSONDataInResponse(resp, data, "email", "sanojs.swaminathan@reqres.in");
		Log.message("JSON Data updated successfully");
	}

	@Test(enabled = true, description = "Automate SOAP API")
	public void TC007_testSOAPAPI() throws AutomationException {
		Header header = new Header("Content-Type", "text/xml; charset=utf-8");
		Response xmlResponse = new APIActions().postRequest("http://www.dneonline.com", "/calculator.asmx", header,
				"requestbody.xml");
		new APIValidations().validateResponseDataInSOAPXMLResponse(xmlResponse,
				"soap:Envelope.soap:Body.AddResponse.AddResult", "5");
	}
}
