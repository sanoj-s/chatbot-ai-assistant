package com.autobots.testsuites;

import org.json.JSONException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.autobots.exception.AutomationException;
import com.autobots.keywords.APIActions;
import com.autobots.reporting.AutomationReport;
import com.autobots.reporting.AutomationReportPortal;
import com.autobots.utils.Log;

import io.restassured.response.Response;

@Listeners({ AutomationReport.class, AutomationReportPortal.class })
public class GraphQLSample {
	String baseURI, endPoint, graphQLQuery;

	@BeforeClass
	public void setup() {
		baseURI = "https://www.predic8.de";
		endPoint = "/fruit-shop-graphql?";
		graphQLQuery = "query{\r\n" + "  products(id: \"7\") {\r\n" + "    name\r\n" + "    price\r\n"
				+ "    category {\r\n" + "      name\r\n" + "    }\r\n" + "    vendor {\r\n" + "      name\r\n"
				+ "      id\r\n" + "    }\r\n" + "  }\r\n" + "}";
	}

	@Test
	public void testGraphql() throws JSONException, AutomationException {
		Response resp = new APIActions().postRequestWithGraphQL(baseURI, endPoint, "sample_query", "application/json");
		Log.message("Response is " + resp.asPrettyString());
	}
}
