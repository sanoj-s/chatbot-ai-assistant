package com.autobots.testsuites;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import com.autobots.retrytests.RetryTestAnalyzer;

public class TestCaseSampleRetry {

	@Test(retryAnalyzer = RetryTestAnalyzer.class)
	public void testFail() {
		assertTrue(false, "Passed");
	}

	@Test(retryAnalyzer = RetryTestAnalyzer.class)
	public void testPass() {
		assertTrue(true, "Failed");
	}
}
