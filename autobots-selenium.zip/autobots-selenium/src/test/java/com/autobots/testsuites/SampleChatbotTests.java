package com.autobots.testsuites;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.autobots.keywords.UIActions;
import com.autobots.keywords.Utilities;
import com.autobots.keywords.Validations;
import com.autobots.keywords.WebActions;
import com.autobots.reporting.AutomationReport;
import com.autobots.runner.TestRunner;

public class SampleChatbotTests extends TestRunner {

	@Test
	public void TC001_testChatbot() throws Exception {
		new AutomationReport().assignCategory("Generic");
		WebDriver driver = getDriver();
		System.out.println(new Utilities().waitForAllElementsLoaded(driver, 20).size());

		new WebActions().loadWebApplication(driver, "https://www.dominos.co.in/");
		new UIActions().click(driver, "//div[@id='ymDivCircle']/img");
		new WebActions().switchToFrame(driver, 1);
		if (new Utilities().waitForElement(driver, "id>>ymMsgInput", 3)) {
			new UIActions().type(driver, "id>>ymMsgInput", "Stores near me");
			new UIActions().click(driver, "id>>sendIcon");
			new Utilities().delay(3);
			new UIActions().click(driver, "//strong[contains(text(),'Enter location')]");
		} else {
			new UIActions().click(driver, "//strong[contains(text(),'Stores near me')]");
			new UIActions().click(driver, "//strong[contains(text(),'Enter location')]");
		}
		new Utilities().delay(5);
		new UIActions().type(driver, "id>>ymMsgInput", "Kakkanad");
		new UIActions().click(driver, "id>>sendIcon");
		new Utilities().delay(3);
		int totalMessages = new Utilities().countOfElementsFromList(driver,
				"//div[@class='chat-message message-came from-them bot-message  new first']");
		String message = new Utilities().getElementText(driver,
				"(//div[@class='chat-message message-came from-them bot-message  new first'])[" + totalMessages + "]");
		new Validations().verifyEquals(message, "Please enter the area name in Kakkanad.", "Missing data");
	}
}
