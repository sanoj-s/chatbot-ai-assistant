package com.autobots.testobjects;

public class SampleTestObjects {
	public static final String txt_search = "//*[@id='APjFqb']";
	public static final String lnk_aspireSystems = "//h3[contains(text(),'Aspire Systems | IT Services & Consulting for Digi')]";
	public static final String lnk_jmeter = "//li//a[text()='JMeter']";
}
