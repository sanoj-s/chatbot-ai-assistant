package com.autobots.retrytests;

import java.io.IOException;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

import com.autobots.exception.AutomationException;
import com.autobots.keywords.DataHandler;
import com.autobots.utils.AutomationConstants;

public class RetryTestAnalyzer implements IRetryAnalyzer {
	private int retryCount = 0;

	@Override
	public boolean retry(ITestResult result) {
		String failureCountLimit = null;
		try {
			DataHandler dataHandler = new DataHandler();
			failureCountLimit = dataHandler.getPropertyFromFilePath(AutomationConstants.FRAMEWORK_CONFIG_FILE_PATH,
					AutomationConstants.RETRY_FAILURE_LIMIT);
		} catch (AutomationException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (retryCount < Integer.valueOf(failureCountLimit)) {
			retryCount++;
			return true;
		}
		return false;
	}
}
