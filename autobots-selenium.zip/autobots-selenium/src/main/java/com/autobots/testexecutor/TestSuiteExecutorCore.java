package com.autobots.testexecutor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.TestNG;
import org.testng.xml.XmlSuite;

import com.autobots.keywords.DataHandler;
import com.autobots.reporting.AutomationReport;
import com.autobots.retrytests.RetryTests;

/**
 * This class helps to generate the testng xml and update test results back to
 * the excel sheet
 */
public class TestSuiteExecutorCore {

	static String testSuiteExtractorPath = "./src/test/resources/TestSuiteExtractor.xlsx";
	static String testRunnersPath = "/test-runners";

	/**
	 * Method to generate the testng suite file for execution under test-runners
	 * folder in the project structure.
	 * 
	 * @author sanoj.swaminathan
	 * @since 10-05-2024
	 * @return
	 */

	public static String testSuiteGenerator(String excelFilePath, String testngFileName, String platformName,
			String browserName, String browserVersion, String parallelMode, String threadCount) {
		String testNGSuiteName = null;
		try {
			String userDir = System.getProperty("user.dir");
			String folderPath = userDir + testRunnersPath;
			String xmlFilePath = folderPath + "/" + testngFileName + ".xml";
			testNGSuiteName = xmlFilePath;
			String testExecutorExcelFilePath = System.getProperty("user.dir") + excelFilePath.trim();
			Workbook workbook = new XSSFWorkbook(testExecutorExcelFilePath);

			// Initialize XML content
			StringBuilder xmlContent = new StringBuilder();
			String gridIp = "";
			String gridPort = "";
			xmlContent.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
			xmlContent.append("<!DOCTYPE suite SYSTEM \"http://testng.org/testng-1.0.dtd\">\n");
			xmlContent.append("<suite name=\"Test_Suite\" preserve-order=\"true\" verbose=\"5\" parallel=\""
					+ parallelMode + "\" thread-count=\"" + threadCount + "\">\n");
			xmlContent.append("\t<parameter name=\"platformName\" value=\"" + platformName + "\" />\n");
			xmlContent.append("\t<parameter name=\"browserName\" value=\"" + browserName + "\" />\n");
			xmlContent.append("\t<parameter name=\"browserVersion\" value=\"" + browserVersion + "\" />\n");
			xmlContent.append("\t<parameter name=\"gridIP\" value=\"" + gridIp + "\" />\n");
			xmlContent.append("\t<parameter name=\"gridPort\" value=\"" + gridPort + "\" />\n");

			xmlContent.append("\t<listeners>\n");
			List<Class<?>> classes = new ArrayList<>();
			classes.add(AutomationReport.class);
			classes.add(RetryTests.class);
			String reportSuiteName = null;
			for (Class<?> clazz : classes) {
				reportSuiteName = clazz.getPackage().getName() + "." + clazz.getSimpleName();
				xmlContent.append("\t\t<listener class-name=\"" + reportSuiteName + "\" />\n");
			}
			xmlContent.append("\t</listeners>\n");
			xmlContent.append("\n\t<test verbose=\"2\" name=\"TestScripts\">\n");

			Map<String, Set<String>> suiteMethodsMap = new HashMap<>();
			Map<String, Set<String>> suiteClassesMap = new HashMap<>();

			// Iterate over all sheets in the workbook
			for (int sheetIndex = 0; sheetIndex < workbook.getNumberOfSheets(); sheetIndex++) {
				Sheet sheet = workbook.getSheetAt(sheetIndex);
				for (int i = 1; i < getNonEmptyRowCount(sheet); i++) {
					Row row = sheet.getRow(i);

					String suiteName = getCellStringValue(row, 0); // Test Suite Name
					String testMethods = getCellStringValue(row, 1); // Test Methods
					String testGroups = getCellStringValue(row, 2); // Test Groups
					String needToExecute = getCellStringValue(row, 3); // Need to Execute

					if (needToExecute.equalsIgnoreCase("")) {
						needToExecute = "Yes";
					}
					if (needToExecute.equalsIgnoreCase("Yes")) {
						suiteMethodsMap.putIfAbsent(suiteName, new HashSet<>());
						suiteMethodsMap.get(suiteName).addAll(Set.of(testMethods.split(",")));
						suiteClassesMap.putIfAbsent(suiteName, new HashSet<>());
						suiteClassesMap.get(suiteName);
					}
				}
			}

			// Generate XML based on collected data
			xmlContent.append("\t<classes>\n");
			for (String suite : suiteMethodsMap.keySet()) {
				xmlContent.append("\t\t<class name=\"" + suite + "\">\n");
				xmlContent.append("\t\t\t<methods>\n");
				for (String method : suiteMethodsMap.get(suite)) {
					xmlContent.append("\t\t\t\t<include name=\"" + method.trim() + "\" />\n");
				}
				xmlContent.append("\t\t\t</methods>\n");
				xmlContent.append("\t\t</class>\n");
			}
			xmlContent.append("\t</classes>\n");
			xmlContent.append("\t</test>\n");
			xmlContent.append("</suite>");

			// Write XML testng XML file
			try (FileOutputStream fos = new FileOutputStream(testNGSuiteName)) {
				fos.write(xmlContent.toString().getBytes());
				System.out.println(testNGSuiteName + " generated successfully!");
			} catch (IOException e) {
				e.printStackTrace();
			}
			workbook.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return testNGSuiteName;
	}

	/**
	 * Method to update the Test Results in the Excel file
	 * 
	 * @author sanoj.swaminathan
	 * @since 26-06-2024
	 * @param testCase
	 * @param status
	 */
	@SuppressWarnings("unused") // Currently unused but planned for future use
	public static void updateTestResultsToExcel(String testCase, String status) {
		boolean testCaseFound = false;

		try {
			FileInputStream fileInputStream = new FileInputStream(
					System.getProperty("user.dir") + testSuiteExtractorPath);
			Workbook workbook = WorkbookFactory.create(fileInputStream);

			// Iterate over all sheets in the workbook
			for (int sheetIndex = 0; sheetIndex < workbook.getNumberOfSheets(); sheetIndex++) {
				Sheet sheet = workbook.getSheetAt(sheetIndex);

				// Iterate over rows to find the TestID and update the Status
				for (Row row : sheet) {
					CellStyle style = workbook.createCellStyle();
					Font font = workbook.createFont();
					font.setBold(true);
					Cell testIDCell = row.getCell(1);
					Cell needToExecute = row.getCell(3);

					// Skip the header row
					if (testIDCell != null && testIDCell.getStringCellValue().trim().equals("TestID")) {
						continue;
					}

					if (testIDCell != null && needToExecute != null
							&& needToExecute.getStringCellValue().trim().equals("Yes")) {
						String testID = testIDCell.getStringCellValue().trim();
						Cell statusCell = null;
						if (testID.equals(testCase.trim())) {
							testCaseFound = true;
							statusCell = row.createCell(4);
							if (status.equalsIgnoreCase("PASSED")) {
								font.setColor(HSSFColorPredefined.GREEN.getIndex());
							} else if (status.equalsIgnoreCase("FAILED")) {
								font.setColor(HSSFColorPredefined.RED.getIndex());
							} else if (status.equalsIgnoreCase("SKIPPED")) {
								font.setColor(HSSFColorPredefined.BROWN.getIndex());
							}
							style.setFont(font);
							statusCell.setCellStyle(style);
							statusCell.setCellValue(status);
							break;
						}
					}
				}
			}

			// Check if testCaseFound is false after iterating through all sheets
			if (!testCaseFound) {
				System.out.println("Test case '" + testCase + "' not found in the Excel file.");
			}

			// Write the updated data to the Excel file
			FileOutputStream fileOutputStream = new FileOutputStream(
					System.getProperty("user.dir") + testSuiteExtractorPath);
			workbook.write(fileOutputStream);

			// Close streams
			fileOutputStream.close();
			fileInputStream.close();
			workbook.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to get the non empty row count
	 * 
	 * @author sanoj.swaminathan
	 * @since 10-05-2024
	 * @param sheet
	 * @return
	 */
	private static int getNonEmptyRowCount(Sheet sheet) {
		int rowCount = 0;

		for (Row row : sheet) {
			if (row != null && !isRowEmpty(row)) {
				rowCount++;
			}
		}
		return rowCount;
	}

	/**
	 * Method to check if the row is empty
	 * 
	 * @author sanoj.swaminathan
	 * @since 10-05-2024
	 * @param row
	 * @return
	 */
	private static boolean isRowEmpty(Row row) {
		for (Cell cell : row) {
			if (cell != null) {
				if (cell.getCellType() == CellType.STRING && !cell.getStringCellValue().trim().isEmpty()) {
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * Method to get the cell value as String
	 * 
	 * @author sanoj.swaminathan
	 * @since 17-05-2024
	 * @param row
	 * @param cellIndex
	 * @return
	 */
	private static String getCellStringValue(Row row, int cellIndex) {
		Cell cell = row.getCell(cellIndex);
		if (cell != null) {
			return cell.getStringCellValue().trim();
		}
		return null;
	}

	/**
	 * Method to execute the testng suite XML file
	 * 
	 * @author sanoj.swaminathan
	 * @since 10-05-2024
	 * @param suiteXmlPath
	 */
	public static void executeTestNGSuite(String suiteXmlPath) {
		TestNG testNG = new TestNG();
		List<XmlSuite> suites = new ArrayList<>();
		XmlSuite suite = new XmlSuite();
		suite.setSuiteFiles(Collections.singletonList(new File(suiteXmlPath).getAbsolutePath()));
		suites.add(suite);
		testNG.setXmlSuites(suites);
		testNG.run();
	}

	/***
	 * Method to get the property value
	 * 
	 * @author sanoj.swaminathan
	 * @since 28-06-2024
	 * @param fileName
	 * @param propertyName
	 * @return
	 */
	static String getProperty(String fileName, String propertyName) {
		String propValue = "";
		try {
			Properties props = new Properties();
			ClassLoader classLoader = DataHandler.class.getClassLoader();
			InputStream input = classLoader.getResourceAsStream(fileName + ".properties");
			props.load(input);
			propValue = props.getProperty(propertyName);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return propValue;
	}
}
