package com.autobots.testexecutor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Set;

import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.reflections.Reflections;
import org.reflections.scanners.SubTypesScanner;
import org.reflections.scanners.TypeAnnotationsScanner;
import org.testng.annotations.Test;

public class TestSuiteExtractorCore {

	private static final String FILE_PATH = "./src/test/resources/TestSuiteExtractor.xlsx";

	/**
	 * Method to create the test suite executor data map
	 * 
	 * @author sanoj.swaminathan
	 * @since 05-09-2024
	 */
	public static void testExecutorDataCreator() {
		Workbook workbook = null;
		File file = new File(FILE_PATH);

		try {
			// Load existing workbook if it exists, otherwise create a new one
			if (file.exists()) {
				try (FileInputStream fis = new FileInputStream(file)) {
					workbook = new XSSFWorkbook(fis);
					ZipSecureFile.setMinInflateRatio(-1.0d);
				}
			} else {
				workbook = new XSSFWorkbook();
			}

			// Initialize Reflections with the class loader
			Reflections reflections = new Reflections(new org.reflections.util.ConfigurationBuilder()
					.setScanners(new SubTypesScanner(false), new TypeAnnotationsScanner()).forPackages("")
					.addClassLoaders(ClassLoader.getSystemClassLoader()));

			// Get all classes in the classpath
			Set<Class<?>> allClasses = reflections.getSubTypesOf(Object.class);

			for (Class<?> clazz : allClasses) {
				// Check if the class has any methods annotated with @Test
				Method[] methods = clazz.getDeclaredMethods();
				boolean hasTestMethod = false;

				// Check if any method is annotated with @Test
				for (Method method : methods) {
					if (method.isAnnotationPresent(Test.class)) {
						hasTestMethod = true;
						break; // Stop scanning methods if at least one is annotated with @Test
					}
				}

				// If the class has at least one method annotated with @Test, write to Excel
				if (hasTestMethod) {
					createOrUpdateExcelSheetForTestClass(workbook, clazz, methods);
				}
			}

			// Write the workbook to a file after all sheets are added
			try (FileOutputStream fileOut = new FileOutputStream(FILE_PATH)) {
				workbook.write(fileOut);
				// System.out.println("Excel file created/updated: " + FILE_PATH);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (workbook != null) {
				try {
					workbook.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * Method to create or update an Excel sheet for a class and its methods
	 * 
	 * @author sanoj.swaminathan
	 * @since 05-09-2024
	 * @param workbook
	 * @param clazz
	 * @param methods
	 */
	private static void createOrUpdateExcelSheetForTestClass(Workbook workbook, Class<?> clazz, Method[] methods) {
		String sheetName = clazz.getSimpleName(); // Sheet name is the last part of the class name
		Sheet sheet = getOrCreateSheet(workbook, sheetName);

		// Get existing methods in the sheet to avoid duplicates
		Set<String> existingMethods = getExistingMethods(sheet);

		int rowCount = sheet.getLastRowNum() + 1; // Start after the last row

		// Write class and method information
		for (Method method : methods) {
			if (method.isAnnotationPresent(Test.class)) {
				String classMethodKey = clazz.getName() + "#" + method.getName();
				if (!existingMethods.contains(classMethodKey)) {
					// Create a row for each test method
					Row row = sheet.createRow(rowCount++);
					row.createCell(0).setCellValue(clazz.getName());
					row.createCell(1).setCellValue(method.getName());
					row.createCell(2).setCellValue(""); // Tag column can be filled as needed
					row.createCell(3).setCellValue("No"); // Default value for "Need to execute?"
//					row.createCell(4).setCellValue(""); //enable if we need it in future for tracking status
				}
			}
		}
	}

	/**
	 * Method to get or create a sheet
	 * 
	 * @author sanoj.swaminathan
	 * @since 05-09-2024
	 * @param workbook
	 * @param sheetName
	 * @return
	 */
	private static Sheet getOrCreateSheet(Workbook workbook, String sheetName) {
		Sheet sheet = workbook.getSheet(sheetName);
		if (sheet == null) {
			sheet = workbook.createSheet(sheetName);

			// Create a bold font for the header
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);

			// Create a cell style with the bold font
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);

			// Set a fixed column width
			int fixedColumnWidth = 20 * 256;
			for (int i = 0; i < 5; i++) {
				sheet.setColumnWidth(i, fixedColumnWidth);
			}

			// Create header row
			Row headerRow = sheet.createRow(0);
			Cell cell0 = headerRow.createCell(0);
			cell0.setCellValue("Test Suite Name");
			cell0.setCellStyle(headerCellStyle);

			Cell cell1 = headerRow.createCell(1);
			cell1.setCellValue("TestID");
			cell1.setCellStyle(headerCellStyle);

			Cell cell2 = headerRow.createCell(2);
			cell2.setCellValue("Tags");
			cell2.setCellStyle(headerCellStyle);

			Cell cell3 = headerRow.createCell(3);
			cell3.setCellValue("Need to execute?");
			cell3.setCellStyle(headerCellStyle);

			// enable if we need it in future for tracking status
//			Cell cell4 = headerRow.createCell(4);
//			cell4.setCellValue("Status");
//			cell4.setCellStyle(headerCellStyle);
		}
		return sheet;
	}

	/**
	 * Method to get existing methods in the sheet
	 * 
	 * @author sanoj.swaminathan
	 * @since 05-09-2024
	 * @param sheet
	 * @return
	 */
	private static Set<String> getExistingMethods(Sheet sheet) {
		Set<String> existingMethods = new HashSet<>();
		for (int i = 1; i <= sheet.getLastRowNum(); i++) {
			Row row = sheet.getRow(i);
			if (row != null) {
				Cell classCell = row.getCell(0);
				Cell methodCell = row.getCell(1);
				if (classCell != null && methodCell != null) {
					String classMethodKey = classCell.getStringCellValue() + "#" + methodCell.getStringCellValue();
					existingMethods.add(classMethodKey);
				}
			}
		}
		return existingMethods;
	}
}
