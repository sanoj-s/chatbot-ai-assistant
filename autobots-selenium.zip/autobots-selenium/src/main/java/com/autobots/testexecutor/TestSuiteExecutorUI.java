package com.autobots.testexecutor;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.autobots.exception.AutomationException;
import com.autobots.keywords.DataHandler;
import com.autobots.utils.AutomationConstants;

public class TestSuiteExecutorUI {
	private static DefaultListModel<String> topListModel;
	private static DefaultListModel<String> bottomListModel;
	private static JList<String> topList;
	private static JList<String> bottomList;
	private static JButton moveDownButton;
	private static JButton moveUpButton;
	private static JButton executeButton;
	private static JButton saveButton;
	private static JButton deleteButton;
	private static JButton viewButton;
	private static JButton viewReportButton;
	private static JButton editButton;
	private static JTextField testNGFileNameField;
	private static JComboBox<String> testNGFilesComboBox;
	private static JComboBox<String> testSuiteSelector;
	private static JComboBox<String> executionEnvironmentComboBox;
	private static Workbook workbook;

	// New fields for Platform, Browser, Browser Version
	private static JTextField platformField;
	private static JComboBox<String> browserComboBox;
	private static JTextField browserVersionField;
	private static JComboBox<String> parallelModeField;
	private static JTextField threadCountField;
	private static JTextField retryCountField;

	private static List<String> generatedXMLFiles = new ArrayList<>();

	private static boolean isEditSame = false;

	static String testDataPath = "./src/test/resources/TestSuiteExtractor.xlsx";
	static String excelFilePath = System.getProperty("user.dir") + testDataPath;
	static String panelBackgroundColor = "#A173C0";
	static String labelBackgroundColor = "#FFFFFF";

	/**
	 * Method to get the Test Executor UI to create test suite execution
	 * configuration, execution and view report
	 * 
	 * @author sanoj.swaminathan
	 * @since 05-09-2024
	 */
	public static void getTestSuiteExecutor() {

		JFrame frame = new JFrame("Test Executor");
		// Initialize new fields
		platformField = new JTextField();
		browserComboBox = new JComboBox<>(
				new String[] { "Chrome", "Firefox", "Edge", "Safari", "IE", "Headless-Chrome" });
		browserVersionField = new JTextField();
		parallelModeField = new JComboBox<>(new String[] { "none", "methods", "classes", "tests" });
		threadCountField = new JTextField();

		// Initialize list models
		topListModel = new DefaultListModel<>();
		bottomListModel = new DefaultListModel<>();

		// Initialize lists
		topList = new JList<>(topListModel);
		bottomList = new JList<>(bottomListModel);

		// Set selection mode to multiple intervals
		topList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		bottomList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

		// Initialize components for Run Configurations
		testNGFileNameField = new JTextField();
		testNGFileNameField.setPreferredSize(new Dimension(200, 25));
		testNGFilesComboBox = new JComboBox<>();
		testNGFilesComboBox.setPreferredSize(new Dimension(200, testNGFilesComboBox.getPreferredSize().height));
		retryCountField = new JTextField();
		retryCountField.setPreferredSize(new Dimension(40, 25));

		listAvailableXMLFiles();
		testNGFilesComboBox.setEditable(false);

		// Move selected test cases to the bottom
		moveDownButton = new JButton("▼");
		moveDownButton.setMaximumSize(new Dimension(50, 50));
		moveDownButton.setBackground(Color.decode("#E6CCFF"));
		moveDownButton.setForeground(Color.WHITE);
		moveDownButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				moveSelectedItems();

				// Set first item selected state
				topList.setSelectedIndex(0);

				// Logic to enable/disable down and up arrow
				enableDisableDownAndUpArrow();
			}
		});

		// Move selected test cases to the top
		moveUpButton = new JButton("▲");
		moveUpButton.setMaximumSize(new Dimension(50, 50));
		moveUpButton.setBackground(Color.decode("#E6CCFF"));
		moveUpButton.setForeground(Color.WHITE);
		moveUpButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				moveBackSelectedItems();

				// Set first item selected state
				topList.setSelectedIndex(0);

				// Logic to enable/disable down and up arrow
				enableDisableDownAndUpArrow();
			}
		});

		// Save the run configuration
		saveButton = new JButton("Save");
		saveButton.setPreferredSize(new Dimension(141, 30));
		saveButton.setBackground(Color.decode("#4CAF50"));
		saveButton.setForeground(Color.WHITE);
		saveButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (testNGFileNameField.getText().length() == 0 || testNGFileNameField.getText().isEmpty()
						|| testNGFileNameField.getText().equals("")
						|| !testNGFileNameField.getText().matches("[\\w\\-]+")) {
					JOptionPane.showMessageDialog(frame, "Please enter all the required details");
				} else if (!checkForAtLeastOneTestCase()) {
					JOptionPane.showMessageDialog(frame, "Please select at least one test case.");
				} else {
					if (testNGFilesComboBox.getSelectedItem() != null) {
						String runConfigFileName = testNGFileNameField.getText();
						String platform = platformField.getText();
						String browser = browserComboBox.getSelectedItem().toString();
						String browserVersion = browserVersionField.getText();
						String parallelMode = parallelModeField.getSelectedItem().toString();
						String threadCount = threadCountField.getText();
						if (runConfigFileName
								.equals(testNGFilesComboBox.getSelectedItem().toString().split("\\.")[0])) {
							// To delete the selected file
							int selectedIndex = testNGFilesComboBox.getSelectedIndex();
							if (selectedIndex != -1) {
								File fileToDelete = new File(System.getProperty("user.dir"),
										TestSuiteExecutorCore.testRunnersPath + "/"
												+ testNGFilesComboBox.getSelectedItem().toString());
								if (fileToDelete.exists()) {
									if (fileToDelete.delete()) {
										isEditSame = true;
										testNGFilesComboBox.removeItemAt(selectedIndex);
										generatedXMLFiles.remove(selectedIndex);
									}
								}
							}
							// generate the run configuration if the selected run configuration name and
							// the given run configuration name are the same
							generateTestNGXml(runConfigFileName, platform, browser, browserVersion, parallelMode,
									threadCount, frame);
							isEditSame = false;
						} else {
							// generate the new run configuration if the selected run configuration name and
							// the given run configuration name are different
							generateTestNGXml(frame);
						}
					} else {
						// generate the new run configuration when save button is clicked if no run
						// configuration is
						// available
						generateTestNGXml(frame);
					}
					platformField.setText("");
					browserComboBox.setSelectedItem("Chrome");
					browserVersionField.setText("");
					testNGFileNameField.setText("");
					parallelModeField.setSelectedItem("methods");
					threadCountField.setText("1");
				}
			}
		});

		// Execute the test suites
		executeButton = new JButton("Execute");
		executeButton.setPreferredSize(new Dimension(141, 40));
		executeButton.setBackground(Color.decode("#007FFF"));
		executeButton.setForeground(Color.WHITE);
		executeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if (testNGFilesComboBox.getSelectedItem() == null) {
						JOptionPane.showMessageDialog(frame, "No run configuration available for execution.");
					} else {
						String retryCountValue = retryCountField.getText();
						String executionEnvironment = executionEnvironmentComboBox.getSelectedItem().toString();
						DataHandler dataHandler = new DataHandler();
						try {
							dataHandler.updatePropertyValueInFile(AutomationConstants.FRAMEWORK_CONFIG_FILE_PATH,
									AutomationConstants.RETRY_FAILURE_LIMIT, retryCountValue);
							dataHandler.updatePropertyValueInFile(AutomationConstants.AUTOMATION_TEST_CONFIG_FILE_PATH,
									AutomationConstants.EXECUTION_ENVIRONMENT, executionEnvironment);
						} catch (AutomationException ex) {
							ex.printStackTrace();
						}
						executeTestCases();
					}
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});

		// Edit the run configuration
		editButton = new JButton("Edit");
		editButton.setPreferredSize(new Dimension(98, 30));
		editButton.setBackground(Color.decode("#00BFFF"));
		editButton.setForeground(Color.WHITE);
		editButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (testNGFilesComboBox.getSelectedItem() == null) {
					JOptionPane.showMessageDialog(frame, "No run configuration available for editing.");
				} else {
					String selectedFileName = (String) testNGFilesComboBox.getSelectedItem();
					loadDataFromXML(selectedFileName);
					testNGFileNameField.setText(selectedFileName.split("\\.")[0]);
				}
			}

			/**
			 * Method to load the data from the generated TestNG XML file for editing
			 * 
			 * @author sanoj.swaminathan
			 * @since 12-09-2024
			 * @param selectedFileName
			 */
			public void loadDataFromXML(String selectedFileName) {
				try {
					String userDir = System.getProperty("user.dir");
					String folderPath = userDir + TestSuiteExecutorCore.testRunnersPath;
					File xmlFile = new File(folderPath + "/" + selectedFileName);
					DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
					dbFactory.setValidating(false);
					dbFactory.setNamespaceAware(true);
					dbFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
					DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
					Document doc = dBuilder.parse(xmlFile);

					// Normalize the XML structure
					doc.getDocumentElement().normalize();

					// Get the suite details
					NodeList suiteNodeList = doc.getElementsByTagName("suite");
					Node suiteNode = suiteNodeList.item(0);
					if (suiteNode.getNodeType() == Node.ELEMENT_NODE) {
						Element suiteElement = (Element) suiteNode;
						parallelModeField.setSelectedItem(suiteElement.getAttribute("parallel"));
						threadCountField.setText(suiteElement.getAttribute("thread-count") == null ? "1"
								: suiteElement.getAttribute("thread-count"));
					}

					// Get the parameter details
					NodeList parameterList = doc.getElementsByTagName("parameter");

					for (int i = 0; i < parameterList.getLength(); i++) {
						Node parameterNode = parameterList.item(i);

						if (parameterNode.getNodeType() == Node.ELEMENT_NODE) {
							Element parameterElement = (Element) parameterNode;
							String paramName = parameterElement.getAttribute("name");
							String paramValue = parameterElement.getAttribute("value");

							// Fill the fields based on the parameter name
							switch (paramName) {
							case "platformName":
								platformField.setText(paramValue);
								break;
							case "browserName":
								browserComboBox.setSelectedItem(paramValue);
								break;
							case "browserVersion":
								browserVersionField.setText(paramValue);
								break;
							default:
								break;
							}
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});

		// Delete the run configuration
		deleteButton = new JButton("Delete");
		deleteButton.setPreferredSize(new Dimension(98, 30));
		deleteButton.setBackground(Color.decode("#FF6347"));
		deleteButton.setForeground(Color.WHITE);
		deleteButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (testNGFilesComboBox.getSelectedItem() == null) {
					JOptionPane.showMessageDialog(frame, "No run configuration available for deletion.");
				} else {
					int result = JOptionPane.showConfirmDialog(frame,
							"Do you want to delete '" + (String) testNGFilesComboBox.getSelectedItem() + "'?",
							"Confirmation", JOptionPane.YES_NO_OPTION);

					if (result == JOptionPane.YES_OPTION) {
						int selectedIndex = testNGFilesComboBox.getSelectedIndex();
						if (selectedIndex != -1) {
							File fileToDelete = new File(System.getProperty("user.dir"),
									TestSuiteExecutorCore.testRunnersPath + "/"
											+ (String) testNGFilesComboBox.getSelectedItem());
							if (fileToDelete.exists()) {
								if (fileToDelete.delete()) {
									testNGFilesComboBox.removeItemAt(selectedIndex);
									generatedXMLFiles.remove(selectedIndex);

									// Clear the fields
									platformField.setText("");
									browserComboBox.setSelectedItem("Chrome");
									browserVersionField.setText("");
									testNGFileNameField.setText("");
									parallelModeField.setSelectedItem("methods");
									threadCountField.setText("1");

									JOptionPane.showMessageDialog(frame, "Run configuration deleted successfully.");

									// Move the selected values from bottom list to top after delete the last XML
									// file
									if (testNGFilesComboBox == null || testNGFilesComboBox.getItemCount() == 0) {
										List<String> allValues = new ArrayList<>();
										for (int i = 0; i < bottomListModel.getSize(); i++) {
											allValues.add(bottomListModel.getElementAt(i));
										}
										for (String value : allValues) {
											topListModel.addElement(value);
											bottomListModel.removeElement(value);
											updateExcelSheet("No");
										}
									}
								}
							}
						}
					}
				}
			}
		});

		// View the run configuration details
		viewButton = new JButton("View Configuration");
		viewButton.setPreferredSize(new Dimension(141, 30));
		viewButton.setForeground(Color.WHITE);
		viewButton.setBackground(Color.decode("#808080"));
		viewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (testNGFilesComboBox.getSelectedItem() == null) {
					JOptionPane.showMessageDialog(frame, "No run configuration available for viewing.");
				} else {
					String selectedFileName = (String) testNGFilesComboBox.getSelectedItem();
					showXMLData(selectedFileName);
				}
			}

			/**
			 * To show the XML data in a new frame
			 * 
			 * @author sanoj.swaminathan
			 * @since 12-09-2024
			 * @param selectedXMLFileName
			 */
			private void showXMLData(String selectedXMLFileName) {
				// Create a new JFrame for the XML data view
				JFrame viewFrame = new JFrame("Configuration Details - " + selectedXMLFileName);
				viewFrame.setSize(500, 400);
				viewFrame.setLocationRelativeTo(null);

				// Read the XML file
				StringBuilder xmlContent = new StringBuilder();
				try {
					String userDir = System.getProperty("user.dir");
					String folderPath = userDir + TestSuiteExecutorCore.testRunnersPath;
					File xmlFile = new File(folderPath + "/" + selectedXMLFileName);
					BufferedReader reader = new BufferedReader(new FileReader(xmlFile));
					String line;
					while ((line = reader.readLine()) != null) {
						xmlContent.append(line).append("\n");
					}
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
					xmlContent.append("Error reading file");
				}

				// Create a JTextArea to display the XML content
				JTextArea textArea = new JTextArea(xmlContent.toString());
				textArea.setEditable(false);
				textArea.setLineWrap(true);
				textArea.setWrapStyleWord(true);
				textArea.setAlignmentX(Component.LEFT_ALIGNMENT);
				textArea.setMargin(new Insets(10, 10, 10, 10));

				JScrollPane scrollPane = new JScrollPane(textArea);
				viewFrame.add(scrollPane, BorderLayout.CENTER);
				viewFrame.setVisible(true);
				viewFrame.setLocationRelativeTo(null);
				viewFrame.setResizable(false);
			}

		});

		// Create the view report option to open the selected HTML report in the default
		// web browser
		viewReportButton = new JButton("View Reports");
		viewReportButton.setPreferredSize(new Dimension(141, 40));
		viewReportButton.setBackground(Color.decode("#808080"));
		viewReportButton.setForeground(Color.WHITE);
		viewReportButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				File reportRoot = new File(System.getProperty("user.dir") + "/Reports/");
				File[] htmlReports = reportRoot.listFiles((dir, name) -> name.endsWith(".html"));
				if (htmlReports != null && htmlReports.length > 0) {
					// Create a new JFrame for HTML reports
					JFrame reportFrame = new JFrame("Report Viewer");
					reportFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					reportFrame.setSize(400, 150);
					reportFrame.setLayout(new FlowLayout());
					reportFrame.setResizable(false);

					// Sort the HTML reports by last modified time-stamp in descending order
					Arrays.sort(htmlReports, new Comparator<File>() {
						@Override
						public int compare(File file1, File file2) {
							return Long.compare(file2.lastModified(), file1.lastModified());
						}
					});

					DefaultComboBoxModel<String> reportComboBoxModel = new DefaultComboBoxModel<>();
					for (File report : htmlReports) {
						reportComboBoxModel.addElement(report.getName());
					}
					JComboBox<String> reportDropdown = new JComboBox<>(reportComboBoxModel);

					// Create an "Open" button
					JButton openReportBtn = new JButton("Open");
					openReportBtn.setBackground(Color.decode("#1ABC9C"));
					openReportBtn.setForeground(Color.decode(labelBackgroundColor));

					JPanel reportPanel = new JPanel();
					Border border = BorderFactory.createTitledBorder("Select a report");
					((TitledBorder) border).setTitleColor(Color.decode(labelBackgroundColor));
					reportPanel.setBorder(border);
					reportPanel.add(reportDropdown);
					reportPanel.setBackground(Color.decode(panelBackgroundColor));
					reportFrame.add(reportPanel);
					reportFrame.add(openReportBtn);
					reportFrame.getContentPane().setBackground(Color.decode(panelBackgroundColor));

					openReportBtn.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							String selectedReport = (String) reportDropdown.getSelectedItem();
							if (selectedReport != null) {
								// Open the selected HTML report in the default web browser
								try {
									Desktop.getDesktop().browse(
											new File(System.getProperty("user.dir") + "/Reports/" + selectedReport)
													.toURI());
								} catch (Exception ex) {
									ex.printStackTrace();
								}
							}
						}
					});

					reportFrame.setLocationRelativeTo(null);
					reportFrame.setVisible(true);
					reportFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				} else {
					JOptionPane.showMessageDialog(null, "No HTML reports found in the Reports directory.", "Message",
							JOptionPane.INFORMATION_MESSAGE);
				}
			}
		});

		// Initialize test suite selection combo box with the list of test suites
		testSuiteSelector = new JComboBox<>();
		testSuiteSelector.setPreferredSize(new Dimension(200, 30));
		testSuiteSelector.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					String selectedSheet = (String) e.getItem();
					updateListsFromExcel(excelFilePath, selectedSheet);
					topList.setSelectedIndex(0);

					// Logic to enable/disable down and up arrow
					enableDisableDownAndUpArrow();
				}
			}
		});

		// Initialize testNG files combo box with the list of testNG files
		testNGFilesComboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					// Parse XML and update Excel file
					String userDir = System.getProperty("user.dir");
					String folderPath = userDir + TestSuiteExecutorCore.testRunnersPath;
					if (!isEditSame) {
						Map<String, List<String>> classMethodsMap = parseXMLFile(
								folderPath + "/" + testNGFilesComboBox.getSelectedItem().toString());
						updateExcelFileWithNewData(excelFilePath, classMethodsMap);
						// Refresh lists based on updated Excel data
						updateListsFromExcel(excelFilePath, testSuiteSelector.getSelectedItem().toString());
					}
					// Clear the fields
					platformField.setText("");
					browserComboBox.setSelectedItem("Chrome");
					browserVersionField.setText("");
					testNGFileNameField.setText("");
					parallelModeField.setSelectedItem("methods");
					threadCountField.setText("1");
				}
			}
		});

		// Read the sheet names from Excel file
		loadSheetNames();

		// Layout components
		Container contentPane = frame.getContentPane();
		contentPane.setLayout(new BorderLayout());

		// Create a panel for the new fields
		JPanel fieldsPanel = new JPanel();
		Border create_border = BorderFactory.createTitledBorder("Execution Environment Configurations");
		((TitledBorder) create_border).setTitleColor(Color.decode(labelBackgroundColor));
		fieldsPanel.setBorder(create_border);
		fieldsPanel.setLayout(new GridBagLayout());

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(5, 5, 5, 5);
		gbc.weightx = 0.1;
		gbc.weighty = 0;

		// Row 1: Platform
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.anchor = GridBagConstraints.WEST;
		JLabel platformLabel = new JLabel("Platform");
		platformLabel.setForeground(Color.decode(labelBackgroundColor));
		fieldsPanel.add(platformLabel, gbc);

		gbc.gridx = 1;
		gbc.weightx = 1.0;
		platformField.setPreferredSize(new Dimension(350, 25));
		fieldsPanel.add(platformField, gbc);

		// Row 2: Browser
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.weightx = 0.1;
		gbc.anchor = GridBagConstraints.WEST;
		JLabel browserLabel = new JLabel("Browser");
		browserLabel.setForeground(Color.decode(labelBackgroundColor));
		fieldsPanel.add(browserLabel, gbc);

		gbc.gridx = 1;
		gbc.weightx = 1.0;
		browserComboBox.setPreferredSize(new Dimension(350, 25));
		fieldsPanel.add(browserComboBox, gbc);

		// Row 3: Browser Version
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.weightx = 0.1;
		gbc.anchor = GridBagConstraints.WEST;
		JLabel browserVersionLabel = new JLabel("Browser Version");
		browserVersionLabel.setForeground(Color.decode(labelBackgroundColor));
		fieldsPanel.add(browserVersionLabel, gbc);

		gbc.gridx = 1;
		gbc.weightx = 1.0;
		browserVersionField.setPreferredSize(new Dimension(350, 25));
		fieldsPanel.add(browserVersionField, gbc);

		// Row 4: Parallel Mode and Thread Count in the same line
		// Parallel Mode label
		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.weightx = 0.1;
		gbc.anchor = GridBagConstraints.WEST;
		JLabel parallelModeLabel = new JLabel("Parallel Mode");
		parallelModeLabel.setForeground(Color.decode(labelBackgroundColor));
		fieldsPanel.add(parallelModeLabel, gbc);

		// Parallel Mode field
		gbc.gridx = 1;
		gbc.weightx = 0.1;
		gbc.fill = GridBagConstraints.NONE;
		parallelModeField.setPreferredSize(new Dimension(350, 25));
		fieldsPanel.add(parallelModeField, gbc);
		parallelModeField.setSelectedItem("methods");

		// Thread count label (aligned right after Parallel Mode field)
		gbc.gridx = 0;
		gbc.gridy = 4;
		gbc.weightx = 0.1;
		gbc.fill = GridBagConstraints.NONE;
		gbc.anchor = GridBagConstraints.WEST;
		JLabel threadCountLabel = new JLabel("Thread Count");
		threadCountLabel.setForeground(Color.decode(labelBackgroundColor));
		fieldsPanel.add(threadCountLabel, gbc);

		// Thread count text field
		gbc.gridx = 1;
		gbc.weightx = 1.0;
		gbc.fill = GridBagConstraints.NONE;
		threadCountField.setPreferredSize(new Dimension(40, 25));
		fieldsPanel.add(threadCountField, gbc);
		threadCountField.setText("1");

		fieldsPanel.setBackground(Color.decode(panelBackgroundColor));

		// Add top panel Run Configurations to content pane
		contentPane.add(fieldsPanel, BorderLayout.NORTH);

		// ***********************************************************//

		// Create a panel for Select Test Cases
		JPanel panel = new JPanel(new GridBagLayout());
		Border select_test_cases_border = BorderFactory.createTitledBorder("Select Test Cases");
		((TitledBorder) select_test_cases_border).setTitleColor(Color.decode(labelBackgroundColor));
		panel.setBorder(select_test_cases_border);

		JScrollPane leftScrollPane = new JScrollPane(topList);
		JScrollPane rightScrollPane = new JScrollPane(bottomList);

		// Create constraints for GridBagLayout
		GridBagConstraints gbcTestCase = new GridBagConstraints();
		gbcTestCase.insets = new Insets(5, 5, 5, 5); // Padding for each component
		gbcTestCase.fill = GridBagConstraints.BOTH;
		gbcTestCase.weightx = 0.8;
		gbcTestCase.weighty = 0.5;

		// Add sheetSelector at the top
		gbcTestCase.gridx = 0;
		gbcTestCase.gridy = 0;
		gbcTestCase.weighty = 0; // Does not grow vertically
		panel.add(testSuiteSelector, gbcTestCase);

		// Add leftScrollPane (leftList below the sheetSelector)
		gbcTestCase.gridx = 0;
		gbcTestCase.gridy = 1;
		gbcTestCase.weighty = 0.5; // Takes half of the vertical space
		panel.add(leftScrollPane, gbcTestCase);

		// Create button panel to hold buttons side by side in the center
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		buttonPanel.add(Box.createHorizontalGlue());

		// Add moveRightButton and moveLeftButton side by side
		buttonPanel.add(moveDownButton);
		buttonPanel.add(Box.createHorizontalStrut(10));
		buttonPanel.add(moveUpButton);
		buttonPanel.add(Box.createHorizontalGlue());
		buttonPanel.setBackground(Color.decode(panelBackgroundColor));

		// Add buttonPanel in the middle
		gbcTestCase.gridx = 0;
		gbcTestCase.gridy = 2;
		gbcTestCase.weighty = 0; // Does not grow vertically
		panel.add(buttonPanel, gbcTestCase);

		// Add rightScrollPane (rightList at the bottom)
		gbcTestCase.gridx = 0;
		gbcTestCase.gridy = 3;
		gbcTestCase.weighty = 0.5; // Takes half of the vertical space
		panel.add(rightScrollPane, gbcTestCase);

		panel.setBackground(Color.decode(panelBackgroundColor));

		// Add panel to content pane
		contentPane.add(panel, BorderLayout.CENTER);

		// ***********************************************************//

		// Create a panel for the Run Configurations section
		JPanel runConfigurationsPanel = new JPanel();
		Border runConfigurationsBorder = BorderFactory.createTitledBorder("Run Configurations");
		((TitledBorder) runConfigurationsBorder).setTitleColor(Color.decode(labelBackgroundColor));
		runConfigurationsPanel.setBorder(runConfigurationsBorder);
		runConfigurationsPanel.setLayout(new GridBagLayout());

		GridBagConstraints gbcRunConfig = new GridBagConstraints();
		gbcRunConfig.insets = new Insets(5, 5, 5, 5); // Padding for each component
		gbcRunConfig.fill = GridBagConstraints.HORIZONTAL;
		gbcRunConfig.anchor = GridBagConstraints.NORTHWEST; // Align components to top-left
		gbcRunConfig.weightx = 0.2;

		// Row 1: Run Configuration File Name Label and Field
		gbcRunConfig.gridx = 0;
		gbcRunConfig.gridy = 0;
		JLabel runConfigurationsLabel = new JLabel("Run Configuration File Name *");
		runConfigurationsLabel.setForeground(Color.decode(labelBackgroundColor));
		runConfigurationsPanel.add(runConfigurationsLabel, gbcRunConfig);

		gbcRunConfig.gridx = 1;
		runConfigurationsPanel.add(testNGFileNameField, gbcRunConfig);

		gbcRunConfig.gridx = 2;
		runConfigurationsPanel.add(saveButton, gbcRunConfig);

		// Row 2: Select Run Configuration File Label and ComboBox
		gbcRunConfig.gridx = 0;
		gbcRunConfig.gridy = 1;
		gbcRunConfig.fill = GridBagConstraints.NONE;
		JLabel selectRunConfigurationsLabel = new JLabel("Select Run Configuration File");
		selectRunConfigurationsLabel.setForeground(Color.decode(labelBackgroundColor));
		runConfigurationsPanel.add(selectRunConfigurationsLabel, gbcRunConfig);

		gbcRunConfig.gridx = 1;
		gbcRunConfig.fill = GridBagConstraints.HORIZONTAL;
		runConfigurationsPanel.add(testNGFilesComboBox, gbcRunConfig);

		gbcRunConfig.gridx = 2;
		runConfigurationsPanel.add(editButton, gbcRunConfig);

		// Row 2.5: Execution Environment Label and ComboBox
		gbcRunConfig.gridx = 0;
		gbcRunConfig.gridy = 2;
		JLabel executionEnvironmentLabel = new JLabel("Execution Environment");
		executionEnvironmentLabel.setForeground(Color.decode(labelBackgroundColor));
		runConfigurationsPanel.add(executionEnvironmentLabel, gbcRunConfig);

		gbcRunConfig.gridx = 1;
		gbcRunConfig.fill = GridBagConstraints.HORIZONTAL;
		executionEnvironmentComboBox = new JComboBox<>(new String[] { "Local", "LambdaTest" });
		runConfigurationsPanel.add(executionEnvironmentComboBox, gbcRunConfig);

		gbcRunConfig.gridx = 2;
		runConfigurationsPanel.add(deleteButton, gbcRunConfig);

		// Row 3: Retry Count Label and Field
		gbcRunConfig.gridx = 0;
		gbcRunConfig.gridy = 3;
		JLabel retryCountLabel = new JLabel("Retry Count");
		retryCountLabel.setForeground(Color.decode(labelBackgroundColor));
		runConfigurationsPanel.add(retryCountLabel, gbcRunConfig);

		gbcRunConfig.gridx = 1;
		runConfigurationsPanel.add(retryCountField, gbcRunConfig);
		retryCountField.setText("0");

		gbcRunConfig.gridx = 2;
		runConfigurationsPanel.add(viewButton, gbcRunConfig);

		// Row 4: Edit, Delete, and View Buttons
		gbcRunConfig.gridx = 1;
		gbcRunConfig.gridy = 5;
		runConfigurationsPanel.add(executeButton, gbcRunConfig);

		// Add View Reports Button below Delete Button
		gbcRunConfig.gridx = 2;
		runConfigurationsPanel.add(viewReportButton, gbcRunConfig);

		// Empty Row to push components upwards
		gbcRunConfig.gridx = 0;
		gbcRunConfig.gridy = 5;
		gbcRunConfig.weighty = 1.0;
		runConfigurationsPanel.add(new JLabel(), gbcRunConfig);

		runConfigurationsPanel.setBackground(Color.decode(panelBackgroundColor));

		// Add the runConfigurationsPanel to the content pane on the right side
		contentPane.add(runConfigurationsPanel, BorderLayout.EAST);

		frame.setSize(1100, 700);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
	}

	/**
	 * Method to enable and disable the move up and down buttons based on the state
	 * of the top and bottom lists
	 * 
	 * @author sanoj.swaminathan
	 * @since 09-09-2024
	 */
	private static void enableDisableDownAndUpArrow() {
		try {
			int topSize = topList.getModel().getSize();
			int bottomSize = bottomList.getModel().getSize();
			moveUpButton.setEnabled(false);
			moveDownButton.setEnabled(false);
			if (topSize > 0) {
				moveDownButton.setEnabled(true);
			}
			if (bottomSize > 0) {
				moveUpButton.setEnabled(true);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to load the sheet names from the excel file
	 * 
	 * @author sanoj.swaminathan
	 * @since 09-09-2024
	 */
	private static void loadSheetNames() {
		try {
			FileInputStream file = new FileInputStream(excelFilePath);
			workbook = new XSSFWorkbook(file);
			for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
				testSuiteSelector.addItem(workbook.getSheetName(i));
			}
			file.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to move selected items from top list to bottom list
	 * 
	 * @author sanoj.swaminathan
	 * @since 09-09-2024
	 */
	private static void moveSelectedItems() {
		List<String> selectedValues = topList.getSelectedValuesList();
		for (String value : selectedValues) {
			bottomListModel.addElement(value);
			topListModel.removeElement(value);
			updateExcelSheet(testSuiteSelector.getSelectedItem().toString(), value, "Yes");
		}
	}

	/**
	 * Method to move selected items from bottom list to top list
	 * 
	 * @author sanoj.swaminathan
	 * @since 09-09-2024
	 */
	private static void moveBackSelectedItems() {
		List<String> selectedValues = bottomList.getSelectedValuesList();
		for (String value : selectedValues) {
			topListModel.addElement(value);
			bottomListModel.removeElement(value);
			updateExcelSheet(testSuiteSelector.getSelectedItem().toString(), value, "No");
		}
	}

	/**
	 * Method to update the excel sheet
	 * 
	 * @author sanoj.swaminathan
	 * @since 09-09-2024
	 * @param sheetName
	 * @param testCaseID
	 * @param executeValue
	 */
	private static void updateExcelSheet(String sheetName, String testCaseID, String executeValue) {
		try {
			Sheet sheet = workbook.getSheet(sheetName);
			for (Row row : sheet) {
				Cell cell = row.getCell(1);
				if (cell != null && cell.getStringCellValue().equals(testCaseID)) {
					Cell executeCell = row.getCell(3);
					if (executeCell == null) {
						executeCell = row.createCell(3);
					}
					executeCell.setCellValue(executeValue);
					break;
				}
			}
			FileOutputStream outFile = new FileOutputStream(excelFilePath);
			workbook.write(outFile);
			outFile.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to update the excel sheet
	 * 
	 * @author sanoj.swaminathan
	 * @since 09-09-2024
	 * @param executeValue
	 */
	private static void updateExcelSheet(String executeValue) {
		try {
			for (Sheet sheet : workbook) {
				for (int i = 1; i <= sheet.getLastRowNum(); i++) {
					Row row = sheet.getRow(i);
					Cell executeCell = row.getCell(3);
					if (executeCell == null) {
						executeCell = row.createCell(3);
					}
					executeCell.setCellValue(executeValue);
				}
			}

			FileOutputStream outFile = new FileOutputStream(excelFilePath);
			workbook.write(outFile);
			outFile.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to check if any test case needs to be executed is selected or not
	 * 
	 * @author sanoj.swaminathan
	 * @since 09-09-2024
	 * @return
	 */
	private static boolean checkForAtLeastOneTestCase() {
		List<String> cellValues = new ArrayList<>();
		for (Sheet sheet : workbook) {
			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				Row row = sheet.getRow(i);
				if (row != null) {
					Cell cell = row.getCell(3);
					if (cell != null) {
						cellValues.add(cell.getStringCellValue());
					}
				}
			}
		}
		return cellValues.contains("Yes");
	}

	/**
	 * Method to read Excel file and update based on the extracted data
	 * 
	 * @author sanoj.swaminathan
	 * @since 09-09-2024
	 * @param excelFilePath
	 * @param sheetName
	 */
	private static void updateListsFromExcel(String excelFilePath, String sheetName) {
		topListModel.clear();
		bottomListModel.clear();
		try (FileInputStream file = new FileInputStream(new File(excelFilePath));
				Workbook workbook = new XSSFWorkbook(file)) {

			Sheet sheet = workbook.getSheet(sheetName);

			for (Row row : sheet) {
				Cell testCaseIDCell = row.getCell(1);
				Cell executeCell = row.getCell(3);

				if (testCaseIDCell != null && executeCell != null && testCaseIDCell.getCellType() == CellType.STRING
						&& executeCell.getCellType() == CellType.STRING) {

					String testCaseID = testCaseIDCell.getStringCellValue();
					String executeValue = executeCell.getStringCellValue();

					if (testCaseID != null && testCaseID.trim().equals("TestID")) {
						continue;
					}

					if ("Yes".equalsIgnoreCase(executeValue)) {
						bottomListModel.addElement(testCaseID);
					} else {
						topListModel.addElement(testCaseID);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Parse XML file to extract class names and their corresponding methods
	 * 
	 * @author sanoj.swaminathan
	 * @since 06-09-2024
	 * @param xmlFilePath
	 * @return
	 */
	private static Map<String, List<String>> parseXMLFile(String xmlFilePath) {
		Map<String, List<String>> classMethodsMap = new HashMap<>();
		try {
			File xmlFile = new File(xmlFilePath);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			dbFactory.setValidating(false);
			dbFactory.setNamespaceAware(true);
			dbFactory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(xmlFile);
			doc.getDocumentElement().normalize();

			NodeList classNodes = doc.getElementsByTagName("class");

			for (int i = 0; i < classNodes.getLength(); i++) {
				Element classElement = (Element) classNodes.item(i);
				String className = classElement.getAttribute("name");

				NodeList methodNodes = classElement.getElementsByTagName("include");
				List<String> methodNames = new ArrayList<>();

				for (int j = 0; j < methodNodes.getLength(); j++) {
					Element methodElement = (Element) methodNodes.item(j);
					String methodName = methodElement.getAttribute("name");

					// Add method to the list of methods for this class
					methodNames.add(methodName);
				}
				// Store the list of methods in the map for this class
				classMethodsMap.put(className, methodNames);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return classMethodsMap;
	}

	/**
	 * Read Excel file and update based on the extracted data
	 * 
	 * @author sanoj.swaminathan
	 * @since 06-09-2024
	 * @param excelFilePath
	 * @param classMethodsMap
	 */
	private static void updateExcelFileWithNewData(String excelFilePath, Map<String, List<String>> classMethodsMap) {
		try (FileInputStream file = new FileInputStream(new File(excelFilePath));
				Workbook workbook = new XSSFWorkbook(file)) {

			// Iterate through all sheets in the workbook
			for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
				Sheet sheet = workbook.getSheetAt(i);

				for (Row row : sheet) {
					if (row.getRowNum() == 0)
						continue; // Skip header row

					Cell classCell = row.getCell(0);
					Cell methodCell = row.getCell(1);
					Cell executeCell = row.getCell(3);

					if (classCell != null && methodCell != null && executeCell != null) {
						String className = classCell.getStringCellValue();
						String methodName = methodCell.getStringCellValue();

						// Default value is "No"
						String executeValue = "No";

						// Check if the class exists and the method is in the list of methods for that
						// class
						if (classMethodsMap.containsKey(className)) {
							List<String> methods = classMethodsMap.get(className);
							// Explicitly check each method for equality
							for (String method : methods) {
								if (method.equals(methodName)) {
									executeValue = "Yes";
									break;
								}
							}
						}
						executeCell.setCellValue(executeValue);
					}
				}
			}

			// Write back to the Excel file
			try (FileOutputStream outputStream = new FileOutputStream(excelFilePath)) {
				workbook.write(outputStream);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to get the list of XML files from project root except the pom.xml file
	 * 
	 * @author sanojs
	 * @since 12-09-2023
	 */
	private static void listAvailableXMLFiles() {

		String userDir = System.getProperty("user.dir");
		String folderPath = userDir + TestSuiteExecutorCore.testRunnersPath;
		File folder = new File(folderPath);
		if (!folder.exists()) {
			folder.mkdirs();
		}
		File currentDirectory = new File(folderPath);
		File[] files = currentDirectory.listFiles((dir, name) -> name.endsWith(".xml"));
		for (File file : files) {
			if (!file.getName().equals("pom.xml")) {
				generatedXMLFiles.add(file.getName());
				testNGFilesComboBox.addItem(file.getName());
			}
		}
	}

	/**
	 * Method to generate the TestNG XML file with frame details
	 * 
	 * @author sanoj.swaminathan
	 * @since 06-09-2024
	 * @param frame
	 * @return
	 */
	private static String generateTestNGXml(JFrame frame) {
		String testNGFilePath = null;
		String testngFileName = testNGFileNameField.getText();
		String platformName = platformField.getText();
		String browserName = browserComboBox.getSelectedItem().toString();
		String browserVersion = browserVersionField.getText();
		String parallelMode = parallelModeField.getSelectedItem().toString();
		String threadCount = threadCountField.getText();

		// collecting data for generating the TestNG XML file
		testNGFilePath = TestSuiteExecutorCore.testSuiteGenerator(testDataPath, testngFileName, platformName,
				browserName, browserVersion, parallelMode, threadCount);
		JOptionPane.showMessageDialog(frame, "Run configuration " + testngFileName + ".xml is saved successfully");
		generatedXMLFiles.add(testngFileName + ".xml");
		testNGFilesComboBox.addItem(testngFileName + ".xml");
		testNGFilesComboBox.setSelectedItem(testngFileName + ".xml");
		return testNGFilePath;
	}

	/**
	 * Method to generate the TestNG XML file
	 * 
	 * @author sanoj.swaminathan
	 * @since 06-09-2024
	 * @param testngFileName
	 * @param platformName
	 * @param browserName
	 * @param browserVersion
	 * @param parallelMode
	 * @param threadCount
	 * @param frame
	 * @return
	 */
	private static String generateTestNGXml(String testngFileName, String platformName, String browserName,
			String browserVersion, String parallelMode, String threadCount, JFrame frame) {
		String testNGFilePath = null;
		// collecting data for generating the TestNG XML file
		testNGFilePath = TestSuiteExecutorCore.testSuiteGenerator(testDataPath, testngFileName, platformName,
				browserName, browserVersion, parallelMode, threadCount);
		JOptionPane.showMessageDialog(frame, "Run configuration " + testngFileName + ".xml is saved successfully");
		generatedXMLFiles.add(testngFileName + ".xml");
		testNGFilesComboBox.addItem(testngFileName + ".xml");
		testNGFilesComboBox.setSelectedItem(testngFileName + ".xml");
		return testNGFilePath;
	}

	/**
	 * Method to execute the TestNG XML file
	 * 
	 * @author sanoj.swaminathan
	 * @since 06-09-2024
	 * @throws IOException
	 */
	private static void executeTestCases() throws IOException {
		try {
			int selectedIndex = testNGFilesComboBox.getSelectedIndex();
			if (selectedIndex >= 0 && selectedIndex < generatedXMLFiles.size()) {
				String selectedXmlFile = generatedXMLFiles.get(selectedIndex);
				String userDir = System.getProperty("user.dir");
				String folderPath = userDir + TestSuiteExecutorCore.testRunnersPath;
				String xmlFilePath = folderPath + "/" + selectedXmlFile;
				TestSuiteExecutorCore.executeTestNGSuite(xmlFilePath);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
