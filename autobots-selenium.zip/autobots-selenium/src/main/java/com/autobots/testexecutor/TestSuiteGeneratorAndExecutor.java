package com.autobots.testexecutor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.TestNG;
import org.testng.annotations.Test;
import org.testng.xml.XmlSuite;

import com.autobots.exception.AutomationException;
import com.autobots.keywords.DataHandler;
import com.autobots.reporting.AutomationReport;
import com.autobots.utils.AutomationConstants;

/**
 * This class helps to generate the testng xml file based on the data input from
 * the TestData.xlsx file and execute that generated XML file.
 */
public class TestSuiteGeneratorAndExecutor {

	static String testDataPath = System.getProperty("testDataPath") == null
			? getProperty("automation_test_config", "testDataPath")
			: System.getProperty("testDataPath");
	static String platformOrModule = System.getProperty("platformOrModule") == null
			? getProperty("automation_test_config", "platformOrModule")
			: System.getProperty("platformOrModule");

	@Test
	public void testSuiteGeneratorExecutor() throws AutomationException {
		String testNGFilePath = testSuiteGenerator(testDataPath, platformOrModule);
		executeTestNGSuite(testNGFilePath);
	}

	/**
	 * Method to generate the testng suite file for execution. platformOrModule can
	 * be comma separated. platformOrModule referred to the sheet names.
	 * 
	 * @author sanoj.swaminathan
	 * @since 10-05-2024
	 * @return
	 * @throws AutomationException
	 */
	public static String testSuiteGenerator(String excelFilePath, String platformOrModule) throws AutomationException {
		String testNGSuiteName = null;
		try {
			testNGSuiteName = System.getProperty("user.dir") + "/test_executor.xml";
			String testExecutorExcelFilePath = System.getProperty("user.dir") + excelFilePath.trim();
			Workbook workbook = new XSSFWorkbook(testExecutorExcelFilePath);

			// Split platformOrModule into individual sheet names
			String[] sheetNames = platformOrModule.split(",");

			// Initialize XML content
			String executionEnvironment = new DataHandler().getPropertyFromFilePath(
					AutomationConstants.AUTOMATION_TEST_CONFIG_FILE_PATH, AutomationConstants.EXECUTION_ENVIRONMENT);

			StringBuilder xmlContent = new StringBuilder();
			xmlContent.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
			xmlContent.append("<!DOCTYPE suite SYSTEM \"http://testng.org/testng-1.0.dtd\">\n");
			xmlContent.append(
					"<suite name=\"Test_Suite\" preserve-order=\"true\" verbose=\"5\" parallel=\"methods\" thread-count=\"1\">\n");
			if (executionEnvironment.equalsIgnoreCase("local")) {
				xmlContent.append("\t<parameter name=\"platformName\" value=\"\" />\n");
			} else {
				xmlContent.append("\t<parameter name=\"platformName\" value=\"Windows 10\" />\n");
			}
			xmlContent.append("\t<parameter name=\"browserName\" value=\"chrome\" />\n");
			xmlContent.append("\t<parameter name=\"browserVersion\" value=\"latest\" />\n");
			xmlContent.append("\t<parameter name=\"gridIP\" value=\"\" />\n");
			xmlContent.append("\t<parameter name=\"gridPort\" value=\"\" />\n");

			xmlContent.append("\t<listeners>\n");
			List<Class<?>> classes = new ArrayList<>();
			classes.add(AutomationReport.class);
			String reportSuiteName = null;
			for (Class<?> clazz : classes) {
				reportSuiteName = clazz.getPackage().getName() + "." + clazz.getSimpleName();
				xmlContent.append("\t\t<listener class-name=\"" + reportSuiteName + "\" />\n");
			}
			xmlContent.append("\t</listeners>\n");
			xmlContent.append("\n\t<test verbose=\"2\" name=\"TestScripts\">\n");

			Map<String, Set<String>> suiteMethodsMap = new HashMap<>();
			Map<String, Set<String>> suiteClassesMap = new HashMap<>();

			if (platformOrModule.equalsIgnoreCase("all")) {
				// Iterate over all sheets in the workbook
				for (int sheetIndex = 0; sheetIndex < workbook.getNumberOfSheets(); sheetIndex++) {
					Sheet sheet = workbook.getSheetAt(sheetIndex);
					for (int i = 1; i < getNonEmptyRowCount(sheet); i++) {
						Row row = sheet.getRow(i);

						String suiteName = getCellStringValue(row, 0); // Test Suite Name
						String testMethods = getCellStringValue(row, 1); // Test Methods
						String testGroups = getCellStringValue(row, 2); // Test Groups
						String needToExecute = getCellStringValue(row, 3); // Need to Execute

						if (needToExecute.equalsIgnoreCase("")) {
							needToExecute = "Yes";
						}
						if (needToExecute.equalsIgnoreCase("Yes")) {
							suiteMethodsMap.putIfAbsent(suiteName, new HashSet<>());
							suiteMethodsMap.get(suiteName).addAll(Set.of(testMethods.split(",")));
							suiteClassesMap.putIfAbsent(suiteName, new HashSet<>());
							suiteClassesMap.get(suiteName);
						}
					}
				}
			} else {
				// Process each specified sheet
				for (String sheetName : sheetNames) {
					Sheet sheet = workbook.getSheet(sheetName.trim());
					if (sheet == null) {
						System.err.println("Sheet '" + sheetName.trim() + "' not found in the workbook.");
						continue;
					}

					for (int i = 1; i < getNonEmptyRowCount(sheet); i++) {
						Row row = sheet.getRow(i);

						String suiteName = getCellStringValue(row, 0);// Test Suite Name
						String testMethods = getCellStringValue(row, 1);// Test Methods
						String testGroups = getCellStringValue(row, 2);// Test Groups
						String needToExecute = getCellStringValue(row, 3);// Need to Execute

						if (needToExecute.equalsIgnoreCase("")) {
							needToExecute = "Yes";
						}
						if (needToExecute.equalsIgnoreCase("Yes")) {
							suiteMethodsMap.putIfAbsent(suiteName, new HashSet<>());
							suiteMethodsMap.get(suiteName).addAll(Set.of(testMethods.split(",")));
							suiteClassesMap.putIfAbsent(suiteName, new HashSet<>());
							suiteClassesMap.get(suiteName);
						}
					}
				}
			}
			// Generate XML based on collected data
			xmlContent.append("\t<classes>\n");
			for (String suite : suiteMethodsMap.keySet()) {
				xmlContent.append("\t\t<class name=\"" + suite + "\">\n");
				xmlContent.append("\t\t\t<methods>\n");
				for (String method : suiteMethodsMap.get(suite)) {
					xmlContent.append("\t\t\t\t<include name=\"" + method.trim() + "\" />\n");
				}
				xmlContent.append("\t\t\t</methods>\n");
				xmlContent.append("\t\t</class>\n");
			}
			xmlContent.append("\t</classes>\n");
			xmlContent.append("\t</test>\n");
			xmlContent.append("</suite>");

			// Write XML testng XML file
			try (FileOutputStream fos = new FileOutputStream(testNGSuiteName)) {
				fos.write(xmlContent.toString().getBytes());
				System.out.println(testNGSuiteName + " generated successfully!");
			} catch (IOException e) {
			}

			workbook.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return testNGSuiteName;
	}

	/**
	 * Method to update the Test Results in the Excel file
	 * 
	 * @author sanoj.swaminathan
	 * @since 26-06-2024
	 * @param testCase
	 * @param status
	 */
	public static void updateTestResultsToExcel(String testCase, String status) {
		boolean testCaseFound = false;
		String filePath = System.getProperty("user.dir") + testDataPath;

		try (FileInputStream fileInputStream = new FileInputStream(filePath);
				Workbook workbook = WorkbookFactory.create(fileInputStream)) {

			ZipSecureFile.setMinInflateRatio(-1.0d);
			CellStyle passedStyle = createCellStyle(workbook, HSSFColorPredefined.GREEN);
			CellStyle failedStyle = createCellStyle(workbook, HSSFColorPredefined.RED);
			CellStyle skippedStyle = createCellStyle(workbook, HSSFColorPredefined.BROWN);

			if (platformOrModule.equalsIgnoreCase("all")) {
				testCaseFound = updateSheetStatus(workbook, testCase, status, passedStyle, failedStyle, skippedStyle);
			} else {
				String[] sheetNames = platformOrModule.split(",");
				for (String sheetName : sheetNames) {
					testCaseFound = updateSheetStatus(workbook, workbook.getSheet(sheetName.trim()), testCase, status,
							passedStyle, failedStyle, skippedStyle);
					if (testCaseFound)
						break;
				}
			}

			if (!testCaseFound) {
				System.out.println("Test case '" + testCase + "' not found in the Excel file.");
			}

			// Write the updated data to the Excel file
			try (FileOutputStream fileOutputStream = new FileOutputStream(filePath)) {
				workbook.write(fileOutputStream);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to create cell style
	 * 
	 * @author sanoj.swaminathan
	 * @since 19-09-2024
	 * @param workbook
	 * @param color
	 * @return
	 */
	private static CellStyle createCellStyle(Workbook workbook, HSSFColorPredefined color) {
		CellStyle style = workbook.createCellStyle();
		Font font = workbook.createFont();
		font.setBold(true);
		font.setColor(color.getIndex());
		style.setFont(font);
		return style;
	}

	/**
	 * Method to update the sheet status if selected all modules
	 * 
	 * @author sanoj.swaminathan
	 * @since 19-09-2024
	 * @param workbook
	 * @param testCase
	 * @param status
	 * @param passedStyle
	 * @param failedStyle
	 * @param skippedStyle
	 * @return
	 */
	private static boolean updateSheetStatus(Workbook workbook, String testCase, String status, CellStyle passedStyle,
			CellStyle failedStyle, CellStyle skippedStyle) {
		for (int sheetIndex = 0; sheetIndex < workbook.getNumberOfSheets(); sheetIndex++) {
			if (updateSheetStatus(workbook, workbook.getSheetAt(sheetIndex), testCase, status, passedStyle, failedStyle,
					skippedStyle)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Method to update sheet status for the selected modules
	 * 
	 * @author sanoj.swaminathan
	 * @since 19-09-2024
	 * @param workbook
	 * @param sheet
	 * @param testCase
	 * @param status
	 * @param passedStyle
	 * @param failedStyle
	 * @param skippedStyle
	 * @return
	 */
	private static boolean updateSheetStatus(Workbook workbook, Sheet sheet, String testCase, String status,
			CellStyle passedStyle, CellStyle failedStyle, CellStyle skippedStyle) {
		for (Row row : sheet) {
			Cell testIDCell = row.getCell(1);
			Cell needToExecute = row.getCell(3);

			// Skip header row
			if (testIDCell != null && testIDCell.getStringCellValue().trim().equals("TestID")) {
				continue;
			}

			if (testIDCell != null && needToExecute != null
					&& needToExecute.getStringCellValue().trim().equals("Yes")) {
				String testID = testIDCell.getStringCellValue().trim();
				if (testID.equals(testCase.trim())) {
					Cell statusCell = row.createCell(4);
					switch (status.toUpperCase()) {
					case "PASSED":
						statusCell.setCellStyle(passedStyle);
						break;
					case "FAILED":
						statusCell.setCellStyle(failedStyle);
						break;
					case "SKIPPED":
						statusCell.setCellStyle(skippedStyle);
						break;
					}
					statusCell.setCellValue(status);
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Method to get the non empty row count
	 * 
	 * @author sanoj.swaminathan
	 * @since 10-05-2024
	 * @param sheet
	 * @return
	 */
	private static int getNonEmptyRowCount(Sheet sheet) {
		int rowCount = 0;

		for (Row row : sheet) {
			if (row != null && !isRowEmpty(row)) {
				rowCount++;
			}
		}
		return rowCount;
	}

	/**
	 * Method to check if the row is empty
	 * 
	 * @author sanoj.swaminathan
	 * @since 10-05-2024
	 * @param row
	 * @return
	 */
	private static boolean isRowEmpty(Row row) {
		for (Cell cell : row) {
			if (cell != null) {
				if (cell.getCellType() == CellType.STRING && !cell.getStringCellValue().trim().isEmpty()) {
					return false;
				}
			}
		}
		return true;
	}

	/**
	 * Method to get the cell value as String
	 * 
	 * @author sanoj.swaminathan
	 * @since 17-05-2024
	 * @param row
	 * @param cellIndex
	 * @return
	 */
	private static String getCellStringValue(Row row, int cellIndex) {
		Cell cell = row.getCell(cellIndex);
		if (cell != null) {
			return cell.getStringCellValue().trim();
		}
		return null;
	}

	/**
	 * Method to execute the testng suite XML file
	 * 
	 * @author sanoj.swaminathan
	 * @since 10-05-2024
	 * @param suiteXmlPath
	 */
	public static void executeTestNGSuite(String suiteXmlPath) {
		TestNG testNG = new TestNG();
		List<XmlSuite> suites = new ArrayList<>();
		XmlSuite suite = new XmlSuite();
		suite.setSuiteFiles(Collections.singletonList(new File(suiteXmlPath).getAbsolutePath()));
		suites.add(suite);
		testNG.setXmlSuites(suites);
		testNG.run();
	}

	/***
	 * Method to get the property value
	 * 
	 * @author sanoj.swaminathan
	 * @since 28-06-2024
	 * @param fileName
	 * @param propertyName
	 * @return
	 */
	private static String getProperty(String fileName, String propertyName) {
		String propValue = "";
		try {
			Properties props = new Properties();
			ClassLoader classLoader = DataHandler.class.getClassLoader();
			InputStream input = classLoader.getResourceAsStream(fileName + ".properties");
			props.load(input);
			propValue = props.getProperty(propertyName);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return propValue;
	}
}
