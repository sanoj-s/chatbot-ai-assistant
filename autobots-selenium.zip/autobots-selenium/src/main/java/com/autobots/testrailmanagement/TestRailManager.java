package com.autobots.testrailmanagement;

import java.util.HashMap;
import java.util.Map;

import com.autobots.keywords.DataHandler;
import com.autobots.utils.AutomationConstants;

public class TestRailManager {

	/**
	 * Method to update the test results in TestRail
	 * 
	 * @author sanoj.swaminathan
	 * @since 23-01-2024
	 * @param testCaseID
	 * @param testCaseStatus
	 * @param error
	 */
	public static void addResultsForTestCase(int testCaseID, String testCaseStatus, String error) {
		try {
			String testrailBaseUrl = new DataHandler().getProperty(AutomationConstants.TEST_RAIL_CONFIG,
					"testrailBaseUrl");
			String testrailUserName = new DataHandler().getProperty(AutomationConstants.TEST_RAIL_CONFIG,
					"testrailUsername");
			String testrailPassword = new DataHandler().getProperty(AutomationConstants.TEST_RAIL_CONFIG,
					"testrailPassword");
			String testRunId = new DataHandler().getProperty(AutomationConstants.TEST_RAIL_CONFIG, "testRunId");

			APIClient _client = new APIClient(testrailBaseUrl);
			_client.setUser(testrailUserName);
			_client.setPassword(testrailPassword);

			Map<String, Object> data = new HashMap<String, Object>();
			data.put("status_id", testCaseStatus);
			data.put("comment", "test is executed. " + error);
			_client.sendPost("add_result_for_case/" + testRunId + "/" + testCaseID, data);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}