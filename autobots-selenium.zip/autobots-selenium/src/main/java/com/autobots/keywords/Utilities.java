package com.autobots.keywords;

import static org.openqa.selenium.support.locators.RelativeLocator.with;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.security.SecureRandom;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.imageio.ImageIO;

import org.apache.commons.codec.binary.Base32;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.autobots.base.AutomationBase;
import com.autobots.exception.AutomationException;
import com.autobots.utils.AccessibilityHandler;
import com.autobots.utils.AutomationConstants;
import com.autobots.utils.GmailUtilitiesIMAPS;
import com.autobots.utils.Log;
import com.autobots.utils.ScreenRecording;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.Result;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;

import de.taimos.totp.TOTP;

public class Utilities extends AutomationBase {

	public WebDriverWait wait;
	public Random random;
	DataHandler dataHandler = new DataHandler();

	/**
	 * Method to wait for WebElement
	 * 
	 * @author sanoj.swaminathan
	 * @since 02-03-2023
	 * @param driver
	 * @param elementName
	 * @return
	 * @throws AutomationException
	 */
	public WebElement waitForElement(WebDriver driver, String elementName) throws AutomationException {
		WebElement element = null;
		boolean status = false;
		int pollingTime = 5;
		long maxElementWaitTime = Long
				.parseLong(dataHandler.getProperty(AutomationConstants.FRAMEWORK_CONFIG, "ELEMENT_WAIT"));
		if (maxElementWaitTime < 5) {
			pollingTime = 1;
		} else {
			maxElementWaitTime = Math.round(maxElementWaitTime / 2);
		}
		Wait<WebDriver> wait = new FluentWait<>(driver).withTimeout(Duration.ofSeconds(maxElementWaitTime))
				.pollingEvery(Duration.ofSeconds(pollingTime)).ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);
		By actualElement = getElementByLocator(elementName);
		try {
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(actualElement));
			if (element == null) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(actualElement));
			}
			status = true;
		} catch (Exception ex) {
			try {
				element = wait.until(ExpectedConditions.presenceOfElementLocated(actualElement));
				if (element == null) {
					wait.until(ExpectedConditions.presenceOfElementLocated(actualElement));
				}
				status = true;
			} catch (Exception e) {
				try {
					status = false;
				} catch (Exception exc) {
					status = false;
				}
			}
		}
		if (status) {
			return element;
		} else {
			return null;
		}
	}

	/**
	 * Method to wait for the element using the object mentioned in the object
	 * repository
	 * 
	 * @author sanojs
	 * @since 15-06-2023
	 * @param driver
	 * @param elementName
	 * @param waitTime
	 * @return element
	 * @throws AutomationException
	 */
	public WebElement waitForElement(WebDriver driver, String elementName, long maxElementWaitTime) throws Exception {
		WebElement element = null;
		boolean status = false;
		int pollingTime = 5;
		if (maxElementWaitTime < 5) {
			pollingTime = 1;
		} else {
			maxElementWaitTime = Math.round(maxElementWaitTime / 2);
		}
		Wait<WebDriver> wait = new FluentWait<>(driver).withTimeout(Duration.ofSeconds(maxElementWaitTime))
				.pollingEvery(Duration.ofSeconds(pollingTime)).ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);
		By actualElement = getElementByLocator(elementName);
		try {
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(actualElement));
			if (element == null) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(actualElement));
			}
			status = true;
		} catch (Exception ex) {
			try {
				element = wait.until(ExpectedConditions.presenceOfElementLocated(actualElement));
				if (element == null) {
					wait.until(ExpectedConditions.presenceOfElementLocated(actualElement));
				}
				status = true;
			} catch (Exception e) {
				try {
					status = false;
				} catch (Exception exc) {
					status = false;
				}
			}
		}
		if (status) {
			return element;
		} else {
			return null;
		}
	}

	/**
	 * Method to wait for the elements with string object value and return
	 * WebElements
	 * 
	 * @author sanoj.swaminathan
	 * @since 02-03-2023
	 * @param driver
	 * @param elementName
	 * @return
	 * @throws AutomationException
	 */
	public List<WebElement> waitForElements(WebDriver driver, String elementName) throws Exception {
		List<WebElement> elements = null;
		WebElement element = null;
		boolean status = false;
		int pollingTime = 5;
		long maxElementWaitTime = Long
				.parseLong(dataHandler.getProperty(AutomationConstants.FRAMEWORK_CONFIG, "ELEMENT_WAIT"));
		if (maxElementWaitTime < 5) {
			pollingTime = 1;
		} else {
			maxElementWaitTime = Math.round(maxElementWaitTime / 2);
		}
		Wait<WebDriver> wait = new FluentWait<>(driver).withTimeout(Duration.ofSeconds(maxElementWaitTime))
				.pollingEvery(Duration.ofSeconds(pollingTime)).ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);
		By actualElement = getElementByLocator(elementName);
		try {
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(actualElement));
			if (element == null) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(actualElement));
			}
			status = true;
		} catch (Exception ex) {
			try {
				element = wait.until(ExpectedConditions.presenceOfElementLocated(actualElement));
				if (element == null) {
					wait.until(ExpectedConditions.presenceOfElementLocated(actualElement));
				}
				status = true;
			} catch (Exception e) {
				try {
					status = false;
				} catch (Exception exc) {
					status = false;
				}
			}
		}
		if (status) {
			elements = driver.findElements(actualElement);
			return elements;
		} else {
			return null;
		}
	}

	/**
	 * Method to wait for the elements with string object value with wait time and
	 * return WebElements
	 * 
	 * @author sanoj.swaminathan
	 * @since 09-08-2024
	 * @param driver
	 * @param elementName
	 * @param maxElementWaitTime
	 * @return
	 * @throws Exception
	 */
	public List<WebElement> waitForElements(WebDriver driver, String elementName, long maxElementWaitTime)
			throws Exception {
		List<WebElement> elements = null;
		WebElement element = null;
		boolean status = false;
		int pollingTime = 5;
		if (maxElementWaitTime < 5) {
			pollingTime = 1;
		} else {
			maxElementWaitTime = Math.round(maxElementWaitTime / 2);
		}
		Wait<WebDriver> wait = new FluentWait<>(driver).withTimeout(Duration.ofSeconds(maxElementWaitTime))
				.pollingEvery(Duration.ofSeconds(pollingTime)).ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);
		By actualElement = getElementByLocator(elementName);
		try {
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(actualElement));
			if (element == null) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(actualElement));
			}
			status = true;
		} catch (Exception ex) {
			try {
				element = wait.until(ExpectedConditions.presenceOfElementLocated(actualElement));
				if (element == null) {
					wait.until(ExpectedConditions.presenceOfElementLocated(actualElement));
				}
				status = true;
			} catch (Exception e) {
				try {
					status = false;
				} catch (Exception exc) {
					status = false;
				}
			}
		}
		if (status) {
			elements = driver.findElements(actualElement);
			return elements;
		} else {
			return null;
		}
	}

	/**
	 * Method to wait for the element with string object value with wait time and
	 * return boolean
	 * 
	 * @author sanoj.swaminathan
	 * @since 09-08-2024
	 * @param driver
	 * @param elementName
	 * @param maxElementWaitTime
	 * @return
	 * @throws Exception
	 */
	public boolean waitForElement(WebDriver driver, String elementName, int maxElementWaitTime) throws Exception {
		boolean status = false;
		int pollingTime = 5;
		if (maxElementWaitTime < 5) {
			pollingTime = 1;
		} else {
			maxElementWaitTime = Math.round(maxElementWaitTime / 2);
		}
		Wait<WebDriver> wait = new FluentWait<>(driver).withTimeout(Duration.ofSeconds(maxElementWaitTime))
				.pollingEvery(Duration.ofSeconds(pollingTime)).ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);
		By actualElement = getElementByLocator(elementName);
		try {
			WebElement e = wait.until(ExpectedConditions.visibilityOfElementLocated(actualElement));
			if (e == null) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(actualElement));
			}
			status = true;
		} catch (Exception e1) {
			try {
				WebElement e = wait.until(ExpectedConditions.presenceOfElementLocated(actualElement));
				if (e == null) {
					wait.until(ExpectedConditions.presenceOfElementLocated(actualElement));
				}
				status = true;
			} catch (Exception e) {
				try {
					status = false;
				} catch (Exception e2) {
					status = false;
				}
			}
		}
		if (status) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Method to wait for the element with element value with wait time and return
	 * boolean
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-09-2024
	 * @param driver
	 * @param element
	 * @param maxElementWaitTime
	 * @return
	 * @throws Exception
	 */
	public boolean waitForElement(WebDriver driver, WebElement element, int maxElementWaitTime) throws Exception {
		boolean status = false;
		int pollingTime = 5;
		if (maxElementWaitTime < 5) {
			pollingTime = 1;
		} else {
			maxElementWaitTime = Math.round(maxElementWaitTime / 2);
		}
		Wait<WebDriver> wait = new FluentWait<>(driver).withTimeout(Duration.ofSeconds(maxElementWaitTime))
				.pollingEvery(Duration.ofSeconds(pollingTime)).ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);

		try {
			WebElement e = wait.until(ExpectedConditions.visibilityOf(element));
			if (e == null) {
				wait.until(ExpectedConditions.visibilityOf(element));
			}
			status = true;
		} catch (Exception e1) {
			try {
				List<WebElement> e = wait.until(ExpectedConditions.visibilityOfAllElements(element));
				if (e == null) {
					wait.until(ExpectedConditions.visibilityOfAllElements(element));
				}
				status = true;
			} catch (Exception e) {
				try {
					status = false;
				} catch (Exception e2) {
					status = false;
				}
			}
		}
		if (status) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Method to wait for the element with element value with wait time and return
	 * boolean
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-09-2024
	 * @param driver
	 * @param element
	 * @param maxElementWaitTime
	 * @return
	 * @throws Exception
	 */
	public boolean waitForElement(WebDriver driver, WebElement element) throws Exception {
		boolean status = false;
		int pollingTime = 5;
		long maxElementWaitTime = Long
				.parseLong(dataHandler.getProperty(AutomationConstants.FRAMEWORK_CONFIG, "ELEMENT_WAIT"));
		if (maxElementWaitTime < 5) {
			pollingTime = 1;
		} else {
			maxElementWaitTime = Math.round(maxElementWaitTime / 2);
		}
		Wait<WebDriver> wait = new FluentWait<>(driver).withTimeout(Duration.ofSeconds(maxElementWaitTime))
				.pollingEvery(Duration.ofSeconds(pollingTime)).ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);

		try {
			WebElement e = wait.until(ExpectedConditions.visibilityOf(element));
			if (e == null) {
				wait.until(ExpectedConditions.visibilityOf(element));
			}
			status = true;
		} catch (Exception e1) {
			try {
				List<WebElement> e = wait.until(ExpectedConditions.visibilityOfAllElements(element));
				if (e == null) {
					wait.until(ExpectedConditions.visibilityOfAllElements(element));
				}
				status = true;
			} catch (Exception e) {
				try {
					status = false;
				} catch (Exception e2) {
					status = false;
				}
			}
		}
		if (status) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Method to wait for the element By locator with wait time and return boolean
	 * 
	 * @author sanoj.swaminathan
	 * @since 09-08-2024
	 * @param driver
	 * @param elementLocator
	 * @param maxElementWaitTime
	 * @return
	 * @throws Exception
	 */
	public boolean waitForElementLocator(WebDriver driver, By elementLocator, int maxElementWaitTime) throws Exception {
		boolean status = false;
		int pollingTime = 5;
		if (maxElementWaitTime < 5) {
			pollingTime = 1;
		} else {
			maxElementWaitTime = Math.round(maxElementWaitTime / 2);
		}
		Wait<WebDriver> wait = new FluentWait<>(driver).withTimeout(Duration.ofSeconds(maxElementWaitTime))
				.pollingEvery(Duration.ofSeconds(pollingTime)).ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);
		try {
			WebElement e = wait.until(ExpectedConditions.visibilityOfElementLocated(elementLocator));
			if (e == null) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(elementLocator));
			}
			status = true;
		} catch (Exception e1) {
			try {
				WebElement e = wait.until(ExpectedConditions.presenceOfElementLocated(elementLocator));
				if (e == null) {
					wait.until(ExpectedConditions.presenceOfElementLocated(elementLocator));
				}
				status = true;
			} catch (Exception e) {
				try {
					status = false;
				} catch (Exception e2) {
					status = false;
				}
			}
		}
		if (status) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Method to wait for the element By locator and return boolean
	 * 
	 * @author sanoj.swaminathan
	 * @since 02-03-2023
	 * @param driver
	 * @param elementLocator
	 * @return element
	 * @throws AutomationException
	 */
	public boolean waitForElement(WebDriver driver, By elementLocator) throws AutomationException {
		boolean status = false;
		int pollingTime = 5;
		long maxElementWaitTime = Long
				.parseLong(dataHandler.getProperty(AutomationConstants.FRAMEWORK_CONFIG, "ELEMENT_WAIT"));
		if (maxElementWaitTime < 5) {
			pollingTime = 1;
		} else {
			maxElementWaitTime = Math.round(maxElementWaitTime / 2);
		}
		Wait<WebDriver> wait = new FluentWait<>(driver).withTimeout(Duration.ofSeconds(maxElementWaitTime))
				.pollingEvery(Duration.ofSeconds(pollingTime)).ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);
		try {
			WebElement e = wait.until(ExpectedConditions.visibilityOfElementLocated(elementLocator));
			if (e == null) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(elementLocator));
			}
			status = true;
		} catch (Exception e1) {
			try {
				WebElement e = wait.until(ExpectedConditions.presenceOfElementLocated(elementLocator));
				if (e == null) {
					wait.until(ExpectedConditions.presenceOfElementLocated(elementLocator));
				}
				status = true;
			} catch (Exception e) {
				try {
					status = false;
				} catch (Exception e2) {
					status = false;
				}
			}
		}
		if (status) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Method to wait for the element By locator and return WebElement
	 * 
	 * @author sanoj.swaminathan
	 * @since 09-08-2024
	 * @param driver
	 * @param elementLocator
	 * @return
	 * @throws AutomationException
	 */
	public WebElement waitForElementLocator(WebDriver driver, By elementLocator) throws AutomationException {
		WebElement element = null;
		boolean status = false;
		int pollingTime = 5;
		long maxElementWaitTime = Long
				.parseLong(dataHandler.getProperty(AutomationConstants.FRAMEWORK_CONFIG, "ELEMENT_WAIT"));
		if (maxElementWaitTime < 5) {
			pollingTime = 1;
		} else {
			maxElementWaitTime = Math.round(maxElementWaitTime / 2);
		}
		Wait<WebDriver> wait = new FluentWait<>(driver).withTimeout(Duration.ofSeconds(maxElementWaitTime))
				.pollingEvery(Duration.ofSeconds(pollingTime)).ignoring(NoSuchElementException.class)
				.ignoring(StaleElementReferenceException.class);
		try {
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(elementLocator));
			if (element == null) {
				wait.until(ExpectedConditions.visibilityOfElementLocated(elementLocator));
			}
			status = true;
		} catch (Exception exc) {
			try {
				element = wait.until(ExpectedConditions.presenceOfElementLocated(elementLocator));
				if (element == null) {
					wait.until(ExpectedConditions.presenceOfElementLocated(elementLocator));
				}
				status = true;
			} catch (Exception e) {
				try {
					status = false;
				} catch (Exception ex) {
					status = false;
				}
			}
		}
		if (status) {
			return element;
		} else {
			return null;
		}
	}

	/**
	 * Method to Wait for the element's text to be present
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2020
	 * @param driver
	 * @param elementKey
	 * @return element
	 * @throws AutomationException
	 */
	public boolean waitForTextPresent(WebDriver driver, String elementName, String expectedText)
			throws AutomationException {
		boolean isTextPresent = false;
		try {
			long timeout = Long
					.parseLong(dataHandler.getProperty(AutomationConstants.FRAMEWORK_CONFIG, "ELEMENT_WAIT"));
			wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
			By actualElement = getElementByLocator(elementName);
			isTextPresent = wait.until(ExpectedConditions.textToBePresentInElementLocated(actualElement, expectedText));
			Log.message(driver, "Text " + expectedText + " is present");
		} catch (Exception e) {
			Log.exception(e);
		}
		return isTextPresent;
	}

	/**
	 * Method to wait for the checkbox selected
	 * 
	 * @author sanoj.swaminathan
	 * @since 05/18/2021
	 * @param driver
	 * @param elementName
	 * @return
	 * @throws AutomationException
	 */
	public boolean waitForCheckboxSelected(WebDriver driver, String elementName) throws AutomationException {
		boolean isCheckboxSelected = false;
		try {
			if (driver != null) {
				WebElement element = waitForElement(driver, elementName);
				if (element != null) {
					if (element.getAttribute("checked") != null) {
						if (element.getAttribute("checked").equals("true")) {
							isCheckboxSelected = true;
							Log.info("Checkbox is selected");
						}
					} else {
						isCheckboxSelected = false;
					}
				}
			}
		} catch (Exception e) {
			isCheckboxSelected = false;
		}
		return isCheckboxSelected;
	}

	/**
	 * Method to wait for the checkbox selected
	 * 
	 * @author sanoj.swaminathan
	 * @since 12-08-2024
	 * @param driver
	 * @param element
	 * @return
	 * @throws AutomationException
	 */
	public boolean waitForCheckboxSelected(WebDriver driver, WebElement element) throws AutomationException {
		boolean isCheckboxSelected = false;
		try {
			if (driver != null) {
				if (element != null) {
					if (element.getAttribute("checked") != null) {
						if (element.getAttribute("checked").equals("true")) {
							isCheckboxSelected = true;
							Log.info("Checkbox is selected");
						}
					} else {
						isCheckboxSelected = false;
					}
				}
			}
		} catch (Exception e) {
			isCheckboxSelected = false;
		}
		return isCheckboxSelected;
	}

	/**
	 * Method to wait for the page to load completely
	 * 
	 * @author sanoj.swaminathan
	 * @since 01-03-2024
	 * @param driver
	 * @throws NumberFormatException
	 * @throws Exception
	 */
	public void waitForPageLoadComplete(WebDriver driver) throws NumberFormatException, Exception {
		try {
			ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
				public Boolean apply(WebDriver driver) {
					return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
				}
			};
			long timeout = Long
					.parseLong(dataHandler.getProperty(AutomationConstants.FRAMEWORK_CONFIG, "ELEMENT_WAIT"));
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
			wait.until(pageLoadCondition);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to wait for all elements loaded in the DOM of web application based on
	 * given wait time.
	 * 
	 * @author sanoj.swaminathan
	 * @since 26-06-2023
	 * @param driver
	 * @param elementName
	 * @param waitTime
	 * @return element
	 * @throws AutomationException
	 */
	public List<WebElement> waitForAllElementsLoaded(WebDriver driver, long waitTime) throws AutomationException {
		List<WebElement> element = null;
		try {
			wait = new WebDriverWait(driver, Duration.ofSeconds(waitTime));
			element = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("*")));
		} catch (Exception e) {
			Log.exception(e);
		}
		return element;
	}

	/**
	 * Method to wait for all elements loaded in the DOM of web application.
	 * 
	 * @author sanoj.swaminathan
	 * @since 27-06-2023
	 * @param driver
	 * @param elementName
	 * @param waitTime
	 * @return element
	 * @throws AutomationException
	 */
	public List<WebElement> waitForAllElementsLoaded(WebDriver driver) throws AutomationException {
		List<WebElement> element = null;
		try {
			long timeout = Long
					.parseLong(dataHandler.getProperty(AutomationConstants.FRAMEWORK_CONFIG, "ELEMENT_WAIT"));
			wait = new WebDriverWait(driver, Duration.ofSeconds(timeout));
			element = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("*")));
		} catch (Exception e) {
			Log.exception(e);
		}
		return element;
	}

	/**
	 * Method to wait for the file download
	 * 
	 * @author sanoj.swaminathan
	 * @since 19-08-2022
	 * @param downloadPath
	 * @param fileName
	 * @return
	 * @throws AutomationException
	 */
	public boolean waitForFileDownload(String downloadPath, String fileName) throws AutomationException {
		File dir = new File(downloadPath);
		File[] dirContents = dir.listFiles();
		for (int i = 0; i < dirContents.length; i++) {
			if (dirContents[i].getName().contains(fileName)) {
				dirContents[i].delete();
				return true;
			}
		}
		Log.message(fileName + " is downloaded to " + downloadPath);
		return false;
	}

	/**
	 * Get the web element based on RelativeLocator direction
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-12-2021
	 * @param driver
	 * @param tagName
	 * @param direction
	 * @param element
	 * @return
	 * @throws AutomationException
	 */
	public WebElement getRelativeElement(WebDriver driver, String tagName, String direction, WebElement element)
			throws AutomationException {
		WebElement elementToDoAction = null;
		try {
			switch (direction) {
			case "left":
				elementToDoAction = driver.findElement(with(By.tagName(tagName)).toLeftOf(element));
				break;
			case "right":
				elementToDoAction = driver.findElement(with(By.tagName(tagName)).toRightOf(element));
				break;
			case "above":
				elementToDoAction = driver.findElement(with(By.tagName(tagName)).above(element));
				break;
			case "below":
				elementToDoAction = driver.findElement(with(By.tagName(tagName)).below(element));
				break;
			case "near":
				elementToDoAction = driver.findElement(with(By.tagName(tagName)).near(element));
				break;
			}
			Log.message(driver, elementToDoAction + " is " + direction + " of " + element);
		} catch (Exception lException) {
			Log.exception(lException);
		}
		return elementToDoAction;
	}

	/**
	 * To get the By locator
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2020
	 * @param elementName
	 * @return
	 * @throws AutomationException
	 */
	public By getElementByLocator(String elementName) throws AutomationException {
		By byElement = null;
		try {
			if (elementName.startsWith("#") || elementName.startsWith("td[") || elementName.startsWith("tr[")
					|| elementName.startsWith("td ") || elementName.startsWith("tr ")
					|| elementName.startsWith("input[") || elementName.startsWith("span[")
					|| elementName.startsWith("div")) {
				byElement = By.cssSelector(elementName);
			} else if (elementName.startsWith("//") || elementName.startsWith(".//") || elementName.startsWith("(//")
					|| elementName.startsWith("(.//")) {
				byElement = By.xpath(elementName);
			} else if (elementName.startsWith("name")) {
				byElement = By.name(elementName.split(">>")[1]);
			} else if (elementName.startsWith("id")) {
				byElement = By.id(elementName.split(">>")[1]);
			} else if (elementName.startsWith("className")) {
				byElement = By.className(elementName.split(">>")[1]);
			} else if (elementName.startsWith("linkText")) {
				byElement = By.linkText(elementName.split(">>")[1]);
			} else if (elementName.startsWith("partialLinkText")) {
				byElement = By.partialLinkText(elementName.split(">>")[1]);
			} else {
				byElement = By.tagName(elementName);
			}
		} catch (Exception e) {
			Log.exception(e);
		}
		return byElement;
	}

	/**
	 * Set delay between test steps
	 * 
	 * @author sanojs
	 * @since 20-04-2021
	 * @param driver
	 * @param delayInSeconds
	 * @throws AutomationException
	 */
	public void delay(int delayInSeconds) throws AutomationException {
		try {
			Thread.sleep(delayInSeconds * 1000);
		} catch (Exception lException) {
			Log.exception(lException);
		}
	}

	/**
	 * Method to drag and drop an element from source to destination
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2020
	 * @param driver
	 * @param sourceElementName
	 * @param destinationElementName
	 * @return element
	 * @throws AutomationException
	 */
	public void dragAndDrop(WebDriver driver, String sourceElementName, String destinationElementName)
			throws AutomationException {
		try {
			WebElement sourceElement = waitForElement(driver, sourceElementName);
			WebElement destinationElement = waitForElement(driver, destinationElementName);
			Actions action = new Actions(driver);
			action.clickAndHold(sourceElement).build().perform();
			Thread.sleep(1000);
			action.moveToElement(destinationElement).build().perform();
			Thread.sleep(1000);
			action.moveByOffset(-1, -1).build().perform();
			Thread.sleep(1000);
			action.release().build().perform();
			Log.message(driver, sourceElementName + " is successfully dropped to " + destinationElementName);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to drag and drop an element from source to destination
	 * 
	 * @author sanoj.swaminathan
	 * @since 12-08-2024
	 * @param driver
	 * @param sourceElement
	 * @param destinationElement
	 * @throws AutomationException
	 */
	public void dragAndDrop(WebDriver driver, WebElement sourceElement, WebElement destinationElement)
			throws AutomationException {
		try {
			Actions action = new Actions(driver);
			action.clickAndHold(sourceElement).build().perform();
			delay(1);
			action.moveToElement(destinationElement).build().perform();
			delay(1);
			action.moveByOffset(-1, -1).build().perform();
			delay(1);
			action.release().build().perform();
			Log.message(driver, "Drag the element from " + sourceElement + " to " + destinationElement);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to scroll to the element
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @throws AutomationException
	 */
	public void scrollToElement(WebDriver driver, String elementName) throws AutomationException {
		try {
			WebElement element = waitForElement(driver, elementName);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
			Log.message(driver, "Successfully scroll to the " + elementName);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to scroll to the element
	 * 
	 * @author sanoj.swaminathan
	 * @since 12-08-2024
	 * @param driver
	 * @param element
	 * @throws AutomationException
	 */
	public void scrollToElement(WebDriver driver, WebElement element) throws AutomationException {
		try {
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
			Log.message(driver, "Scroll to the element " + element);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to scroll to the bottom of the web page
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @throws AutomationException
	 */
	public void scrollToBottom(WebDriver driver) throws AutomationException {
		try {
			((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
			Log.message(driver, "Successfully scroll to the bottom of the page");
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to scroll to the top of the web page
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @throws AutomationException
	 */
	public void scrollToTop(WebDriver driver) throws AutomationException {
		try {
			((JavascriptExecutor) driver).executeScript("window.scrollTo(0, 0)");
			Log.message(driver, "Successfully scroll to the top of the page");
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to move to the Web element
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @throws AutomationException
	 */
	public void moveToElement(WebDriver driver, String elementName) throws AutomationException {
		try {
			Actions actions = new Actions(driver);
			WebElement element = waitForElement(driver, elementName);
			actions.moveToElement(element).perform();
			Log.message(driver, "Successfully move to " + elementName);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to move to the Web element
	 * 
	 * @author sanoj.swaminathan
	 * @since 12-08-2024
	 * @param driver
	 * @param element
	 * @throws AutomationException
	 */
	public void moveToElement(WebDriver driver, WebElement element) throws AutomationException {
		try {
			Actions actions = new Actions(driver);
			actions.moveToElement(element).perform();
			Log.message(driver, "Move to the element " + element);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to move to the Web element based on the provided X and Y co-ordinates
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @param xOffset
	 * @param yOffset
	 * @throws AutomationException
	 */
	public void moveToElementByXandY(WebDriver driver, String elementName, int xOffset, int yOffset)
			throws AutomationException {
		try {
			Actions actions = new Actions(driver);
			WebElement element = waitForElement(driver, elementName);
			actions.moveToElement(element, xOffset, yOffset).perform();
			Log.message(driver, "Successfully move to " + elementName + " by " + xOffset + " and " + yOffset);
		} catch (Exception e) {
			Log.exception(e);

		}
	}

	/**
	 * Method to move to the Web element based on the provided X and Y co-ordinates
	 * 
	 * @author sanoj.swaminathan
	 * @since 12-08-2024
	 * @param driver
	 * @param element
	 * @param xOffset
	 * @param yOffset
	 * @throws AutomationException
	 */
	public void moveToElementByXandY(WebDriver driver, WebElement element, int xOffset, int yOffset)
			throws AutomationException {
		try {
			Actions actions = new Actions(driver);
			actions.moveToElement(element, xOffset, yOffset).perform();
			Log.message(driver, "Move to the element by " + xOffset + "," + yOffset);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to get the attribute value of the web element
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @param attributeName
	 * @throws AutomationException
	 */
	public String getElementAttributeValue(WebDriver driver, String elementName, String attributeName)
			throws AutomationException {
		String elementAttribute = "";
		try {
			WebElement element = waitForElement(driver, elementName);
			elementAttribute = element.getAttribute(attributeName);
			Log.message(driver, "Successfully get the attribute" + elementAttribute);
		} catch (Exception e) {
			Log.exception(e);
		}
		return elementAttribute;
	}

	/**
	 * Method to get the attribute value of the web element
	 * 
	 * @author sanoj.swaminathan
	 * @since 12-08-2024
	 * @param driver
	 * @param element
	 * @param attributeName
	 * @return
	 * @throws AutomationException
	 */
	public String getElementAttributeValue(WebDriver driver, WebElement element, String attributeName)
			throws AutomationException {
		String elementAttribute = "";
		try {
			elementAttribute = element.getAttribute(attributeName);
			Log.message(driver, "Attribute value " + elementAttribute);
		} catch (Exception e) {
			Log.exception(e);
		}
		return elementAttribute;
	}

	/**
	 * Method to select the value from the drop down using the visible text
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @param visibleText
	 * @throws AutomationException
	 */
	public void selectDropDownValueByVisibleText(WebDriver driver, String elementName, String visibleText)
			throws AutomationException {
		try {
			Select select = new Select(waitForElement(driver, elementName));
			select.selectByVisibleText(visibleText);
			Log.message(driver, visibleText + " is selected");
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to select the value from the drop down using the visible text
	 * 
	 * @author sanoj.swaminathan
	 * @since 12-08-2024
	 * @param driver
	 * @param element
	 * @param visibleText
	 * @throws AutomationException
	 */
	public void selectDropDownValueByVisibleText(WebDriver driver, WebElement element, String visibleText)
			throws AutomationException {
		try {
			Select select = new Select(element);
			select.selectByVisibleText(visibleText);
			Log.message(driver, visibleText + " is selected successfully");
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to select the value from the drop down using the index
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @param index
	 * @throws AutomationException
	 */
	public void selectDropDownValueByIndex(WebDriver driver, String elementName, int index) throws AutomationException {
		try {
			Select select = new Select(waitForElement(driver, elementName));
			select.selectByIndex(index);
			Log.message(driver, "The value selected at " + index + " on " + elementName);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to select the value from the drop down using the index
	 * 
	 * @author sanoj.swaminathan
	 * @since 12-08-2024
	 * @param driver
	 * @param element
	 * @param index
	 * @throws AutomationException
	 */
	public void selectDropDownValueByIndex(WebDriver driver, WebElement element, int index) throws AutomationException {
		try {
			Select select = new Select(element);
			select.selectByIndex(index);
			Log.message(driver, "Value successfully selected at " + index);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to select the value from the drop down using value
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @param valueToSelect
	 * @throws AutomationException
	 */
	public void selectDropDownValueByValue(WebDriver driver, String elementName, String valueToSelect)
			throws AutomationException {
		try {
			Select select = new Select(waitForElement(driver, elementName));
			select.selectByValue(valueToSelect);
			Log.message(driver, "The value " + valueToSelect + " selected at " + elementName);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to select the value from the drop down using value
	 * 
	 * @author sanoj.swaminathan
	 * @since 12-08-2024
	 * @param driver
	 * @param element
	 * @param valueToSelect
	 * @throws AutomationException
	 */
	public void selectDropDownValueByValue(WebDriver driver, WebElement element, String valueToSelect)
			throws AutomationException {
		try {
			Select select = new Select(element);
			select.selectByValue(valueToSelect);
			Log.message(driver, valueToSelect + " successfully selected");
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method deselect the selected value from the dropdown based on index passed
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param elementName
	 * @param index
	 * @throws AutomationException
	 * 
	 */
	public void deselectElementByIndex(final WebDriver driver, final String elementName, final int index)
			throws AutomationException {
		try {
			if (driver != null) {
				WebElement element = waitForElement(driver, elementName);
				if (element != null) {
					final Select listbox = new Select(element);
					listbox.deselectByIndex(index);
					Log.message(driver, "Deselected at " + index);
				} else {
					throw new AutomationException(AutomationConstants.OBJECT_NOT_FOUND + "'" + elementName + "'");
				}
			}
		} catch (final Exception lException) {
			Log.exception(lException);
		}
	}

	/**
	 * Method deselect the selected value from the dropdown based on Value passed
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param elementName
	 * @param value
	 * @throws AutomationException
	 * 
	 */

	public void deselectElementByValue(final WebDriver driver, final String elementName, final String value)
			throws AutomationException {
		try {
			if (driver != null) {
				WebElement element = waitForElement(driver, elementName);
				if (element != null) {
					final Select listbox = new Select(element);
					listbox.deselectByValue(value);
					Log.message(driver, "Deselected value " + value);
				} else {
					throw new AutomationException(AutomationConstants.OBJECT_NOT_FOUND + "'" + elementName + "'");
				}
			}
		} catch (final Exception lException) {
			Log.exception(lException);
		}
	}

	/**
	 * Method deselect the selected value from the dropdown based on visible text
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param elementName
	 * @param visibleText
	 * @throws AutomationException
	 * 
	 */

	public void deselectElementByVisibleText(final WebDriver driver, final String elementName, final String visibleText)
			throws AutomationException {
		try {
			if (driver != null) {
				WebElement element = waitForElement(driver, elementName);
				if (element != null) {
					final Select listbox = new Select(element);
					listbox.deselectByVisibleText(visibleText);
					Log.message(driver, "Deselected visible text " + visibleText);
				} else {
					throw new AutomationException(AutomationConstants.OBJECT_NOT_FOUND + "'" + elementName + "'");
				}
			}
		} catch (final Exception lException) {
			Log.exception(lException);
		}
	}

	/**
	 * Method to get the X co-ordinate of the Web element
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @throws AutomationException
	 */
	public int getXcoordinate(WebDriver driver, String elementName) throws AutomationException {
		int xcoordinate = 0;
		try {
			WebElement element = waitForElement(driver, elementName);
			Point point = element.getLocation();
			Log.message(driver, "X co-ordinate of the Web element: " + point.getX());
			xcoordinate = point.getX();

		} catch (Exception e) {
			Log.exception(e);
		}
		return xcoordinate;
	}

	/**
	 * Method to get the X co-ordinate of the element
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param element
	 * @return
	 * @throws AutomationException
	 */
	public int getXcoordinate(WebDriver driver, WebElement element) throws AutomationException {
		int xCoordinate = 0;
		try {
			Point point = element.getLocation();
			xCoordinate = point.getX();
		} catch (Exception e) {
			Log.exception(e);
		}
		return xCoordinate;
	}

	/**
	 * Method to get the Y co-ordinate of the Web element
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @throws AutomationException
	 */
	public int getYcoordinate(WebDriver driver, String elementName) throws AutomationException {
		int ycoordinate = 0;
		try {
			WebElement element = waitForElement(driver, elementName);
			Point point = element.getLocation();
			Log.message(driver, "Y co-ordinate of the Web element: " + point.getY());
			ycoordinate = point.getY();
		} catch (Exception e) {
			Log.exception(e);
		}
		return ycoordinate;
	}

	/**
	 * Method to get the Y co-ordinate of the element
	 * 
	 * @author sanoj.swaminathan
	 * @since 12-08-2024
	 * @param driver
	 * @param element
	 * @return
	 * @throws AutomationException
	 */
	public int getYcoordinate(WebDriver driver, WebElement element) throws AutomationException {
		int yCoordinate = 0;
		try {
			Point point = element.getLocation();
			yCoordinate = point.getY();
		} catch (Exception e) {
			Log.exception(e);
		}
		return yCoordinate;
	}

	/**
	 * Method to get the Count of the elements from the Web element list
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @throws AutomationException
	 */
	public int countOfElementsFromList(WebDriver driver, String elementName) throws AutomationException {
		int countOfElements = 0;
		try {
			List<WebElement> elements = waitForElements(driver, elementName);
			countOfElements = elements.size();
		} catch (Exception e) {
			Log.exception(e);
		}
		return countOfElements;
	}

	/**
	 * Method to get the Count of the elements from the Web element list
	 * 
	 * @author sanoj.swaminathan
	 * @since 12-08-2024
	 * @param driver
	 * @param elements
	 * @return
	 * @throws AutomationException
	 */
	public int countOfElementsFromList(WebDriver driver, List<WebElement> elements) throws AutomationException {
		int countOfElementsFromList = 0;
		try {
			countOfElementsFromList = elements.size();
		} catch (Exception e) {
			Log.exception(e);
		}
		return countOfElementsFromList;
	}

	/**
	 * Method to clear the input field (which is referred by the user from the
	 * Object Repository)
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @throws AutomationException
	 */
	public void clearInputField(WebDriver driver, String elementName) throws AutomationException {
		try {
			WebElement element = waitForElement(driver, elementName);
			element.clear();
			Log.message(driver, elementName + " field is cleared");
		} catch (Exception e) {
			Log.exception(e);

		}
	}

	/**
	 * Method to clear the input field
	 * 
	 * @author sanoj.swaminathan
	 * @since 12-08-2024
	 * @param driver
	 * @param element
	 * @throws AutomationException
	 */
	public void clearInputField(WebDriver driver, WebElement element) throws AutomationException {
		try {
			element.clear();
			Log.message(driver, "Edit field " + element + " is cleared");
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to delete the value from input field (which is referred by the user
	 * from the Object Repository)
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @throws AutomationException
	 */
	public void clearAllFromInputField(WebDriver driver, String elementName) throws AutomationException {
		try {
			WebElement sourceElement = waitForElement(driver, elementName);
			sourceElement.sendKeys(Keys.CONTROL + "a");
			sourceElement.sendKeys(Keys.DELETE);
			Log.message(driver, elementName + " field is cleared");
		} catch (Exception e) {
			Log.exception(e);

		}
	}

	/**
	 * Method to delete the value from input field
	 * 
	 * @author sanoj.swaminathan
	 * @since 12-08-2024
	 * @param driver
	 * @param element
	 * @throws AutomationException
	 */
	public void clearAllFromInputField(WebDriver driver, WebElement element) throws AutomationException {
		try {
			element.sendKeys(Keys.CONTROL + "a");
			element.sendKeys(Keys.DELETE);
			Log.message(driver, "Edit field " + element + " is cleared");
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to Copy and Paste the value from one input field to another input
	 * field
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param sourceElementName
	 * @param destinationElementName
	 * @throws AutomationException
	 */
	public void copyAndPasteFromOneInputFieldToAnother(WebDriver driver, String sourceElementName,
			String destinationElementName) throws AutomationException {
		try {
			WebElement sourceElement = waitForElement(driver, sourceElementName);
			sourceElement.sendKeys(Keys.CONTROL + "a");
			sourceElement.sendKeys(Keys.CONTROL + "c");

			WebElement destinationElement = waitForElement(driver, destinationElementName);
			destinationElement.clear();
			destinationElement.sendKeys(Keys.CONTROL + "v");
			Log.message(driver, "Data copy pasted from " + sourceElementName + " to " + destinationElementName);
		} catch (Exception e) {
			Log.exception(e);

		}
	}

	/**
	 * Method to get the text of the Web Element
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @param elementName
	 * @throws AutomationException
	 */
	public String getElementText(WebDriver driver, String elementName) throws AutomationException {
		String elementText = "";
		try {
			WebElement element = waitForElement(driver, elementName);
			elementText = element.getText();
			Log.message(driver, elementText + " is fetched from " + elementName);
		} catch (Exception e) {
			Log.exception(e);

		}
		return elementText;
	}

	/**
	 * Method to get the text of the Web Element
	 * 
	 * @author sanoj.swaminathan
	 * @since 12-08-2024
	 * @param driver
	 * @param element
	 * @return
	 * @throws AutomationException
	 */
	public String getElementText(WebDriver driver, WebElement element) throws AutomationException {
		String elementText = "";
		try {
			elementText = element.getText();
			Log.message(driver, "Successfully get the element text is " + elementText);
		} catch (Exception e) {
			Log.exception(e);
		}
		return elementText;
	}

	/**
	 * Method to Release the depressed left mouse button at the current mouse
	 * location
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2020
	 * @param driver
	 * @throws AutomationException
	 */
	public void releaseMouse(WebDriver driver) throws AutomationException {
		try {
			Actions actions = new Actions(driver);
			actions.release();
		} catch (Exception e) {
			Log.exception(e);

		}
	}

	/**
	 * This method is to capture screenshot and returns a byte array for visible
	 * screen
	 * 
	 * @author sanoj.swaminatthan
	 * @since 13-03-2021
	 * @param driver
	 * @return file
	 * @throws AutomationException
	 * 
	 */
	public byte[] captureScreenAsByteArray(WebDriver driver) throws AutomationException, FileNotFoundException {
		byte[] imageBytes = null;
		try {
			if (driver != null) {
				TakesScreenshot ts = (TakesScreenshot) driver;
				imageBytes = ts.getScreenshotAs(OutputType.BYTES);
			}
		} catch (Exception lException) {
			Log.exception(lException);

		}
		return imageBytes;
	}

	/**
	 * This method is to capture screenshot in the application and save it in the
	 * path that passed as parameter with mentioned image name
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-03-2021
	 * @param driver
	 * @param filePath
	 * @param imageName
	 * @throws AutomationException
	 * 
	 */
	public String captureScreenshot(WebDriver driver, String filePath, String imageName) throws AutomationException {
		String destinationFilePath = null;

		try {
			if (driver != null) {
				delay(3);
				TakesScreenshot screenShot = ((TakesScreenshot) driver);
				File sourceFile = screenShot.getScreenshotAs(OutputType.FILE);
				destinationFilePath = filePath + imageName + "_" + getCurrentDate() + ".png";
				File destinationFile = new File(destinationFilePath);
				FileUtils.copyFile(sourceFile, destinationFile);
			}
		} catch (final IOException lException) {
			Log.exception(lException);

		}
		return destinationFilePath;
	}

	/**
	 * Capture the screenshot of the current screen and store into Screenshots
	 * folder in the project structure
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2021
	 * @param driver
	 * @throws AutomationException
	 */
	public String captureScreenshot(WebDriver driver, String fileName) throws AutomationException {
		String destinationFilePath = null;
		try {
			TakesScreenshot screenShot = ((TakesScreenshot) driver);
			File sourceFile = screenShot.getScreenshotAs(OutputType.FILE);
			destinationFilePath = System.getProperty("user.dir") + "/Screenshots/" + fileName + "_" + getCurrentDate()
					+ ".jpg";
			File destinationFile = new File(destinationFilePath);
			FileUtils.copyFile(sourceFile, destinationFile);
		} catch (Exception e) {
			Log.exception(e);
		}
		return destinationFilePath;
	}

	/**
	 * Capture the screenshot of the current screen
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2021
	 * @param driver
	 * @throws AutomationException
	 */
	public String captureScreenshot(WebDriver driver) throws AutomationException {
		File sourceFile = null;
		try {
			TakesScreenshot screenShot = ((TakesScreenshot) driver);
			sourceFile = screenShot.getScreenshotAs(OutputType.FILE);
		} catch (Exception e) {
			Log.exception(e);
		}
		return sourceFile.getAbsolutePath();
	}

	/**
	 * Method to get a random number between the two ranges
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param lowerBound
	 * @param upperBound
	 * @throws AutomationException
	 */
	public int getRandomNumber(int lowerBound, int upperBound) throws AutomationException {
		int randomNumber = 0;
		try {
			random = new Random();
			int randomNum = random.nextInt(upperBound - lowerBound + 1) + lowerBound;
			randomNumber = randomNum;
		} catch (Exception e) {
			Log.exception(e);
		}
		return randomNumber;
	}

	/**
	 * Method to get a random number with the a number length mentioned
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param numberLength
	 * @throws AutomationException
	 */
	public String getRandomNumber(int numberLength) throws AutomationException {
		String randomNumber = null;
		try {
			random = new Random();
			int randomNum = 0;
			boolean loop = true;
			while (loop) {
				randomNum = random.nextInt();
				if (Integer.toString(randomNum).length() == numberLength
						&& !Integer.toString(randomNum).startsWith("-")) {
					loop = false;
				}
			}
			randomNumber = Integer.toString(randomNum);

		} catch (Exception e) {
			Log.exception(e);
		}
		return randomNumber;
	}

	/**
	 * Method to get a random string value with the string length mentioned
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param stringLength
	 * @throws AutomationException
	 */
	public String getRandomString(int stringLength) throws AutomationException {
		String randomString = null;
		try {
			String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz";
			StringBuilder sb = new StringBuilder(stringLength);
			for (int i = 0; i < stringLength; i++) {
				int index = (int) (AlphaNumericString.length() * Math.random());
				sb.append(AlphaNumericString.charAt(index));
			}
			randomString = sb.toString();
		} catch (Exception e) {
			Log.exception(e);
		}
		return randomString;
	}

	/**
	 * Method to get a random string which has only alphabets with the string length
	 * mentioned
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param stringLength
	 * @throws AutomationException
	 */
	public String getRandomStringOnlyAlphabets(int stringLength) throws AutomationException {
		String randomStringOnlyAlphabets = null;
		try {
			String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "abcdefghijklmnopqrstuvxyz";
			StringBuilder sb = new StringBuilder(stringLength);
			for (int i = 0; i < stringLength; i++) {
				int index = (int) (AlphaNumericString.length() * Math.random());
				sb.append(AlphaNumericString.charAt(index));
			}
			randomStringOnlyAlphabets = sb.toString();
		} catch (Exception e) {
			Log.exception(e);
		}
		return randomStringOnlyAlphabets;
	}

	/**
	 * Method to get the current date
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @throws AutomationException
	 */
	public String getCurrentDate() throws AutomationException {
		String currentDate = null;
		try {
			DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy_HH-mm-ss");
			Date date = new Date();
			String filePathdate = dateFormat.format(date).toString();
			currentDate = filePathdate;
		} catch (Exception e) {
			Log.exception(e);
		}
		return currentDate;
	}

	/**
	 * Method to get the current date in the date format ddMMMyyyy
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @throws AutomationException
	 */
	public String getCurrentDateInFormatddMMMyyyy() throws AutomationException {
		String currentDateInFormatddMMMyyyy = null;
		try {
			DateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
			Date date = new Date();
			String filePathdate = dateFormat.format(date).toString();
			currentDateInFormatddMMMyyyy = filePathdate;
		} catch (Exception e) {
			Log.exception(e);
		}
		return currentDateInFormatddMMMyyyy;
	}

	/**
	 * Method to get a current date in the date format ddMMyyyy
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @throws AutomationException
	 */
	public String getCurrentDateInFormatddMMyyyy() throws AutomationException {
		String currentDateInFormatddMMMyyyy = null;
		try {
			DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
			Date date = new Date();
			String filePathdate = dateFormat.format(date).toString();
			currentDateInFormatddMMMyyyy = filePathdate;
		} catch (Exception e) {
			Log.exception(e);
		}
		return currentDateInFormatddMMMyyyy;
	}

	/**
	 * Method to get the day from the current date
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @throws AutomationException
	 */
	public String getDayFromCurrentDate() throws AutomationException {
		String dayFromCurrentDate = null;
		try {
			DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy_HH-mm-ss");
			Date date = new Date();
			String filePathdate = dateFormat.format(date).toString();
			String day = filePathdate.substring(0, 2);
			dayFromCurrentDate = day;
		} catch (Exception e) {
			Log.exception(e);
		}
		return dayFromCurrentDate;
	}

	/**
	 * Method to convert a double value to an Integer
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param doubleValue
	 * @throws AutomationException
	 */
	public int convertDoubleToInt(double doubleValue) throws AutomationException {
		int doubleToInt = 0;
		try {
			int intValue = (int) doubleValue;
			doubleToInt = intValue;
		} catch (Exception e) {
			Log.exception(e);
		}
		return doubleToInt;
	}

	/**
	 * Method to convert a float value to an Integer
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param floatValue
	 * @throws AutomationException
	 */
	public int convertFloatToInt(float floatValue) throws AutomationException {
		int floatToInt = 0;
		try {
			int intValue = (int) floatValue;
			floatToInt = intValue;
		} catch (Exception e) {
			Log.exception(e);
		}
		return floatToInt;
	}

	/**
	 * Method to convert a string value to an Integer
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param stringValue
	 * @throws AutomationException
	 */
	public int convertStringToInt(String stringValue) throws AutomationException {
		int stringToInt = 0;
		try {
			int intValue = Integer.parseInt(stringValue);
			stringToInt = intValue;
		} catch (Exception e) {
			Log.exception(e);
		}
		return stringToInt;
	}

	/**
	 * Method to convert a string value to a double value
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param stringValue
	 * @throws AutomationException
	 */
	public double convertStringToDouble(String stringValue) throws AutomationException {
		double stringToDouble = 0;
		try {
			double doubleValue = Double.parseDouble(stringValue);
			stringToDouble = doubleValue;
		} catch (Exception e) {
			Log.exception(e);
		}
		return stringToDouble;
	}

	/**
	 * Method to convert an Integer to a string value
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param intValue
	 * @throws AutomationException
	 */
	public String convertIntToString(int intValue) throws AutomationException {
		String intToString = null;
		try {
			String stringValue = String.valueOf(intValue);
			intToString = stringValue;
		} catch (Exception e) {
			Log.exception(e);
		}
		return intToString;
	}

	/**
	 * Method to convert a double value to a string value
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param doubleValue
	 * @throws AutomationException
	 */
	public String convertDoubleToString(double doubleValue) throws AutomationException {
		String doubleToString = null;
		try {
			String stringValue = String.valueOf(doubleValue);
			doubleToString = stringValue;
		} catch (Exception e) {
			Log.exception(e);
		}
		return doubleToString;
	}

	/**
	 * Method to convert a string value to a long value
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param doubleValue
	 * @throws AutomationException
	 */
	public long convertStringToLong(String stringValue) throws AutomationException {
		long stringToLong = 0;
		try {
			long longValue = Long.parseLong(stringValue);
			stringToLong = longValue;

		} catch (Exception e) {
			Log.exception(e);
		}
		return stringToLong;
	}

	/**
	 * Method to encode any file data
	 * 
	 * @author sanoj.swaminathan
	 * @since 06-03-2023
	 * @param filePath
	 * @throws AutomationException
	 */
	public String encodeFile(String filePath) throws AutomationException {
		String encodedString = null;
		try {
			byte[] fileContent = FileUtils.readFileToByteArray(new File(filePath));
			encodedString = Base64.getEncoder().encodeToString(fileContent);
		} catch (Exception e) {
			Log.exception(e);
		}
		return encodedString;
	}

	/**
	 * Method to decode any string data
	 * 
	 * @author sanoj.swaminathan
	 * @since 06-03-2023
	 * @param dataToBeDecoded
	 * @throws AutomationException
	 */
	public String decodeString(String dataToBeDecoded) throws AutomationException {
		byte[] decodedString = null;
		try {
			decodedString = Base64.getDecoder().decode(dataToBeDecoded);
		} catch (Exception e) {
			Log.exception(e);

		}
		return decodedString.toString();
	}

	/**
	 * Method to delete file
	 * 
	 * @author sanoj.swaminathan
	 * @since 21-03-2023
	 * @param filePath
	 * @throws AutomationException
	 */
	public void deleteFile(String filePath) throws AutomationException {
		try {
			FileUtils.forceDelete(new File(filePath));
			Log.message(filePath + " is successfully deleted");
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to get the screen dimension
	 * 
	 * @author sanoj.swaminathan
	 * @since 19-08-20234
	 * @param driver
	 * @param secondsToWait
	 * @return
	 */
	public Dimension getScreenSize(WebDriver driver, int secondsToWait) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(secondsToWait));
		Dimension size = wait.until(new ExpectedCondition<Dimension>() {
			@Override
			public Dimension apply(WebDriver driver) {
				return driver.manage().window().getSize();
			}
		});
		return size;
	}

	/**
	 * To track the violations using AxeBuilder support as part of the Accessibility
	 * Audit
	 * 
	 * @author sanoj.swaminathan @since07-11-2023
	 * @param driver
	 * @param pageName
	 * @throws AutomationException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void startAccessibilityAudit(WebDriver driver, String pageName)
			throws AutomationException, IOException, InterruptedException {
		try {
			new AccessibilityHandler().trackViolations(driver, pageName);
			Log.message("Completed the Accessibility Audit for " + pageName);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * To track the violations using AxeBuilder support as part of the Accessibility
	 * Audit for given web application URL
	 * 
	 * @author sanoj.swaminathan
	 * @since 07-11-2023
	 * @param driver
	 * @param pageName
	 * @throws AutomationException
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void startAccessibilityAudit(WebDriver driver, String webURL, String pageName)
			throws AutomationException, IOException, InterruptedException {
		try {
			new WebActions().loadWebApplication(driver, webURL);
			new AccessibilityHandler().trackViolations(driver, pageName);
			Log.message("Completed the Accessibility Audit for " + pageName);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to get the data from the QR code. The elementName should be the QR
	 * code image locator path
	 * 
	 * @author sanoj.swaminathan
	 * @since 28-11-2023
	 * @param driver
	 * @param elementName
	 * @return
	 * @throws AutomationException
	 */
	public String getQRCodeData(WebDriver driver, String elementName) throws AutomationException {
		Result result = null;
		try {
			WebElement element = waitForElement(driver, elementName);
			String urlOfQRCode = element.getAttribute("src");
			URL url = new URL(urlOfQRCode);
			BufferedImage bufferedimage = ImageIO.read(url);
			LuminanceSource luminanceSource = new BufferedImageLuminanceSource(bufferedimage);
			BinaryBitmap binaryBitmap = new BinaryBitmap(new HybridBinarizer(luminanceSource));
			result = new MultiFormatReader().decode(binaryBitmap);
		} catch (Exception e) {
			Log.exception(e);
		}
		return result.getText();
	}

	/**
	 * Method to get the data from the given QR code image
	 * 
	 * @author sanoj.swaminathan
	 * @since 28-11-2023
	 * @param qrCodeFilePath
	 * @return
	 * @throws AutomationException
	 */
	public String getQRCodeData(String qrCodeFilePath) throws AutomationException {
		Result result = null;
		try {
			BufferedImage bufferedimage = ImageIO.read(new File(qrCodeFilePath).getAbsoluteFile());
			LuminanceSource luminanceSource = new BufferedImageLuminanceSource(bufferedimage);
			BinaryBitmap binaryBitmap = new BinaryBitmap(new HybridBinarizer(luminanceSource));
			result = new MultiFormatReader().decode(binaryBitmap);
		} catch (Exception e) {
			Log.exception(e);
		}
		return result.getText();
	}

	/**
	 * Start video recording and store it in Automation_Videos folder inside Reports
	 * folder.
	 * 
	 * @author sanoj.swaminathan
	 * @since 19-08-2024
	 * @param testcaseName
	 * @throws AutomationException
	 */
	public void startRecording(String testcaseName) throws AutomationException {
		try {
			ScreenRecording.startVideoRecording(testcaseName);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Stop video recording.
	 * 
	 * @author sanoj.swaminathan
	 * @since 19-08-2024
	 * @throws AutomationException
	 */
	public void stopRecording() throws AutomationException {
		try {
			ScreenRecording.stopVideoRecording();
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to get the test data path from the property file
	 * automation_test_config.properties
	 * 
	 * @author sanoj.swaminathan
	 * @since 25-07-2024
	 * @param testDataPathKey
	 * @return
	 * @throws AutomationException
	 */
	public String getTestDataPath(String testDataPathKey) throws AutomationException {
		String testDataPath = null;
		try {
			testDataPath = dataHandler.getProperty(AutomationConstants.AUTOMATION_TEST_CONFIG, testDataPathKey);
		} catch (Exception e) {
			Log.exception(e);
		}
		return testDataPath;
	}

	/**
	 * Keyword to get the latest mail from Gmail account. Here's how to generate an
	 * app password for Gmail. 1. Log into your Gmail account. 2. Go to your profile
	 * and click Manage your Gmail account. 3. Click the Security tab. 4. Make sure
	 * 2-Step Verification is turned on. 5. Click Generate app password. 6. Verify
	 * your account with your password. 7. Enter the 2-step verification passcode.
	 * 8. Select the app and device you want to use. 9. Click Generate. 10. Copy and
	 * save the code. 11. Click Done. NOTE: When using the password, do not use
	 * spaces.
	 * 
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-09-2024
	 * @param emailAddress
	 * @param password
	 * @return
	 * @throws Exception
	 */
	public String getMail(final String emailAddress, final String password) throws Exception {
		final GmailUtilitiesIMAPS gm = new GmailUtilitiesIMAPS();
		String mail = null;
		try {
			mail = gm.getMessage(emailAddress, password);
		} catch (final Exception e) {
			Log.exception(e);
			throw new AutomationException(e);
		}
		return mail;
	}

	/**
	 * Keyword to get the mail subject of latest mail from Gmail account.Here's how
	 * to generate an app password for Gmail. 1. Log into your Gmail account. 2. Go
	 * to your profile and click Manage your Gmail account. 3. Click the Security
	 * tab. 4. Make sure 2-Step Verification is turned on. 5. Click Generate app
	 * password. 6. Verify your account with your password. 7. Enter the 2-step
	 * verification passcode. 8. Select the app and device you want to use. 9. Click
	 * Generate. 10. Copy and save the code. 11. Click Done. NOTE: When using the
	 * password, do not use spaces.
	 * 
	 * @author sanoj.swaminathan
	 * @since 13-09-2024
	 * @param emailAddress
	 * @param password
	 * @return
	 * @throws Exception
	 */
	public String getMailSubject(final String emailAddress, final String password) throws Exception {
		final GmailUtilitiesIMAPS gm = new GmailUtilitiesIMAPS();
		String mailSubject = null;
		try {
			mailSubject = gm.getSubject(emailAddress, password);
		} catch (final Exception e) {
			Log.exception(e);
			throw new AutomationException(e);
		}
		return mailSubject;
	}

	/**
	 * Method to generate 20 bytes secret key encoded as base32 string
	 * 
	 * @author sanoj.swaminathan
	 * @since 03-10-2024
	 * @return
	 * @throws AutomationException
	 */
	public String generateSecretKey() throws AutomationException {
		byte[] bytes;
		Base32 base32;
		String secretKey = null;
		try {
			SecureRandom random = new SecureRandom();
			bytes = new byte[20];
			random.nextBytes(bytes);
			base32 = new Base32();
			secretKey = base32.encodeToString(bytes);
		} catch (Exception e) {
			throw new AutomationException(e);
		}
		return secretKey;
	}

	/**
	 * Method to generate the 6 digit TOTP based on the given secret key
	 * 
	 * @author sanoj.swaminathan
	 * @since 03-10-2024
	 * @param secretKey
	 * @return
	 * @throws AutomationException
	 */
	public static String getTOTPCode(String secretKey) throws AutomationException {
		String totp = null;
		try {
			Base32 base32 = new Base32();
			byte[] bytes = base32.decode(secretKey);
			String hexKey = Hex.encodeHexString(bytes);
			totp = TOTP.getOTP(hexKey);
		} catch (Exception e) {
			throw new AutomationException(e);
		}
		return totp;
	}
}
