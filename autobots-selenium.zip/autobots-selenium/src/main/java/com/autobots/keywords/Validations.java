package com.autobots.keywords;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONException;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.testng.Assert;

import com.autobots.base.AutomationBase;
import com.autobots.exception.AutomationException;
import com.autobots.utils.AutomationConstants;
import com.autobots.utils.Log;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.Result;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;

public class Validations extends AutomationBase {

	Utilities utilityActionHelper = new Utilities();

	/**
	 * Verify the visibility of an element on the page
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @param messageOnFailure
	 * @throws Exception
	 */
	public void verifyElementVisible(WebDriver driver, String elementName, String messageOnFailure) throws Exception {
		boolean isElementVisible = false;
		try {
			int count = utilityActionHelper.waitForElements(driver, elementName).size();
			if (count != 0) {
				isElementVisible = true;
			} else {
				isElementVisible = false;
			}
			Assert.assertTrue(isElementVisible, messageOnFailure);
			Log.message(driver, elementName + " is visible");
		} catch (AssertionError e) {
			Log.fail(driver, elementName + " is not visible");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify the visibility of given element on the page
	 * 
	 * @author tom.saju
	 * @since 20-08-2024
	 * @param driver
	 * @param element
	 * @param messageOnFailure
	 * @throws Exception
	 */
	public void verifyElementVisible(WebDriver driver, WebElement element, String messageOnFailure) throws Exception {
		boolean isElementVisible = false;
		try {
			isElementVisible = utilityActionHelper.waitForElement(driver, element);
			Assert.assertTrue(isElementVisible, messageOnFailure);
			Log.message(driver, "Given element is visible");
		} catch (AssertionError e) {
			Log.fail(driver, element + " is not visible");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the object is visible based on RelativeLocator direction
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-12-2021
	 * @param driver
	 * @param tagName
	 * @param direction:left,  right, above, below, near
	 * @param elementName
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyElementVisible(WebDriver driver, String tagName, String direction, String elementName,
			String messageOnFailure) throws AutomationException {
		boolean elementVisible = false;
		try {
			WebElement element = utilityActionHelper.waitForElement(driver, elementName);
			WebElement elementToDoAction = new Utilities().getRelativeElement(driver, tagName, direction, element);
			if (elementToDoAction.isDisplayed()) {
				elementVisible = true;
			} else {
				elementVisible = false;
			}
			Assert.assertTrue(elementVisible, messageOnFailure);
			Log.message(driver, elementName + " is visible");
		} catch (AssertionError e) {
			Log.fail(driver, elementName + " is not visible");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the given element is visible based on RelativeLocator direction
	 * 
	 * @author tom.saju
	 * @since 20-08-2024
	 * @param driver
	 * @param tagName
	 * @param direction
	 * @param element
	 * @param messageOnFailure
	 * @throws Exception
	 */
	public void verifyElementVisible(WebDriver driver, String tagName, String direction, WebElement element,
			String messageOnFailure) throws Exception {
		boolean elementVisible = false;
		try {
			utilityActionHelper.waitForElement(driver, element);
			WebElement elementToDoAction = new Utilities().getRelativeElement(driver, tagName, direction, element);
			if (elementToDoAction.isDisplayed()) {
				elementVisible = true;
			} else {
				elementVisible = false;
			}
			Assert.assertTrue(elementVisible, messageOnFailure);
			Log.message(driver, "Given element is visible");
		} catch (AssertionError e) {
			Log.fail(driver, element + " is not visible");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify the visibility of an element is not on the page
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @param messageOnFailure
	 * @throws Exception
	 */
	public void verifyElementNotVisible(WebDriver driver, String elementName, String messageOnFailure)
			throws Exception {
		boolean elementNotPresent = false;
		try {
			int count = utilityActionHelper.waitForElements(driver, elementName).size();
			if (count != 0) {
				elementNotPresent = true;
			} else {
				elementNotPresent = false;
			}
			Assert.assertFalse(elementNotPresent, messageOnFailure);
			Log.message(driver, elementName + " is not visible");
		} catch (AssertionError e) {
			Log.fail(driver, elementName + " is visible");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify the visibility of an given element is not found
	 * 
	 * @author tom.saju
	 * @since 20-08-2024
	 * @param driver
	 * @param element
	 * @param messageOnFailure
	 * @throws Exception
	 */
	public void verifyElementNotVisible(WebDriver driver, WebElement element, String messageOnFailure)
			throws Exception {
		boolean elementNotPresent = false;
		try {
			elementNotPresent = utilityActionHelper.waitForElement(driver, element);
			if (!elementNotPresent) {
				elementNotPresent = true;
			} else {
				elementNotPresent = false;
			}
			Assert.assertFalse(elementNotPresent, messageOnFailure);
			Log.message(driver, "Given element is not visible");
		} catch (AssertionError e) {
			Log.fail(driver, element + " is visible");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the the element is displayed on the page
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @throws AutomationException
	 */
	public void verifyElementDisplayed(WebDriver driver, String elementName, String messageOnFailure)
			throws AutomationException {
		boolean elementVisible = false;
		try {
			elementVisible = utilityActionHelper.waitForElement(driver, elementName).isDisplayed();
			Assert.assertTrue(elementVisible, messageOnFailure);
			Log.message(driver, elementName + " is displayed");
		} catch (AssertionError e) {
			Log.fail(driver, elementName + " is not displayed");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the the given element is found
	 * 
	 * @author tom.saju
	 * @since 20-08-2024
	 * @param driver
	 * @param element
	 * @param messageOnFailure
	 * @throws Exception
	 */
	public void verifyElementDisplayed(WebDriver driver, WebElement element, String messageOnFailure) throws Exception {
		boolean elementVisible = false;
		try {
			if (utilityActionHelper.waitForElement(driver, element)) {
				if (element.isDisplayed()) {
					elementVisible = true;
				} else {
					elementVisible = false;
				}
			}
			Assert.assertTrue(elementVisible, messageOnFailure);
			Log.message(driver, "Given element is displayed");
		} catch (AssertionError e) {
			Log.fail(driver, element + " is not displayed");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the element is not displayed on the page
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @throws AutomationException
	 */
	public void verifyElementNotDisplayed(WebDriver driver, String elementName, String messageOnFailure)
			throws AutomationException {
		boolean elementNotVisible = false;
		try {
			elementNotVisible = utilityActionHelper.waitForElement(driver, elementName).isDisplayed();
			Assert.assertFalse(elementNotVisible, messageOnFailure);
			Log.message(driver, elementName + " is not displayed");
		} catch (AssertionError e) {
			Log.fail(driver, elementName + " is displayed");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the given element is not displayed
	 * 
	 * @author tom.saju
	 * @since 20-08-2024
	 * @param driver
	 * @param element
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyElementNotDisplayed(WebDriver driver, WebElement element, String messageOnFailure)
			throws AutomationException {
		boolean elementNotVisible = false;
		try {
			if (!element.isDisplayed()) {
				elementNotVisible = true;
			} else {
				elementNotVisible = false;
			}
			Assert.assertFalse(elementNotVisible, messageOnFailure);
			Log.message(driver, "Given element is not displayed");
		} catch (AssertionError e) {
			Log.fail(driver, element + " is displayed");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the element is enabled
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyElementEnabled(WebDriver driver, String elementName, String messageOnFailure)
			throws AutomationException {
		boolean elementEnabled = false;
		try {
			elementEnabled = utilityActionHelper.waitForElement(driver, elementName).isEnabled();
			Assert.assertTrue(elementEnabled, messageOnFailure);
			Log.message(driver, elementName + " is enabled");
		} catch (AssertionError e) {
			Log.fail(driver, elementName + " is not enabled");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify the given element is enabled
	 * 
	 * @author tom.saju
	 * @since 20-08-2024
	 * @param driver
	 * @param element
	 * @param messageOnFailure
	 * @throws Exception
	 */
	public void verifyElementEnabled(WebDriver driver, WebElement element, String messageOnFailure) throws Exception {
		boolean elementEnabled = false;
		try {
			if (utilityActionHelper.waitForElement(driver, element)) {
				if (element.isEnabled()) {
					elementEnabled = true;
				} else {
					elementEnabled = false;
				}
			}
			Assert.assertTrue(elementEnabled, messageOnFailure);
			Log.message(driver, "Given element is enabled");
		} catch (AssertionError e) {
			Log.fail(driver, element + " is not enabled");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the object is enabled based on RelativeLocator direction
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-12-2021
	 * @param driver
	 * @param tagName
	 * @param direction:left,  right, above, below, near
	 * @param elementName
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyElementEnabled(WebDriver driver, String tagName, String direction, String elementName,
			String messageOnFailure) throws AutomationException {
		boolean elementVisible = false;
		try {
			WebElement element = utilityActionHelper.waitForElement(driver, elementName);
			WebElement elementToDoAction = new Utilities().getRelativeElement(driver, tagName, direction, element);
			if (elementToDoAction.isEnabled()) {
				elementVisible = true;
			} else {
				elementVisible = false;
			}
			Assert.assertTrue(elementVisible, messageOnFailure);
			Log.message(driver, elementName + " is enabled");
		} catch (AssertionError e) {
			Log.fail(driver, elementName + " is not enabled");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the given element is enabled based on RelativeLocator direction
	 * 
	 * @author tom.saju
	 * @since 20-08-2024
	 * @param driver
	 * @param tagName
	 * @param direction
	 * @param element
	 * @param messageOnFailure
	 * @throws Exception
	 */
	public void verifyElementEnabled(WebDriver driver, String tagName, String direction, WebElement element,
			String messageOnFailure) throws Exception {
		boolean elementVisible = false;
		try {
			utilityActionHelper.waitForElement(driver, element);
			WebElement elementToDoAction = new Utilities().getRelativeElement(driver, tagName, direction, element);
			if (elementToDoAction.isEnabled()) {
				elementVisible = true;
			} else {
				elementVisible = false;
			}
			Assert.assertTrue(elementVisible, messageOnFailure);
			Log.message(driver, "Given element is enabled");
		} catch (AssertionError e) {
			Log.fail(driver, element + " is not enabled");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the element is not enabled
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyElementNotEnabled(WebDriver driver, String elementName, String messageOnFailure)
			throws AutomationException {
		boolean elementNotEnabled = false;
		try {
			elementNotEnabled = utilityActionHelper.waitForElement(driver, elementName).isEnabled();
			Assert.assertFalse(elementNotEnabled, messageOnFailure);
			Log.message(driver, elementName + " is not enabled");
		} catch (AssertionError e) {
			Log.fail(driver, elementName + " is enabled");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the given element is not enabled
	 * 
	 * @author tom.saju
	 * @since 20-08-2024
	 * @param driver
	 * @param element
	 * @param messageOnFailure
	 * @throws Exception
	 */
	public void verifyElementNotEnabled(WebDriver driver, WebElement element, String messageOnFailure)
			throws Exception {
		boolean elementNotEnabled = false;
		try {
			if (utilityActionHelper.waitForElement(driver, element)) {
				if (!element.isEnabled()) {
					elementNotEnabled = true;
				} else {
					elementNotEnabled = false;
				}
			}
			Assert.assertFalse(elementNotEnabled, messageOnFailure);
			Log.message(driver, "Given element is not enabled");
		} catch (AssertionError e) {
			Log.fail(driver, element + " is enabled");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the element is selected
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyElementSelected(WebDriver driver, String elementName, String messageOnFailure)
			throws AutomationException {
		boolean elementSelected = false;
		try {
			elementSelected = utilityActionHelper.waitForElement(driver, elementName).isSelected();
			Assert.assertTrue(elementSelected, messageOnFailure);
			Log.message(driver, elementName + " is selected");
		} catch (AssertionError e) {
			Log.fail(driver, elementName + " is not selected");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the given element is selected
	 * 
	 * @author tom.saju
	 * @since 20-08-2024
	 * @param driver
	 * @param element
	 * @param messageOnFailure
	 * @throws Exception
	 */
	public void verifyElementSelected(WebDriver driver, WebElement element, String messageOnFailure) throws Exception {
		boolean elementSelected = false;
		try {
			if (utilityActionHelper.waitForElement(driver, element)) {
				if (element.isSelected()) {
					elementSelected = true;
				} else {
					elementSelected = false;
				}
			}
			Assert.assertTrue(elementSelected, messageOnFailure);
			Log.message(driver, "Given element is selected");
		} catch (AssertionError e) {
			Log.fail(driver, element + " is not selected");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the object is selected based on RelativeLocator direction
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-12-2021
	 * @param driver
	 * @param tagName
	 * @param direction:left,  right, above, below, near
	 * @param elementName
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyElementSelected(WebDriver driver, String tagName, String direction, String elementName,
			String messageOnFailure) throws AutomationException {
		boolean elementVisible = false;
		try {
			WebElement element = utilityActionHelper.waitForElement(driver, elementName);
			WebElement elementToDoAction = new Utilities().getRelativeElement(driver, tagName, direction, element);
			if (elementToDoAction.isSelected()) {
				elementVisible = true;
			} else {
				elementVisible = false;
			}
			Assert.assertTrue(elementVisible, messageOnFailure);
			Log.message(driver, elementName + " is selected");
		} catch (AssertionError e) {
			Log.fail(driver, elementName + " is not selected");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the given element is selected based on RelativeLocator direction
	 * 
	 * @author tom.saju
	 * @since 20-08-2024
	 * @param driver
	 * @param tagName
	 * @param direction
	 * @param element
	 * @param messageOnFailure
	 * @throws Exception
	 */
	public void verifyElementSelected(WebDriver driver, String tagName, String direction, WebElement element,
			String messageOnFailure) throws Exception {
		boolean elementVisible = false;
		try {
			utilityActionHelper.waitForElement(driver, element);
			WebElement elementToDoAction = new Utilities().getRelativeElement(driver, tagName, direction, element);
			if (elementToDoAction.isSelected()) {
				elementVisible = true;
			} else {
				elementVisible = false;
			}
			Assert.assertTrue(elementVisible, messageOnFailure);
			Log.message(driver, "Given element is selected");
		} catch (AssertionError e) {
			Log.fail(driver, element + " is not selected");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the element is not selected
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyElementNotSelected(WebDriver driver, String elementName, String messageOnFailure)
			throws AutomationException {
		boolean elementNotSelected = false;
		try {
			elementNotSelected = utilityActionHelper.waitForElement(driver, elementName).isSelected();
			Assert.assertFalse(elementNotSelected, messageOnFailure);
			Log.message(driver, elementName + " is not selected");
		} catch (AssertionError e) {
			Log.fail(driver, elementName + " is selected");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the given element is not selected
	 * 
	 * @author tom.saju
	 * @since 20-08-2024
	 * @param driver
	 * @param element
	 * @param messageOnFailure
	 * @throws Exception
	 */
	public void verifyElementNotSelected(WebDriver driver, WebElement element, String messageOnFailure)
			throws Exception {
		boolean elementNotSelected = false;
		try {
			if (utilityActionHelper.waitForElement(driver, element)) {
				if (!element.isSelected())
					elementNotSelected = true;
			} else {
				elementNotSelected = false;
			}
			Assert.assertFalse(elementNotSelected, messageOnFailure);
			Log.message(driver, "Given element is not selected");
		} catch (AssertionError e) {
			Log.fail(driver, element + " is selected");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the checkbox selected
	 * 
	 * @author sanoj.swaminathan
	 * @since 05/18/2021
	 * @param driver
	 * @param elementName
	 * @param messageOnFailure
	 * @return
	 * @throws AutomationException
	 */
	public void verifyCheckboxSelected(WebDriver driver, String elementName, String messageOnFailure)
			throws AutomationException {
		boolean isCheckboxSelected = false;
		try {
			if (driver != null) {
				WebElement element = utilityActionHelper.waitForElement(driver, elementName);
				if (element != null) {
					if (element.getAttribute("checked") != null) {
						if (element.getAttribute("checked").equals("true")) {
							isCheckboxSelected = true;
						}
					} else {
						isCheckboxSelected = false;
					}
					Assert.assertTrue(isCheckboxSelected, messageOnFailure);
					Log.message(driver, "Checkbox is selected at " + elementName);
				}
			}
		} catch (AssertionError e) {
			Log.fail(driver, "Checkbox is not selected");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the checkbox selected for given element
	 * 
	 * @author tom.saju
	 * @since 20-08-2024
	 * @param driver
	 * @param element
	 * @param messageOnFailure
	 * @throws Exception
	 */
	public void verifyCheckboxSelected(WebDriver driver, WebElement element, String messageOnFailure) throws Exception {
		boolean isCheckboxSelected = false;
		try {
			if (driver != null) {
				boolean elementVisible = utilityActionHelper.waitForElement(driver, element);
				if (elementVisible) {
					if (element.getAttribute("checked") != null) {
						if (element.getAttribute("checked").equals("true")) {
							isCheckboxSelected = true;
						}
					} else {
						isCheckboxSelected = false;
					}
					Assert.assertTrue(isCheckboxSelected, messageOnFailure);
					Log.message(driver, "Checkbox is selected at the given element");
				}
			}
		} catch (AssertionError e) {
			Log.fail(driver, "Checkbox is not selected");
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the element text or label is visible
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @param expectedText
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyElementText(WebDriver driver, String elementName, String expectedText, String messageOnFailure)
			throws AutomationException {
		boolean textVerified = false;
		try {
			WebElement element = utilityActionHelper.waitForElement(driver, elementName);
			String actualText = element.getText();
			if (actualText.contentEquals(expectedText)) {
				textVerified = true;
			} else {
				textVerified = false;
			}
			Assert.assertTrue(textVerified, messageOnFailure);
			Log.message(driver, "Element text " + expectedText + " is present in " + elementName);
		} catch (AssertionError e) {
			Log.fail(driver, "Element text " + expectedText + " is not present in " + elementName);
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the element text or label is visible in the given element
	 * 
	 * @author tom.saju
	 * @since 20-08-2024
	 * @param driver
	 * @param element
	 * @param expectedText
	 * @param messageOnFailure
	 * @throws Exception
	 */
	public void verifyElementText(WebDriver driver, WebElement element, String expectedText, String messageOnFailure)
			throws Exception {
		boolean textVerified = false;
		try {
			if (utilityActionHelper.waitForElement(driver, element)) {
				String actualText = element.getText();
				if (actualText.contentEquals(expectedText)) {
					textVerified = true;
				} else {
					textVerified = false;
				}
			}
			Assert.assertTrue(textVerified, messageOnFailure);
			Log.message(driver, "Element text " + expectedText + " is present in the given element");
		} catch (AssertionError e) {
			Log.fail(driver, "Element text " + expectedText + " is not present in " + element);
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the element contains text or label
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @param expectedText
	 * @throws AutomationException
	 */
	public void verifyElementTextContains(WebDriver driver, String elementName, String expectedText,
			String messageOnFailure) throws AutomationException {
		boolean textContains = false;
		try {
			WebElement element = utilityActionHelper.waitForElement(driver, elementName);
			String actualText = element.getText();
			if (actualText.contains(expectedText)) {
				textContains = true;
			} else {
				textContains = false;
			}
			Assert.assertTrue(textContains, messageOnFailure);
			Log.message(driver, "Element text " + expectedText + " is contains in " + elementName);
		} catch (AssertionError e) {
			Log.fail(driver, "Element text " + expectedText + " is not contains in " + elementName);
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the given element contains text or label
	 * 
	 * @author tom.saju
	 * @since 20-08-2024
	 * @param driver
	 * @param element
	 * @param expectedText
	 * @param messageOnFailure
	 * @throws Exception
	 */
	public void verifyElementTextContains(WebDriver driver, WebElement element, String expectedText,
			String messageOnFailure) throws Exception {
		boolean textContains = false;
		try {
			if (utilityActionHelper.waitForElement(driver, element)) {
				String actualText = element.getText();
				if (actualText.contains(expectedText)) {
					textContains = true;
				} else {
					textContains = false;
				}
			}
			Assert.assertTrue(textContains, messageOnFailure);
			Log.message(driver, "Element text " + expectedText + " is contains in given element");
		} catch (AssertionError e) {
			Log.fail(driver, "Element text " + expectedText + " is not contains in " + element);
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the element attribute has text or label visible
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param elementName
	 * @param attributeName
	 * @param expectedText
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyElementAttributeHasText(WebDriver driver, String elementName, String attributeName,
			String expectedText, String messageOnFailure) throws AutomationException {
		boolean textVerified = false;
		try {
			WebElement element = utilityActionHelper.waitForElement(driver, elementName);
			String actualAttributeValue = element.getAttribute(attributeName);
			if (actualAttributeValue.contentEquals(expectedText)) {
				textVerified = true;
			} else {
				textVerified = false;
			}
			Assert.assertTrue(textVerified, messageOnFailure);
			Log.message(driver, attributeName + " has text in " + elementName);
		} catch (AssertionError e) {
			Log.fail(driver, attributeName + " has text not in " + elementName);
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the given element attribute has text or label visible
	 * 
	 * @author tom.saju
	 * @since 20-08-2024
	 * @param driver
	 * @param element
	 * @param attributeName
	 * @param expectedText
	 * @param messageOnFailure
	 * @throws Exception
	 */
	public void verifyElementAttributeHasText(WebDriver driver, WebElement element, String attributeName,
			String expectedText, String messageOnFailure) throws Exception {
		boolean textVerified = false;
		try {
			if (utilityActionHelper.waitForElement(driver, element)) {
				String actualAttributeValue = element.getAttribute(attributeName);
				if (actualAttributeValue.contentEquals(expectedText)) {
					textVerified = true;
				} else {
					textVerified = false;
				}
			}
			Assert.assertTrue(textVerified, messageOnFailure);
			Log.message(driver, attributeName + " has text in given element");
		} catch (AssertionError e) {
			Log.fail(driver, attributeName + " has text not in " + element);
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify that the URL contains text or label
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param driver
	 * @param expectedText
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyURLContainsText(WebDriver driver, String expectedText, String messageOnFailure)
			throws AutomationException {
		boolean urlConatinsText = false;
		String actualURL = null;
		try {
			actualURL = driver.getCurrentUrl();
			if (actualURL.contains(expectedText)) {
				urlConatinsText = true;
			} else {
				urlConatinsText = false;
			}
			Assert.assertTrue(urlConatinsText, messageOnFailure);
			Log.message(driver, expectedText + " is present in the URL " + actualURL);
		} catch (AssertionError e) {
			Log.fail(driver, expectedText + " is not present in the URL " + actualURL);
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * To compare and verify the JSON files
	 * 
	 * @author sanoj.swaminathan
	 * @since 10-10-2022
	 * @param expectedJSONPath
	 * @param actualJSONPath
	 * @throws JSONException
	 * @throws IOException
	 * @throws AutomationException
	 */
	public void verifyJSONFileContent(String expectedJSONPath, String actualJSONPath)
			throws JSONException, IOException, AutomationException {
		try {
			String expectedJson = FileUtils.readFileToString(new File(expectedJSONPath), "utf-8");
			String actualJson = FileUtils.readFileToString(new File(actualJSONPath), "utf-8");
			JSONAssert.assertEquals(expectedJson, actualJson, JSONCompareMode.STRICT);
		} catch (AssertionError e) {
			Log.fail("JSON files are not equal");
			throw new AssertionError("JSON files are not equal", e);
		}
	}

	/**
	 * Verify the file downloaded or not
	 * 
	 * @author sanoj.swaminathan
	 * @since 19-08-2022
	 * @param downloadPath
	 * @param fileName
	 * @param messageOnFailure
	 * @return
	 * @throws AutomationException
	 */
	public void verifyFileDownload(String downloadPath, String fileName, String messageOnFailure)
			throws AutomationException {
		boolean isFileDownloaded = false;
		try {
			File dir = new File(downloadPath);
			File[] dirContents = dir.listFiles();
			for (int i = 0; i < dirContents.length; i++) {
				if (dirContents[i].getName().contains(fileName)) {
					dirContents[i].delete();
					isFileDownloaded = true;
					Assert.assertTrue(isFileDownloaded, messageOnFailure);
					Log.message(getDriver(), fileName + " is downloaded at " + downloadPath);
				}
			}
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Test broken links in a web page. To achieve, users must be in the web page to
	 * be tested and call this method
	 * 
	 * @author sanoj.swaminathan
	 * @since 16-04-2021
	 * @param driver
	 * @throws AutomationException
	 * 
	 */
	public void verifyBrokenLinks(final WebDriver driver) throws AutomationException {
		List<WebElement> linkElements = null;
		int size = 0;
		int count = 0;
		String pageCurrentURL = "";
		FileOutputStream linkCheckerOutPut = null;
		byte[] firstRun = null;
		long startTime;
		Capabilities capabilities = null;
		if (driver != null) {
			final String currentURL = driver.getCurrentUrl();
			driver.get(currentURL);

			final long end = System.currentTimeMillis() + 5000;
			while (System.currentTimeMillis() < end) {
				linkElements = driver.findElements(By.tagName("a"));
			}
			size = linkElements.size();
			Log.message("Number of links : " + size);
			capabilities = ((RemoteWebDriver) driver).getCapabilities();
		} else {
			Log.message("Driver not initialised..");
			System.exit(0);
		}
		String browsername = "";
		try {
			browsername = (String) capabilities.getCapability("browserName");
		} catch (final NullPointerException e) {
			browsername = "UnknownBrowser";
		}
		String urls = null, attributeValue1 = null, attributeValue2 = null;
		final String[] hrefTags = new String[size];
		for (int i = 0; i < size; i++) {
			boolean resultDataLink = false;
			boolean resultHref = false;
			try {
				urls = linkElements.get(i).getAttribute("href");
				try {
					attributeValue1 = linkElements.get(i).getAttribute("data-link");
					resultDataLink = true;
				} catch (final Exception e) {
					Log.exception(e);
					resultDataLink = false;
				}
				try {
					attributeValue2 = linkElements.get(i).getAttribute("href");
					resultHref = true;

				} catch (final Exception e) {
					Log.exception(e);
					resultHref = false;
				}

				if (urls.equals(null) || (urls.equalsIgnoreCase("null"))) {
					count = count + 0;
				} else {
					hrefTags[count] = urls;
					count = count + 1;
				}
				if (attributeValue1 != null) {
					resultDataLink = true;
				} else if (attributeValue2 != null) {
					resultHref = true;
				}

				if (resultDataLink == true) {
					if (attributeValue1.equals(null) || (attributeValue1.equalsIgnoreCase("null"))) {
						count = count + 0;
					} else {
						hrefTags[count] = attributeValue1;
						count = count + 1;
					}
				} else if (resultHref == true) {
					if (attributeValue2.equals(null) || (attributeValue2.equalsIgnoreCase("null"))) {
						count = count + 0;
					} else {
						hrefTags[count] = attributeValue2;
						count = count + 1;
					}
				}
			} catch (final NullPointerException nuEx) {
				count = count + 0;
			}
		}
		final DateFormat dateFormat = new SimpleDateFormat("dd_MM_yyyy");
		new File(new File(System.getProperty("user.dir")), AutomationConstants.URLCHECK_LIST_FILE).mkdirs();
		try {
			try {
				linkCheckerOutPut = new FileOutputStream(System.getProperty("user.dir")
						+ AutomationConstants.URLCHECK_LIST_FILE + "default_" + browsername + "_"
						+ dateFormat.format(new Date()) + "_" + +System.currentTimeMillis() + ".txt");

			} catch (final Exception lException) {
				Log.exception(lException);

			}

		} catch (final Exception fnf) {
			Log.exception(fnf);

		}
		try {
			firstRun = ("\n" + "Index" + "\t " + "Link Name" + "\t\t " + "Response Code" + "\n ").getBytes();
			linkCheckerOutPut.write(firstRun);
		} catch (final IOException e1) {
			Log.exception(e1);
		}
		startTime = (System.currentTimeMillis() / 1000);

		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(59));

		for (int j = 0; j < hrefTags.length; j++) {
			try {
				if ((j < hrefTags.length) && (hrefTags[j] != null) && (!hrefTags[j].equals(""))) {
					if ((hrefTags[j].contains("javascript:"))) {
						Log.message("URL contains javascript Method");
						firstRun = ("\n" + j + " \t" + hrefTags[j] + " \t" + " URL contains javascript Method ")
								.getBytes();
						try {
							linkCheckerOutPut.write(firstRun);
						} catch (final IOException e) {
							Log.exception(e);
						}
					} else {
						driver.get(hrefTags[j]);
						pageCurrentURL = driver.getCurrentUrl().toString().trim();
					}
					try {
						if (!pageCurrentURL.equals(hrefTags[j]) && (pageCurrentURL.equals(""))) {
							throw new Exception();
						}
						final URL url = new URL(hrefTags[j]);
						final HttpURLConnection connection = (HttpURLConnection) url.openConnection();
						connection.setRequestMethod("GET");
						connection.connect();
						final int code = connection.getResponseCode();

						if (code == 200 || code == 201 || code == 202 || code == 203 || code == 204 || code == 205
								|| code == 206 || code == 207 || code == 208 || code == 226) {
							Log.message("Server Response  : " + code);
							firstRun = ("\n" + j + " \t" + hrefTags[j] + " \t" + code + "\t\t - Success Code Returned")
									.getBytes();
							linkCheckerOutPut.write(firstRun);
						} else {
							Log.message("URL not returned a Success response from server!!!");
							firstRun = ("\n" + j + " \t" + hrefTags[j] + " \t" + code
									+ "\t\t - Fail Response from server").getBytes();
							linkCheckerOutPut.write(firstRun);
							throw new Exception();
						}
					} catch (final Exception e) {
						Log.message("Failed to load URL- Exception occured!!!");
					}
				}
			} catch (final Exception e) {
				continue;
			}
		}
		final long endTime = (System.currentTimeMillis() / 1000);
		final long elapsedTimeLong = endTime - startTime;
		final String elapsedTime = Long.toString(elapsedTimeLong);
		try {
			linkCheckerOutPut.write(("\n\n\n\t" + "Total Execution time : " + elapsedTime + " (Seconds)").getBytes());
		} catch (final IOException e) {
			Log.exception(e);
		}
	}

	/**
	 * Verify whether the actual and expected results are equal or not, based on
	 * that it will show the message that given as parameter
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param actual
	 * @param expected
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyEquals(String actual, String expected, String messageOnFailure) throws AutomationException {
		try {
			Assert.assertEquals((String) actual, (String) expected, (String) messageOnFailure);
			Log.message(getDriver(), actual + " matches " + expected);
		} catch (AssertionError e) {
			Log.fail(getDriver(), actual + " does not match " + expected);
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify whether the actual and expected results are equal or not for boolean,
	 * based on that it will show the message that given as parameter
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param actual
	 * @param expected
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyEquals(boolean actual, boolean expected, String messageOnFailure) throws AutomationException {
		try {
			Assert.assertEquals((boolean) actual, (boolean) expected, (String) messageOnFailure);
			Log.message(getDriver(), actual + " matches " + expected);
		} catch (AssertionError e) {
			Log.fail(getDriver(), actual + " does not match " + expected);
			throw new AssertionError(messageOnFailure, e);
		}
	}

	/**
	 * Verify whether the actual and expected results are not equal or not for
	 * String, based on that it will show the message that given as parameter
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param actual
	 * @param expected
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyNotEquals(String actual, String expected, String messageOnFailure) throws AutomationException {
		try {
			Assert.assertNotEquals((String) actual, (String) expected, (String) messageOnFailure);
			Log.message(actual + " is not matches " + expected);
		} catch (AssertionError lException) {
			Log.fail(getDriver(), actual + " is matches " + expected);
			throw new AssertionError(messageOnFailure, lException);
		}
	}

	/**
	 * Verify whether the actual and expected results are equal or not for boolean,
	 * based on that it will show the message that given as parameter
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param actual
	 * @param expected
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyNotEquals(boolean actual, boolean expected, String messageOnFailure) throws AutomationException {
		try {
			Assert.assertNotEquals((boolean) actual, (boolean) expected, (String) messageOnFailure);
			Log.message(actual + " is not matches " + expected);
		} catch (AssertionError lException) {
			Log.fail(actual + " is matches " + expected);
			throw new AssertionError(messageOnFailure, lException);
		}
	}

	/**
	 * Method to validate the string value in a list
	 * 
	 * @author sanoj.swaminathan
	 * @since 17-01-2024
	 * @param list
	 * @param valueToBeValidated
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyValueInList(List<String> list, String valueToBeValidated, String messageOnFailure)
			throws AutomationException {
		try {
			Assert.assertTrue(list.contains(valueToBeValidated), messageOnFailure);
			Log.message(valueToBeValidated + " is not in the " + list);
		} catch (AssertionError lException) {
			Log.fail(valueToBeValidated + " is in the " + list);
			throw new AssertionError(messageOnFailure, lException);
		}
	}

	/**
	 * Method to validate the string value not in a list
	 * 
	 * @author sanoj.swaminathan
	 * @since 17-01-2024
	 * @param list
	 * @param valueToBeValidated
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyValueNotInList(List<String> list, String valueToBeValidated, String messageOnFailure)
			throws AutomationException {
		try {
			Assert.assertFalse(list.contains(valueToBeValidated), messageOnFailure);
			Log.message(valueToBeValidated + " is in the " + list);
		} catch (AssertionError lException) {
			Log.fail(valueToBeValidated + " is not in the " + list);
			throw new AssertionError(messageOnFailure, lException);
		}
	}

	/**
	 * Method to validate the integer value in a list
	 * 
	 * @author sanoj.swaminathan
	 * @since 17-01-2024
	 * @param list
	 * @param valueToBeValidated
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyValueInList(List<Integer> list, int valueToBeValidated, String messageOnFailure)
			throws AutomationException {
		try {
			Assert.assertTrue(list.contains(valueToBeValidated), messageOnFailure);
			Log.message(valueToBeValidated + " is not in the " + list);
		} catch (AssertionError lException) {
			Log.fail(valueToBeValidated + " is in the " + list);
			throw new AssertionError(messageOnFailure, lException);
		}
	}

	/**
	 * Method to validate the integer value not in a list
	 * 
	 * @author sanoj.swaminathan
	 * @since 17-01-2024
	 * @param list
	 * @param valueToBeValidated
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyValueNotInList(List<Integer> list, int valueToBeValidated, String messageOnFailure)
			throws AutomationException {
		try {
			Assert.assertFalse(list.contains(valueToBeValidated), messageOnFailure);
			Log.message(valueToBeValidated + " is in the " + list);
		} catch (AssertionError lException) {
			Log.fail(valueToBeValidated + " is not in the " + list);
			throw new AssertionError(messageOnFailure, lException);
		}
	}

	/**
	 * Capture the current screen and compare it with expected image file
	 * 
	 * @author sanoj.swaminathan
	 * @since 01-05-2023
	 * @param driver
	 * @param scenario
	 * @param expectedImageFilePath
	 * @param featureName
	 * @throws AutomationException
	 * 
	 */
	@SuppressWarnings("unused")
	public String compareImages(WebDriver driver, String scenario, String expectedImageFilePath, String featureName)
			throws AutomationException {
		String matchpercentage = null;
		try {
			BufferedImage image = null;
			int width = 0;
			int height = 0;
			int[][] clr = null;
			BufferedImage images = null;
			int widthe = 0;
			int heighte = 0;
			int[][] clre = null;
			double start = System.currentTimeMillis();
			utilityActionHelper.delay(5);

			File outputfile;
			try {
				outputfile = ((TakesScreenshot) new Augmenter().augment(driver)).getScreenshotAs(OutputType.FILE);
				if (!outputfile.canRead() || !outputfile.isFile()) {
					throw new AutomationException(AutomationConstants.EXCEPTION_MESSAGE_FAILED_TO_GET_SCREEN);
				}
				image = ImageIO.read(outputfile);
				width = image.getWidth(null);
				height = image.getHeight(null);
				clr = new int[width][height];
			} catch (Exception e) {
				Log.exception(e);

			}

			try {
				File inFile = new File(expectedImageFilePath).getAbsoluteFile();
				if (!inFile.canRead() || !inFile.isFile()) {
					throw new AutomationException(AutomationConstants.EXCEPTION_MESSAGE_INPUT_IMAGE_NOT_FOUND);
				}
				images = ImageIO.read(inFile);
				widthe = images.getWidth(null);
				heighte = images.getHeight(null);
				clre = new int[widthe][heighte];
			} catch (Exception e) {
				Log.exception(e);

			}

			int smw = 0;
			int smh = 0;
			int p = 0;
			// Calculating the smallest value among width and height
			if (width > widthe) {
				smw = widthe;
			} else {
				smw = width;
			}
			if (height > heighte) {
				smh = heighte;
			} else {
				smh = height;
			}
			// Checking the number of pixels similarity
			for (int a = 0; a < smw; a++) {
				for (int b = 0; b < smh; b++) {
					clre[a][b] = images.getRGB(a, b);
					clr[a][b] = image.getRGB(a, b);
					if (clr[a][b] == clre[a][b]) {
						p = p + 1;
					}
				}
			}
			float w, h = 0;
			if (width > widthe) {
				w = width;
			} else {
				w = widthe;
			}
			if (height > heighte) {
				h = height;
			} else {
				h = heighte;
			}
			float s = (smw * smh);
			// Calculating the percentage
			float x = (100 * p) / s;
			matchpercentage = String.valueOf(new DecimalFormat("#").format(x)) + "%";

			DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy_HH-mm-ss");
			Date date = new Date();
			String dateTime = dateFormat.format(date).toString();

			double stop = System.currentTimeMillis();
			String timeTakenForComparison = String.valueOf((stop - start) / 1000);

			// Track the comparison details to the report
			trackDetailsToReport(scenario, expectedImageFilePath.toString(), matchpercentage, timeTakenForComparison,
					dateTime, featureName);

		} catch (Exception lException) {
			Log.exception(lException);

		}
		return matchpercentage;
	}

	/**
	 * Compares two images that send by the user and will return the percentage
	 * value for assertion
	 * 
	 * @author sanoj.swaminathan
	 * @since 01-05-2023
	 * @param expectedImage
	 * @param actualImage
	 * @throws AutomationException
	 * 
	 */
	@SuppressWarnings("unused")
	public String compareImages(String expectedImage, String actualImage) throws AutomationException {
		String matchpercentage = null;
		try {
			BufferedImage image = null;
			int width = 0;
			int height = 0;
			int[][] clr = null;
			BufferedImage images = null;
			int widthe = 0;
			int heighte = 0;
			int[][] clre = null;
			File outFile;
			try {
				outFile = new File(actualImage).getAbsoluteFile();

				if (!outFile.canRead() || !outFile.isFile()) {
					throw new AutomationException(AutomationConstants.EXCEPTION_MESSAGE_OUTPUT_IMAGE_NOT_FOUND);
				}
				image = ImageIO.read(outFile);
				width = image.getWidth(null);
				height = image.getHeight(null);
				clr = new int[width][height];
			} catch (Exception e) {
				Log.exception(e);
			}

			File inFile;
			try {
				inFile = new File(expectedImage).getAbsoluteFile();

				if (!inFile.canRead() || !inFile.isFile()) {
					throw new AutomationException(AutomationConstants.EXCEPTION_MESSAGE_INPUT_IMAGE_NOT_FOUND);
				}
				images = ImageIO.read(inFile);
				widthe = images.getWidth(null);
				heighte = images.getHeight(null);
				clre = new int[widthe][heighte];
			} catch (Exception e) {
				Log.exception(e);

			}

			int smw = 0;
			int smh = 0;
			int p = 0;
			// Calculating the smallest value among width and height
			if (width > widthe) {
				smw = widthe;
			} else {
				smw = width;
			}
			if (height > heighte) {
				smh = heighte;
			} else {
				smh = height;
			}
			// Checking the number of pixels similarity
			for (int a = 0; a < smw; a++) {
				for (int b = 0; b < smh; b++) {
					clre[a][b] = images.getRGB(a, b);
					clr[a][b] = image.getRGB(a, b);
					if (clr[a][b] == clre[a][b]) {
						p = p + 1;
					}
				}
			}

			float w, h = 0;
			if (width > widthe) {
				w = width;
			} else {
				w = widthe;
			}
			if (height > heighte) {
				h = height;
			} else {
				h = heighte;
			}
			float s = (smw * smh);
			// Calculating the percentage
			float x = (100 * p) / s;
			matchpercentage = String.valueOf(new DecimalFormat("#").format(x)) + "%";
			Log.message("Comparison percentage is " + matchpercentage);
		} catch (Exception lException) {
			Log.exception(lException);

		}
		return matchpercentage;
	}

	/**
	 * Method to track the image comparison details and generate excel report
	 * 
	 * @author sanoj.swaminathan
	 * @since 12/01/2023
	 * @param scenario
	 * @param expectedImage
	 * @param percentMatch
	 * @param timeTakenForComparison
	 * @param dateTime
	 * @param featureName
	 * @throws IOException
	 * @throws AutomationException
	 */
	private void trackDetailsToReport(String scenario, String expectedImage, String percentMatch,
			String timeTakenForComparison, String dateTime, String featureName)
			throws IOException, AutomationException {

		// Creating file object of existing excel file
		if (!new File(System.getProperty("user.dir") + "\\Reports").exists()) {
			(new File(System.getProperty("user.dir") + "\\Reports")).mkdir();
		}
		if (!new File(System.getProperty("user.dir") + "\\Reports\\Image_Comparision\\").exists()) {
			new File(new File(System.getProperty("user.dir")), "\\Reports\\Image_Comparision\\").mkdirs();
		}
		DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy_MM_dd");
		LocalDateTime dateNow = LocalDateTime.now();
		String dateValue = dateFormat.format(dateNow);
		String filePath = System.getProperty("user.dir") + "\\Reports\\Image_Comparision\\Image_Comparision_Report_"
				+ featureName + "_" + dateValue + ".xlsx";

		File excelFile = new File(filePath);
		OutputStream fileOut = null;
		Sheet sheet;
		File fileName;

		Workbook wb = new XSSFWorkbook();
		if (!excelFile.exists()) {
			fileName = new File(filePath);
			fileOut = new FileOutputStream(fileName);
			sheet = wb.createSheet("Sheet1");

			// Create headers and set style
			Row header = sheet.createRow(0);
			header.createCell(0).setCellValue("Scenario");
			header.createCell(1).setCellValue("Expected Image");
			header.createCell(2).setCellValue("% Match");
			header.createCell(3).setCellValue("Time Taken for Comparison (in seconds)");
			header.createCell(4).setCellValue("Date Time");
			header.createCell(5).setCellValue("Status");
			CellStyle style = wb.createCellStyle();
			Font font = wb.createFont();
			font.setFontHeightInPoints((short) 12);
			font.setBold(true);
			style.setFont(font);
			style.setWrapText(true);
			sheet.setColumnWidth(0, 70 * 256);
			sheet.setColumnWidth(1, 50 * 256);
			sheet.setColumnWidth(2, 15 * 256);
			sheet.setColumnWidth(3, 25 * 256);
			sheet.setColumnWidth(4, 15 * 256);
			sheet.setColumnWidth(5, 10 * 256);
			for (int j = 0; j <= 5; j++) {
				header.getCell(j).setCellStyle(style);
				CellStyle cellHeaderStyle = header.getCell(j).getCellStyle();
				cellHeaderStyle.setVerticalAlignment(VerticalAlignment.CENTER);
				cellHeaderStyle.setAlignment(HorizontalAlignment.CENTER);
				header.getCell(j).setCellStyle(cellHeaderStyle);
			}
			wb.write(fileOut);
			Log.message("Report has been created successfully.");
		}
		wb.close();

		// New records to update in the report
		Object[][] newdataLists = { { scenario, expectedImage, percentMatch, timeTakenForComparison, dateTime } };
		try {
			// Creating input stream
			FileInputStream inputStream = new FileInputStream(filePath);

			// Creating workbook from input stream
			Workbook workbook = WorkbookFactory.create(inputStream);

			// Reading first sheet of excel file
			sheet = workbook.getSheetAt(0);

			// Getting the count of existing records
			int rowCount = sheet.getLastRowNum();

			// Iterating new data to update
			for (Object[] data : newdataLists) {

				// Creating new row from the next row count
				Row row = sheet.createRow(++rowCount);

				int columnCount = 0;

				// Iterating data informations
				for (Object info : data) {

					// Creating new cell and setting the value
					Cell cell = row.createCell(columnCount++);
					if (info instanceof String) {
						cell.setCellValue((String) info);
					} else if (info instanceof Integer) {
						cell.setCellValue((Integer) info);
					}
				}
				// Setting the status and also setting the color style
				for (int i = 1; i < sheet.getLastRowNum() + 1; i++) {
					CellStyle style = workbook.createCellStyle();
					Font font = workbook.createFont();
					font.setBold(true);
					DataFormatter df = new DataFormatter();
					String actualPercentage = df.formatCellValue(sheet.getRow(i).getCell(2));
					Cell cell = row.createCell(5);
					if (!actualPercentage.equals("100%")) {
						font.setColor(HSSFColorPredefined.RED.getIndex());
						style.setFont(font);
						cell.setCellStyle(style);
						cell.setCellValue((String) "FAIL");
					} else {
						font.setColor(HSSFColorPredefined.GREEN.getIndex());
						style.setFont(font);
						cell.setCellStyle(style);
						cell.setCellValue((String) "PASS");
					}
				}
			}
			// Close input stream
			inputStream.close();

			// Crating output stream and writing the updated workbook
			FileOutputStream os = new FileOutputStream(filePath);
			workbook.write(os);

			// Close the workbook and output stream
			workbook.close();
			os.close();

			Log.message("Report has been updated successfully.");

		} catch (EncryptedDocumentException | IOException e) {
			Log.message("Exception while updating an existing report.");
			Log.exception(e);
		}
	}

	/**
	 * Method to validate the QR code data. The elementName should be the QR code
	 * image locator path
	 * 
	 * @author sanoj.swaminathan
	 * @since 28-11-2023
	 * @param driver
	 * @param elementName
	 * @param expected
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyQRCodeData(WebDriver driver, String elementName, String expected, String messageOnFailure)
			throws AutomationException {
		try {
			WebElement element = utilityActionHelper.waitForElement(driver, elementName);
			String urlOfQRCode = element.getAttribute("src");
			URL url = new URL(urlOfQRCode);
			BufferedImage bufferedimage = ImageIO.read(url);
			LuminanceSource luminanceSource = new BufferedImageLuminanceSource(bufferedimage);
			BinaryBitmap binaryBitmap = new BinaryBitmap(new HybridBinarizer(luminanceSource));
			Result result = new MultiFormatReader().decode(binaryBitmap);
			verifyEquals(result.getText(), expected, messageOnFailure);
		} catch (Exception e) {
			Log.exception(e);
			throw new AutomationException(messageOnFailure, e);
		}
	}

	/**
	 * Method to validate the QR code data. The given element should be the QR code
	 * image
	 * 
	 * @author tom.saju
	 * @since 20-08-2024
	 * @param driver
	 * @param element
	 * @param expected
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyQRCodeData(WebDriver driver, WebElement element, String expected, String messageOnFailure)
			throws AutomationException {
		try {
			boolean elementVisible = utilityActionHelper.waitForElement(driver, element);
			if (elementVisible) {
				String urlOfQRCode = element.getAttribute("src");
				URL url = new URL(urlOfQRCode);
				BufferedImage bufferedimage = ImageIO.read(url);
				LuminanceSource luminanceSource = new BufferedImageLuminanceSource(bufferedimage);
				BinaryBitmap binaryBitmap = new BinaryBitmap(new HybridBinarizer(luminanceSource));
				Result result = new MultiFormatReader().decode(binaryBitmap);
				verifyEquals(result.getText(), expected, messageOnFailure);
			}

		} catch (Exception e) {
			Log.exception(e);
			throw new AutomationException(messageOnFailure, e);
		}
	}

	/**
	 * Method to validate the QR code data. Need to pass the path of the QR code
	 * file image.
	 * 
	 * @author sanoj.swaminathan
	 * @since 28-11-2023
	 * @param qrCodeFilePath
	 * @param expected
	 * @param messageOnFailure
	 * @throws AutomationException
	 */
	public void verifyQRCodeData(String qrCodeFilePath, String expected, String messageOnFailure)
			throws AutomationException {
		try {
			BufferedImage bufferedimage = ImageIO.read(new File(qrCodeFilePath).getAbsoluteFile());
			LuminanceSource luminanceSource = new BufferedImageLuminanceSource(bufferedimage);
			BinaryBitmap binaryBitmap = new BinaryBitmap(new HybridBinarizer(luminanceSource));
			Result result = new MultiFormatReader().decode(binaryBitmap);
			verifyEquals(result.getText(), expected, messageOnFailure);
		} catch (Exception e) {
			Log.exception(e);
			throw new AutomationException(messageOnFailure, e);
		}
	}
}
