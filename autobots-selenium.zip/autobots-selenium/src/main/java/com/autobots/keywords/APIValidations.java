package com.autobots.keywords;

import static com.jayway.jsonpath.matchers.JsonPathMatchers.hasJsonPath;
import static com.jayway.jsonpath.matchers.JsonPathMatchers.isJson;
import static com.jayway.jsonpath.matchers.JsonPathMatchers.withJsonPath;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.nullValue;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.util.ArrayList;

import org.apache.commons.io.FileUtils;
import org.skyscreamer.jsonassert.JSONAssert;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.testng.Assert;

import com.autobots.exception.AutomationException;
import com.autobots.utils.AutomationConstants;
import com.autobots.utils.Log;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;
import io.restassured.path.xml.config.XmlPathConfig;
import io.restassured.response.Response;

public class APIValidations {

	/***
	 * Validate the status code from the response
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param expectedStatusCode
	 * @param responseData
	 * @return
	 */
	public boolean validateStatusCode(Response responseData, int expectedStatusCode) throws AutomationException {
		try {
			int actualStatusCode = responseData.getStatusCode();
			Assert.assertEquals(actualStatusCode, expectedStatusCode,
					actualStatusCode + " is not matches " + expectedStatusCode);
			Log.message(actualStatusCode + " is matches " + expectedStatusCode);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Validate response entire body
	 * 
	 * @author sanoj.swaminathan
	 * @since 02/04/2022
	 * @param response
	 * @param keyToValidate
	 * @param expectedValue
	 * @throws AutomationException 
	 */
	public void validateResponseBody(Response response, String expectedValue) throws AutomationException {
		try {
			String actualValue = response.then().extract().body().asPrettyString();
			assertTrue(actualValue.equals(expectedValue), actualValue + " value not matches " + expectedValue);
			Log.message(actualValue + " value matches " + expectedValue);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Validate data in the response body
	 * 
	 * @author sanoj.swaminathan
	 * @since 02/04/2022
	 * @param response
	 * @param keyToValidate
	 * @param expectedValue
	 * @throws AutomationException 
	 */
	public void validateInResponseBody(Response response, String expectedValue) throws AutomationException {
		try {
			String actualValue = response.then().extract().body().asPrettyString();
			assertTrue(actualValue.contains(expectedValue), actualValue + " value not matches " + expectedValue);
			Log.message(actualValue + " value matches " + expectedValue);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Validate response data from JSON response
	 * 
	 * @author sanoj.swaminathan
	 * @since 02/04/2022
	 * @param response
	 * @param keyToValidate
	 * @param expectedValue
	 * @throws AutomationException 
	 */
	public void validateResponseData(Response response, String keyToValidate, String expectedValue) throws AutomationException {
		try {
			String actualValue = response.then().extract().path(keyToValidate);
			assertTrue(actualValue.equals(expectedValue), actualValue + " value not matches " + expectedValue);
			Log.message(actualValue + " value matches " + expectedValue);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Validate response data from SOAP XML response
	 * 
	 * @author sanoj.swaminathan
	 * @since 11/12/2023
	 * @param response
	 * @param xmlPath
	 * @param expectedValue
	 */
	public void validateResponseDataInSOAPXMLResponse(Response response, String xmlPath, String expectedValue) {
		XmlPath xmlResponse = null;
		try {
			xmlResponse = new XmlPath(response.asPrettyString()).using(XmlPathConfig.xmlPathConfig()
					.declaredNamespace("soap", "http://schemas.xmlsoap.org/soap/envelope/"));
			String actualValue = xmlResponse.getString(xmlPath);
			assertTrue(actualValue.equals(expectedValue), actualValue + " value not matches " + expectedValue);
			Log.message(actualValue + " value not matches " + expectedValue);
		} catch (Exception e) {
			int actualValue = xmlResponse.getInt(xmlPath);
			assertTrue(actualValue == (Integer.parseInt(expectedValue)),
					actualValue + " value not matches " + expectedValue);
		}
	}

	/**
	 * Validate the response array list, the expected array list values can be read
	 * from the JSON file that available at
	 * /src/test/resources/APITesting/ResponseData/ location using
	 * getArrayValuesFromJSONFile() method
	 * 
	 * @author sanoj.swaminathan
	 * @since 02/04/2022
	 * @param arrayName
	 * @param keyName
	 * @param response
	 * @param expectedValue
	 * @return
	 */
	public void validateArrayListInResponse(Response response, String arrayName, String keyName,
			ArrayList<String> expectedValue) {
		String responseBody = response.then().extract().body().asPrettyString();
		JsonPath path = new JsonPath(responseBody);
		int dataSize = path.getInt(arrayName + ".size()");
		for (int i = 0; i < dataSize; i++) {
			String actualValue = path.get("" + arrayName + "[" + i + "]." + keyName + "");
			assertTrue(actualValue.equals(expectedValue.get(i)));
		}
	}

	/**
	 * Validate the actual JSON response against the expected JSON data from the
	 * file
	 * 
	 * @author sanoj.swaminathan
	 * @since 07-03-2023
	 * @param responseJson
	 * @param expectedJSONFileName
	 * @throws AutomationException 
	 */
	public void validateJsonResponseMatch(Response responseJson, String expectedJSONFileName) throws AutomationException {
		try {
			String expectedResponseDataPath = System.getProperty("user.dir") + AutomationConstants.API_RESPONSE_DATA
					+ expectedJSONFileName + ".json";
			String actualJson = responseJson.getBody().asString();
			String expectedJson = FileUtils.readFileToString(new File(expectedResponseDataPath), "utf-8");
			JSONAssert.assertEquals(expectedJson, actualJson, JSONCompareMode.STRICT);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Validate JsonPath from the response
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param responseData
	 * @param jsonPath
	 * @return
	 */
	public boolean validateJsonPath(Response responseData, String jsonPath) throws AutomationException {
		try {
			String responseBody = responseData.getBody().asString();
			assertThat(responseBody, hasJsonPath(jsonPath));
			Log.message(jsonPath + " is in " + responseBody);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Validate JsonPath to string value
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param responseData
	 * @param jsonPath
	 * @param valueToValidate
	 * @return
	 */
	public boolean validateJsonPathToStringValue(Response responseData, String jsonPath, String valueToValidate)
			throws AutomationException {
		try {
			String responseBody = responseData.getBody().asString();
			assertThat(responseBody, hasJsonPath(jsonPath, equalTo(valueToValidate)));
			Log.message(valueToValidate + " is in " + responseBody);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Validate JsonPath to integer value
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param responseData
	 * @param jsonPath        like data.id
	 * @param valueToValidate
	 * @return
	 */
	public boolean validateJsonPathToIntegerValue(Response responseData, String jsonPath, int valueToValidate)
			throws AutomationException {
		try {
			String responseBody = responseData.getBody().asString();
			assertThat(responseBody, hasJsonPath(jsonPath, equalTo(valueToValidate)));
			Log.message(valueToValidate + " is in " + responseBody);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Validate JsonPath to boolean value
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param responseData
	 * @param jsonPath        like data.id
	 * @param valueToValidate
	 * @return
	 */
	public boolean validateJsonPathToBooleanValue(Response responseData, String jsonPath, boolean valueToValidate)
			throws AutomationException {
		try {
			String responseBody = responseData.getBody().asString();
			assertThat(responseBody, hasJsonPath(jsonPath, equalTo(valueToValidate)));
			Log.message(valueToValidate + " is in " + responseBody);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Validate JsonPath to null value
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param responseData
	 * @param jsonPath        like data.id
	 * @param valueToValidate
	 * @return
	 */
	public boolean validateJsonPathToNullValue(Response responseData, String jsonPath) throws AutomationException {
		try {
			String responseBody = responseData.getBody().asString();
			assertThat(responseBody, isJson(withJsonPath(jsonPath)));
			assertThat(responseBody, hasJsonPath(jsonPath, nullValue()));
			Log.message(jsonPath + " has null value in " + responseBody);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Validate the empty response
	 * 
	 * @author sanoj.swaminathan
	 * @since 07-03-2023
	 * @param responseData
	 * @return
	 */
	public boolean validateEmptyResponse(Response responseData) throws AutomationException {
		try {
			String responseBody = responseData.getBody().asString();
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode jsonNode = objectMapper.readTree(responseBody);
			boolean isEmptyObject = jsonNode.isObject() && jsonNode.size() == 0;
			assertTrue(isEmptyObject, "Response data is not empty");
			Log.message("Response data is empty");
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Validate the status line from the response
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param expectedStatusLine
	 * @param responseData
	 * @return
	 */
	public boolean validateStatusLine(Response responseData, String expectedStatusLine) throws AutomationException {

		try {
			String actualStatusLine = responseData.getStatusLine();
			Assert.assertEquals(actualStatusLine, expectedStatusLine);
			Log.message(actualStatusLine + " is matches " + expectedStatusLine);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Validate the header from the response
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param responseData
	 * @param headerName
	 * @param expectedHeaderValue
	 * @return
	 */
	public boolean validateHeader(Response responseData, String headerName, String expectedHeaderValue)
			throws AutomationException {
		try {
			String actualHeaderValue = responseData.getHeader(headerName);
			Assert.assertEquals(actualHeaderValue, expectedHeaderValue);
			Log.message(actualHeaderValue + " is matches " + expectedHeaderValue);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Validate the ContentType from the response
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param expectedStatusLine
	 * @param responseData
	 * @return
	 */
	public boolean validateContentType(Response responseData, String expectedContentType) throws AutomationException {

		try {
			String actualContentType = responseData.getContentType();
			Assert.assertEquals(actualContentType, expectedContentType);
			Log.message(actualContentType + " is matches " + expectedContentType);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Validate the SessionId from the response
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-04-2021
	 * @param responseData
	 * @param expectedSessionId
	 * @return
	 */
	public boolean validateSessionId(Response responseData, String expectedSessionId) throws AutomationException {

		try {
			String actualSessionId = responseData.getSessionId();
			Assert.assertEquals(actualSessionId, expectedSessionId);
			Log.message(actualSessionId + " is matches " + expectedSessionId);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * Validate the response schema for a get request. Need to pass the JSON schema
	 * file name and the file should be available in
	 * /src/test/resources/APITesting/JSONSchema/ location
	 * 
	 * @author sanoj.swaminathan
	 * @since 28-11-2023
	 * @param baseURI
	 * @param endPointPath
	 * @param schemaFileName
	 */
	public void validateGetResponseSchema(String baseURI, String endPointPath, String schemaFileName) {
		String schemaFile = System.getProperty("user.dir") + AutomationConstants.API_JSON_SCHEMA + schemaFileName
				+ ".json";
		RestAssured.given().baseUri(baseURI).basePath(endPointPath).when().get().then().assertThat()
				.body(JsonSchemaValidator.matchesJsonSchema(new File(schemaFile).getAbsoluteFile()));
	}

	/**
	 * Validate the response schema for a post request. Need to pass the JSON schema
	 * file name and the file should be available in
	 * /src/test/resources/APITesting/JSONSchema/ location.
	 * 
	 * @author sanoj.swaminathan
	 * @since 28-11-2023
	 * @param baseURI
	 * @param endPointPath
	 * @param payloadFileName
	 * @param contentType
	 * @param schemaFileName
	 */
	public void validatePostResponseSchema(String baseURI, String endPointPath, String payloadFileName,
			String contentType, String schemaFileName) {
		String payloadPath = System.getProperty("user.dir") + AutomationConstants.API_REQUEST_PAYLOAD + payloadFileName
				+ ".json";
		String schemaFile = System.getProperty("user.dir") + AutomationConstants.API_JSON_SCHEMA + schemaFileName
				+ ".json";
		RestAssured.given().baseUri(baseURI).basePath(endPointPath).body(new File(payloadPath).getAbsoluteFile())
				.contentType(contentType).log().all().when().post().andReturn().then().assertThat()
				.body(JsonSchemaValidator.matchesJsonSchema(new File(schemaFile).getAbsoluteFile()));
	}

	/**
	 * Validate the response schema for a put request. Need to pass the JSON schema
	 * file name and the file should be available in
	 * /src/test/resources/APITesting/JSONSchema/ location.
	 * 
	 * @author sanoj.swaminathan
	 * @since 28-11-2023
	 * @param baseURI
	 * @param endPointPath
	 * @param payloadFileName
	 * @param contentType
	 * @param schemaFileName
	 */
	public void validatePutResponseSchema(String baseURI, String endPointPath, String payloadFileName,
			String contentType, String schemaFileName) {
		String payloadPath = System.getProperty("user.dir") + AutomationConstants.API_REQUEST_PAYLOAD + payloadFileName
				+ ".json";
		String schemaFile = System.getProperty("user.dir") + AutomationConstants.API_JSON_SCHEMA + schemaFileName
				+ ".json";
		RestAssured.given().baseUri(baseURI).basePath(endPointPath).body(new File(payloadPath).getAbsoluteFile())
				.contentType(contentType).log().all().when().put().andReturn().then().assertThat()
				.body(JsonSchemaValidator.matchesJsonSchema(new File(schemaFile).getAbsoluteFile()));
	}

	/**
	 * Validate the response schema for a patch request. Need to pass the JSON
	 * schema file name and the file should be available in
	 * /src/test/resources/APITesting/JSONSchema/ location.
	 * 
	 * @author sanoj.swaminathan
	 * @since 28-11-2023
	 * @param baseURI
	 * @param endPointPath
	 * @param payloadFileName
	 * @param contentType
	 * @param schemaFileName
	 */
	public void validatePatchResponseSchema(String baseURI, String endPointPath, String payloadFileName,
			String contentType, String schemaFileName) {
		String payloadPath = System.getProperty("user.dir") + AutomationConstants.API_REQUEST_PAYLOAD + payloadFileName
				+ ".json";
		String schemaFile = System.getProperty("user.dir") + AutomationConstants.API_JSON_SCHEMA + schemaFileName
				+ ".json";
		RestAssured.given().baseUri(baseURI).basePath(endPointPath).body(new File(payloadPath).getAbsoluteFile())
				.contentType(contentType).log().all().when().patch().andReturn().then().assertThat()
				.body(JsonSchemaValidator.matchesJsonSchema(new File(schemaFile).getAbsoluteFile()));
	}

	/**
	 * Validate the response schema for a get request. The JSON schema data read
	 * from the file path.
	 * 
	 * @author sanoj.swaminathan
	 * @since 28-11-2023
	 * @param baseURI
	 * @param endPointPath
	 * @param schemaFilePath
	 */
	public void validateGetResponseSchemaFromFilePath(String baseURI, String endPointPath, String schemaFilePath) {
		RestAssured.given().baseUri(baseURI).basePath(endPointPath).when().get().then().assertThat()
				.body(JsonSchemaValidator.matchesJsonSchema(new File(schemaFilePath).getAbsoluteFile()));
	}

	/**
	 * Validate the response schema for a post request. The JSON schema data read
	 * from the file path.
	 * 
	 * @author sanoj.swaminathan
	 * @since 28-11-2023
	 * @param baseURI
	 * @param endPointPath
	 * @param payloadFileName
	 * @param contentType
	 * @param schemaFilePath
	 */
	public void validatePostResponseSchemaFromFilePath(String baseURI, String endPointPath, String payloadFileName,
			String contentType, String schemaFilePath) {
		String payloadPath = System.getProperty("user.dir") + AutomationConstants.API_REQUEST_PAYLOAD + payloadFileName
				+ ".json";
		RestAssured.given().baseUri(baseURI).basePath(endPointPath).body(new File(payloadPath).getAbsoluteFile())
				.contentType(contentType).log().all().when().post().andReturn().then().assertThat()
				.body(JsonSchemaValidator.matchesJsonSchema(new File(schemaFilePath).getAbsoluteFile()));
	}

	/**
	 * Validate the response schema for a put request. The JSON schema data read
	 * from the file path.
	 * 
	 * @author sanoj.swaminathan
	 * @since 28-11-2023
	 * @param baseURI
	 * @param endPointPath
	 * @param payloadFileName
	 * @param contentType
	 * @param schemaFilePath
	 */
	public void validatePutResponseSchemaFromFilePath(String baseURI, String endPointPath, String payloadFileName,
			String contentType, String schemaFilePath) {
		String payloadPath = System.getProperty("user.dir") + AutomationConstants.API_REQUEST_PAYLOAD + payloadFileName
				+ ".json";
		RestAssured.given().baseUri(baseURI).basePath(endPointPath).body(new File(payloadPath).getAbsoluteFile())
				.contentType(contentType).log().all().when().put().andReturn().then().assertThat()
				.body(JsonSchemaValidator.matchesJsonSchema(new File(schemaFilePath).getAbsoluteFile()));
	}

	/**
	 * Validate the response schema for a patch request. The JSON schema data read
	 * from the file path.
	 * 
	 * @author sanoj.swaminathan
	 * @since 28-11-2023
	 * @param baseURI
	 * @param endPointPath
	 * @param payloadFileName
	 * @param contentType
	 * @param schemaFilePath
	 */
	public void validatePatchResponseSchemaFromFilePath(String baseURI, String endPointPath, String payloadFileName,
			String contentType, String schemaFilePath) {
		String payloadPath = System.getProperty("user.dir") + AutomationConstants.API_REQUEST_PAYLOAD + payloadFileName
				+ ".json";
		RestAssured.given().baseUri(baseURI).basePath(endPointPath).body(new File(payloadPath).getAbsoluteFile())
				.contentType(contentType).log().all().when().patch().andReturn().then().assertThat()
				.body(JsonSchemaValidator.matchesJsonSchema(new File(schemaFilePath).getAbsoluteFile()));
	}

	/**
	 * Validate the response schema for a get request.
	 * 
	 * @author sanoj.swaminathan
	 * @since 28-11-2023
	 * @param baseURI
	 * @param endPointPath
	 * @param JSONSchemaData
	 */
	public void validateGetResponseJSONSchemaData(String baseURI, String endPointPath, String JSONSchemaData) {
		RestAssured.given().baseUri(baseURI).basePath(endPointPath).when().get().then().assertThat()
				.body(JsonSchemaValidator.matchesJsonSchema(JSONSchemaData));
	}

	/**
	 * Validate the response schema for a post request.
	 * 
	 * @author sanoj.swaminathan
	 * @since 28-11-2023
	 * @param baseURI
	 * @param endPointPath
	 * @param payloadFileName
	 * @param contentType
	 * @param JSONSchemaData
	 */
	public void validatePostResponseJSONSchemaData(String baseURI, String endPointPath, String payloadFileName,
			String contentType, String JSONSchemaData) {
		String payloadPath = System.getProperty("user.dir") + AutomationConstants.API_REQUEST_PAYLOAD + payloadFileName
				+ ".json";
		RestAssured.given().baseUri(baseURI).basePath(endPointPath).body(new File(payloadPath).getAbsoluteFile())
				.contentType(contentType).log().all().when().post().andReturn().then().assertThat()
				.body(JsonSchemaValidator.matchesJsonSchema(JSONSchemaData));
	}

	/**
	 * Validate the response schema for a put request.
	 * 
	 * @author sanoj.swaminathan
	 * @since 28-11-2023
	 * @param baseURI
	 * @param endPointPath
	 * @param payloadFileName
	 * @param contentType
	 * @param JSONSchemaData
	 */
	public void validatePutResponseJSONSchemaData(String baseURI, String endPointPath, String payloadFileName,
			String contentType, String JSONSchemaData) {
		String payloadPath = System.getProperty("user.dir") + AutomationConstants.API_REQUEST_PAYLOAD + payloadFileName
				+ ".json";
		RestAssured.given().baseUri(baseURI).basePath(endPointPath).body(new File(payloadPath).getAbsoluteFile())
				.contentType(contentType).log().all().when().put().andReturn().then().assertThat()
				.body(JsonSchemaValidator.matchesJsonSchema(JSONSchemaData));
	}

	/**
	 * Validate the response schema for a patch request.
	 * 
	 * @author sanoj.swaminathan
	 * @since 28-11-2023
	 * @param baseURI
	 * @param endPointPath
	 * @param payloadFileName
	 * @param contentType
	 * @param JSONSchemaData
	 */
	public void validatePatchResponseJSONSchemaData(String baseURI, String endPointPath, String payloadFileName,
			String contentType, String JSONSchemaData) {
		String payloadPath = System.getProperty("user.dir") + AutomationConstants.API_REQUEST_PAYLOAD + payloadFileName
				+ ".json";
		RestAssured.given().baseUri(baseURI).basePath(endPointPath).body(new File(payloadPath).getAbsoluteFile())
				.contentType(contentType).log().all().when().patch().andReturn().then().assertThat()
				.body(JsonSchemaValidator.matchesJsonSchema(JSONSchemaData));
	}
}
