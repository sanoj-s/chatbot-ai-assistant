package com.autobots.keywords;

import java.util.ArrayList;

import com.autobots.exception.AutomationException;
import com.autobots.utils.DatabaseConnectionUtility;
import com.autobots.utils.Log;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseActions extends DatabaseConnectionUtility {
	ResultSet res;

	public DatabaseActions() throws AutomationException {
		stmt = new DatabaseConnectionUtility().createConnectionStatement();
	}

	/**
	 * Method to retrieve data from a table
	 * 
	 * @author sanoj.swaminathan
	 * @since 02-03-2023
	 * @param query
	 * @return ResultSet
	 * @throws AutomationException
	 */
	public ResultSet getTableData(String query) throws AutomationException {
		try {
			if (query == null || query.equals("")) {
				throw new AutomationException("");
			}
		} catch (Exception e) {
			Log.exception(e);
			
		}
		try {
			res = stmt.executeQuery(query);
		} catch (Exception e) {
			Log.exception(e);
			
		}
		return res;
	}

	/**
	 * Method to retrieve integer data from a table based on the column number
	 * 
	 * @author sanoj.swaminathan
	 * @since 02-03-2023
	 * @param resultSet
	 * @param colIndex
	 * @return list
	 */
	public ArrayList<Integer> getIntegerValuesbyColNum(ResultSet resultSet, int colIndex)
			throws SQLException, AutomationException {
		ArrayList<Integer> list = new ArrayList<Integer>();
		while (resultSet.next()) {
			list.add(resultSet.getInt(colIndex));
		}
		 
		Log.message("The value for the column index " + colIndex + " is " + list);
		return list;
	}

	/**
	 * Method to retrieve String data from a table based on the column number
	 * 
	 * @author sanoj.swaminathan
	 * @since 02-03-2023
	 * @param resultSet
	 * @param colIndex
	 * @return list
	 */
	public ArrayList<String> getStringValuesbyColNum(ResultSet resultSet, int colIndex)
			throws SQLException, AutomationException {
		ArrayList<String> list = new ArrayList<String>();
		while (resultSet.next()) {
			list.add(resultSet.getString(colIndex));
		}
		Log.message("The value for the column index " + colIndex + " is " + list);
		return list;
	}

	/**
	 * Method to execute query
	 * 
	 * @author sanoj.swaminathan
	 * @since 02-03-2023
	 * @param stm
	 * @param query
	 * @throws AutomationException
	 */
	public void executeQuery(Statement stm, String query) throws AutomationException {
		try {
			if (query == null || query.equals("")) {
				throw new AutomationException("");
			}
		} catch (Exception e) {
			Log.exception(e);
			
		}
		try {
			stm.execute(query);
		} catch (Exception e) {
	        Log.exception(e);
		}
	}

}
