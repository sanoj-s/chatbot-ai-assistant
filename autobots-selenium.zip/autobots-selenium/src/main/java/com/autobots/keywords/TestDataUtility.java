package com.autobots.keywords;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Paths;
import java.security.GeneralSecurityException;
import java.util.HashMap;
import java.util.Hashtable;

import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.Assert;

/**
 * This class helps to read the test data from the excel sheet based on the
 * TestID mapped in the first column of a sheet. The TestID should be the test
 * script method name. The usage as below,
 * 
 * HashMap<String, String> testData = TestDataUtility .getTestData(new
 * Utilities().getTestDataPath("testDataPath"), "SampleTest");
 * 
 * In the above example, getTestData() method accept two parameters: workbook
 * path and the sheet name. The Excel workbook should be under the
 * src/test/resources folder.
 * 
 */
public class TestDataUtility {

	private String workBookName;
	private String workSheet;
	private String testCaseId;
	private boolean doFilePathMapping;
	private HashMap<String, String> data;
	private Hashtable<String, Integer> excelHeaders = new Hashtable<String, Integer>();
	private Hashtable<String, Integer> excelrRowColumnCount = new Hashtable<String, Integer>();

	public TestDataUtility() {
	}

	public TestDataUtility(String xlWorkBook, String xlWorkSheet) {
		this.workBookName = xlWorkBook;
		this.workSheet = xlWorkSheet;
	}

	public TestDataUtility(String xlWorkBook, String xlWorkSheet, String tcID) {
		this.workBookName = xlWorkBook;
		this.workSheet = xlWorkSheet;
		this.testCaseId = tcID;
	}

	public String getWorkBookName() {
		return workBookName;
	}

	public void setWorkBookName(String workBookName) {
		this.workBookName = workBookName;
	}

	public void setFilePathMapping(boolean doFilePathMapping) {
		this.doFilePathMapping = doFilePathMapping;
	}

	public String getWorkSheet() {
		return workSheet;
	}

	public void setWorkSheet(String workSheet) {
		this.workSheet = workSheet;
	}

	public String getTestCaseId() {
		return testCaseId;
	}

	public void setTestCaseId(String testCaseId) {
		this.testCaseId = testCaseId;
	}

	public String get(String key) {
		if (data.isEmpty())
			readData();
		return data.get(key);
	}

	/**
	 * Loading the test data from excel based on given workbook and sheet. The Excel
	 * workbook should be under the src/test/resources folder. Suppose the Excel
	 * file under TestData folder inside src/test/resources then in script we can
	 * pass the workbook value as "TestData\\TestData.xlsx".
	 *
	 * @author sanoj.swaminathan
	 * @since 25-06-2024
	 * @param workbook  - workbook name
	 * @param sheetName - sheet name
	 * @return testData - Data from Excel as HashMap format
	 * @throws GeneralSecurityException
	 * @throws IOException
	 */
	public static HashMap<String, String> getTestData(String workbook, String sheetName)
			throws IOException, GeneralSecurityException {
		// Get the testCaseId
		Throwable t = new Throwable();
		String testCaseId = t.getStackTrace()[1].getMethodName();

		TestDataUtility testData = new TestDataUtility();
		testData.setWorkBookName(workbook);
		testData.setWorkSheet(sheetName);
		testData.setFilePathMapping(true);
		testData.setTestCaseId(testCaseId);
		return testData.readData();
	}

	/**
	 * Fetch Data from Excel
	 * 
	 * @author sanoj.swaminathan
	 * @since 25-06-2024
	 * @return testData - Data from Excel as HashMap format
	 */
	private HashMap<String, String> readData() {
		HashMap<String, String> testData = new HashMap<String, String>();
		boolean isDataFound = false;
		testCaseId = testCaseId != null ? testCaseId.trim() : "";
		XSSFSheet sheet = null;
		XSSFRow row = null;
		XSSFCell cell = null;

		try {
			sheet = initiateExcelConnection(workSheet, workBookName, doFilePathMapping);
			excelrRowColumnCount = findRowColumnCount(sheet, excelrRowColumnCount);
			excelHeaders = readExcelHeaders(sheet, excelHeaders, excelrRowColumnCount);

			for (int r = 0; r < excelrRowColumnCount.get("RowCount"); r++) {
				row = sheet.getRow(r);
				if (row == null)
					continue;
				for (int c = 0; c < excelrRowColumnCount.get("ColumnCount"); c++) {
					if (row.getCell(excelHeaders.get("TestID")) == null)
						break;
					cell = row.getCell(excelHeaders.get("TestID"));
					if (!convertXSSFCellToString(cell).toString().equalsIgnoreCase(testCaseId))
						continue;
					isDataFound = true;
					for (String key : excelHeaders.keySet()) {
						testData.put(key, getCellValueAsString(row.getCell(excelHeaders.get(key))));
					}
					break;
				}
				if (isDataFound)
					break;
			}
			if (!isDataFound)
				Assert.fail("\nTest Data not found in test data sheet for Test Case Id  : " + testCaseId);
		} catch (RuntimeException e) {
			Assert.fail("Error During Execution; Execution Failed More details " + e);
		}
		data = testData;
		return testData;
	}

	/**
	 * Method to get the cell value as String
	 * 
	 * @author sanoj.swaminathan
	 * @since 25-05-2024
	 * @param cell
	 * @return
	 */
	private String getCellValueAsString(XSSFCell cell) {
		if (cell == null) {
			return "";
		}
		// Determine the cell type and convert to String accordingly
		CellType cellType = cell.getCellType();
		switch (cellType) {
		case STRING:
			return cell.getStringCellValue();
		case NUMERIC:
			// For numeric cells, we can use DataFormatter to get the formatted string
			// representation
			DataFormatter formatter = new DataFormatter();
			return formatter.formatCellValue(cell);
		case BOOLEAN:
			return String.valueOf(cell.getBooleanCellValue());
		case FORMULA:
			// If the cell contains a formula, evaluate it and return the result
			return cell.getCellFormula();
		case BLANK:
			return "";
		default:
			return "Unknown Cell Type";
		}
	}

	/**
	 * Loading the test data from excel based on given workbook, sheet and
	 * testCaseId. The Excel workbook should be under the src/test/resources folder.
	 * Suppose the Excel file under TestData folder inside src/test/resources then
	 * in script we can pass the workbook value as "TestData\\TestData.xlsx".
	 *
	 * @param workbook
	 * @param sheetName
	 * @param testCaseId
	 * @return
	 * @throws IOException
	 * @throws GeneralSecurityException
	 */
	public static HashMap<String, String> getTestData(String workbook, String sheetName, String testCaseId)
			throws IOException, GeneralSecurityException {
		TestDataUtility testData = new TestDataUtility();
		testData.setWorkBookName(workbook);
		testData.setWorkSheet(sheetName);
		testData.setFilePathMapping(true);
		testData.setTestCaseId(testCaseId);
		return testData.readExcelData();
	}

	/**
	 * Read data from excel
	 * 
	 * @author sanoj.swaminathan
	 * @since 25-06-2024
	 * @return
	 */
	private HashMap<String, String> readExcelData() {
		HashMap<String, String> testData = new HashMap<String, String>();
		boolean isDataFound = false;
		testCaseId = testCaseId != null ? testCaseId.trim() : "";
		XSSFSheet sheet = null;
		XSSFRow row = null;
		XSSFCell cell = null;

		try {
			sheet = initiateExcelDataConnection(workSheet, workBookName, doFilePathMapping);
			excelrRowColumnCount = findRowColumnCount(sheet, excelrRowColumnCount);
			excelHeaders = readExcelHeaders(sheet, excelHeaders, excelrRowColumnCount);

			for (int r = 0; r < excelrRowColumnCount.get("RowCount"); r++) {
				row = sheet.getRow(r);
				if (row == null)
					continue;
				for (int c = 0; c < excelrRowColumnCount.get("ColumnCount"); c++) {
					if (row.getCell(excelHeaders.get("TestID")) == null)
						break;
					cell = row.getCell(excelHeaders.get("TestID"));
					if (!convertXSSFCellToString(cell).toString().equalsIgnoreCase(testCaseId))
						continue;
					isDataFound = true;
					for (String key : excelHeaders.keySet()) {
						testData.put(key, convertXSSFCellToString(row.getCell(excelHeaders.get(key))));
					}
					break;
				}
				if (isDataFound)
					break;
			}
			if (!isDataFound)
				Assert.fail("\nTest Data not found in test data sheet for Test Case Id  : " + testCaseId);
		} catch (RuntimeException e) {
			Assert.fail("Error During Execution; Execution Failed More details " + e);
		}
		data = testData;
		return testData;
	}

	/**
	 * initiateExcelConnection function to establish an initial connection with a
	 * work sheet
	 * 
	 * @author sanoj.swaminathan
	 * @since 25-06-2024
	 * @param workSheet         (String)
	 * @param doFilePathMapping (boolean)
	 * @param workBookName      (String)
	 * @return HSSFSheet (Work sheet)
	 */
	private XSSFSheet initiateExcelConnection(String workSheet, String workBookName, boolean doFilePathMapping) {
		ZipSecureFile.setMinInflateRatio(-1.0d);
		String filePath = doFilePathMapping ? workBookName : workBookName.replace("\\", File.separator);

		try (FileInputStream fis = new FileInputStream(filePath); XSSFWorkbook workBook = new XSSFWorkbook(fis)) {

			return workBook.getSheet(workSheet);
		} catch (IOException e) {
			System.err.println("Error reading Excel file: " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * findRowColumnCount function to establish an initial connection with a work
	 * sheet
	 * 
	 * @author sanoj.swaminathan
	 * @since 25-06-2024
	 * @param sheet          : Sheet Name
	 * @param rowColumnCount (Hashtable)
	 * @return Hashtable (returns row count and column count)
	 */
	private Hashtable<String, Integer> findRowColumnCount(XSSFSheet sheet, Hashtable<String, Integer> rowColumnCount) {
		XSSFRow row = null;
		String temp = null;
		int rows = sheet.getPhysicalNumberOfRows();
		int cols = 0;
		int tmp = 0;
		int counter = 0;

		for (int i = 0; i < 10 || i < rows; i++) {
			row = sheet.getRow(i);
			if (row == null)
				continue;
			temp = convertXSSFCellToString(row.getCell(0));
			if (!temp.equals(""))
				counter++;

			tmp = sheet.getRow(i).getPhysicalNumberOfCells();
			if (tmp > cols)
				cols = tmp;
		}

		rowColumnCount.put("RowCount", counter);
		rowColumnCount.put("ColumnCount", cols);
		return rowColumnCount;
	}

	/**
	 * readExcelHeaders function to establish an initial connection with a work
	 * sheet
	 * 
	 * @author sanoj.swaminathan
	 * @since 25-06-2024
	 * @param sheet          : Sheet Name
	 * @param excelHeaders   : Excel Headers List
	 * @param rowColumnCount : Row and Column Count
	 * @return: Hashtable (Having Header column values)
	 */
	private Hashtable<String, Integer> readExcelHeaders(XSSFSheet sheet, Hashtable<String, Integer> excelHeaders,
			Hashtable<String, Integer> rowColumnCount) {
		XSSFRow row = null;
		XSSFCell cell = null;

		for (int r = 0; r < rowColumnCount.get("RowCount"); r++) {
			row = sheet.getRow(r);
			if (row == null)
				continue;
			for (int c = 0; c < rowColumnCount.get("ColumnCount"); c++) {
				cell = row.getCell(c);
				if (cell != null)
					excelHeaders.put(cell.toString(), c);
			}
			break;
		}
		return excelHeaders;
	}

	/**
	 * function will convert the HSSFCell type value to its equivalent string value
	 * 
	 * @author sanoj.swaminathan
	 * @since 25-06-2024
	 * @param cell : HSSFCell value
	 * @return cellValue
	 */
	private String convertXSSFCellToString(XSSFCell cell) {
		String cellValue = "";
		if (cell != null)
			cellValue = cell.toString().trim();
		return cellValue;
	}

	/**
	 * Method to establish an initial connection with a work sheet
	 * 
	 * @author sanoj.swaminathan
	 * @since 25-06-2024
	 * @param workSheet
	 * @param workBookName
	 * @param doFilePathMapping
	 * @return
	 */
	private XSSFSheet initiateExcelDataConnection(String workSheet, String workBookName, boolean doFilePathMapping) {
		ZipSecureFile.setMinInflateRatio(-1.0d);

		String filePath;
		try {
			String basePath = new File(".").getCanonicalPath();
			filePath = doFilePathMapping ? Paths.get(basePath, workBookName).toString() : workBookName;
		} catch (IOException e) {
			System.err.println("Error getting canonical path: " + e.getMessage());
			e.printStackTrace();
			return null;
		}

		try (FileInputStream fis = new FileInputStream(filePath); XSSFWorkbook workBook = new XSSFWorkbook(fis)) {

			return workBook.getSheet(workSheet);
		} catch (IOException e) {
			System.err.println("Error reading Excel file: " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
}
