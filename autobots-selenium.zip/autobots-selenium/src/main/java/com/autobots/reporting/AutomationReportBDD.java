package com.autobots.reporting;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.autobots.exception.AutomationException;
import com.autobots.keywords.DataHandler;
import com.autobots.utils.LiveDashboardConnector;
import com.autobots.utils.AutomationConstants;
import com.autobots.utils.AutomationMail;
import com.autobots.utils.KeyManagement;
import com.influxdb.client.write.Point;

public class AutomationReportBDD implements ITestListener {
	String reportPath = System.getProperty("user.dir") + "/Reports/";
	int successCount = 0, failureCount = 0, skippedCount = 0, testCount = 0;

	/**
	 * Method to set up the Execution Report
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-05-2023
	 * @throws Exception
	 */
	public void onStart(ITestContext testContext) {
		try {

			// Checking the execution expire
			KeyManagement.checkExpiry();
			System.out.println("TEST CASE EXECUTION STARTED");
		} catch (Exception lException) {
			lException.printStackTrace();
		}
	}

	/**
	 * Method to collect the test names
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-05-2023
	 * @param result
	 */
	public void onTestStart(ITestResult result) {
		try {

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to get the pass result of the execution
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-05-2023
	 * @throws IOException
	 */
	public void onTestSuccess(ITestResult result) {
		try {
			successCount++;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to get the fail result of the execution
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-05-2023
	 * @throws IOException
	 */
	public void onTestFailure(ITestResult result) {
		try {
			failureCount++;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to get the skip result of the execution
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-05-2023
	 * @throws IOException
	 */
	public void onTestSkipped(ITestResult result) {
		try {
			skippedCount++;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to tear down the report and to call the send mail method
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-05-2023
	 */
	public void onFinish(ITestContext testContext) {
		try {
			String actualReportPath = lastFileModified(reportPath).getAbsolutePath();
			DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy_HH-mm-ss");
			Date date = new Date();
			String filePathdate = dateFormat.format(date).toString();
			new File(actualReportPath).renameTo(new File(
					System.getProperty("user.dir") + "/Reports/" + "Automation_Report_" + filePathdate + ".html"));
			String isMailReportNeed = new DataHandler().getProperty(AutomationConstants.FRAMEWORK_CONFIG,
					"isMailReportNeed");
			if (isMailReportNeed.toLowerCase().equals("yes")) {
				new AutomationMail().sendMailReport();
			}
			System.out.println("TEST CASE EXECUTION COMPLETED");

			// publish the test results count to the AutoBots Dashboard
			String needRealtimeDashboardResults = new DataHandler().getProperty(AutomationConstants.FRAMEWORK_CONFIG,
					"needRealtimeDashboardResults");
			if (needRealtimeDashboardResults.toLowerCase().equals("yes")) {
				this.postTestStatusCount();
				System.out.println("PUBLISHED RESULTS TO DASHBOARD");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to post the test status count
	 * 
	 * @author sanoj.swaminathan
	 * @since 11-07-2023
	 */
	private void postTestStatusCount() {
		try {
			Point successPoint = Point.measurement("testCount").addField("Passed", successCount)
					.addField("Failed", failureCount).addField("Skipped", skippedCount);
			LiveDashboardConnector.publishResults(successPoint);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to get the latest modified report
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-05-2023
	 * @param filePath
	 * @throws AutomationException
	 */
	private File lastFileModified(String filePath) {
		File choice = null;
		try {
			File fl = new File(filePath);
			File[] files = fl.listFiles(new FileFilter() {

				public boolean accept(File file) {
					return file.isFile();
				}
			});
			long lastMod = Long.MIN_VALUE;
			for (File file : files) {
				if (file.lastModified() > lastMod) {
					choice = file;
					lastMod = file.lastModified();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return choice;
	}
}
