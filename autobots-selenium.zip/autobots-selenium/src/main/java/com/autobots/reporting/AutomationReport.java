package com.autobots.reporting;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.jfree.data.category.DefaultCategoryDataset;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.v129.network.Network;
import org.openqa.selenium.devtools.v129.network.model.Response;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.IExecutionListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.xml.XmlTest;

import com.autobots.base.AutomationBase;
import com.autobots.defectmanagement.JiraDefectManagement;
import com.autobots.exception.AutomationException;
import com.autobots.keywords.DataHandler;
import com.autobots.keywords.Utilities;
import com.autobots.testexecutor.TestSuiteGeneratorAndExecutor;
import com.autobots.testrailmanagement.TestRailManager;
import com.autobots.utils.AutomationConstants;
import com.autobots.utils.AutomationMail;
import com.autobots.utils.KeyManagement;
import com.autobots.utils.LiveDashboardConnector;
import com.autobots.utils.Log;
import com.autobots.utils.TestCaseConfig;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.aventstack.extentreports.reporter.configuration.ViewName;
import com.influxdb.client.write.Point;

import io.qameta.allure.Allure;

public class AutomationReport implements ITestListener, IExecutionListener {
	public static ExtentSparkReporter sparkReporter;
	public static ExtentReports extent;
	private static ThreadLocal<ExtentTest> testThreadLocal = new ThreadLocal<>();

	String reportPath = System.getProperty("user.dir") + "/Reports/";
	FileWriter fileWriter;
	String needNetworkLogs;
	int successCount = 0, failureCount = 0, skippedCount = 0, testCount = 0;

	private long startTime;
	private DefaultCategoryDataset individualTestDataset = new DefaultCategoryDataset();
	private DefaultCategoryDataset totalExecutionHistoryDataset = new DefaultCategoryDataset();

	/**
	 * Method to set up the Execution Report
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @throws Exception
	 */
	public void onStart(ITestContext testContext) {
		try {

			// Checking the execution expire
			KeyManagement.checkExpiry();

			String projectName = new DataHandler().getProperty(AutomationConstants.AUTOMATION_TEST_CONFIG,
					AutomationConstants.PROJECTNAME);
			String executionEnvironment = new DataHandler().getPropertyFromFilePath(
					AutomationConstants.AUTOMATION_TEST_CONFIG_FILE_PATH, AutomationConstants.EXECUTION_ENVIRONMENT);
			String testEnvironment = new DataHandler().getProperty(AutomationConstants.AUTOMATION_TEST_CONFIG,
					AutomationConstants.TEST_ENVIRONMENT);

			// To get the current date and time in the report file name
			LocalDateTime currentTime = LocalDateTime.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy_HH-mm-ss");
			String reportName = "Automation_Report_" + currentTime.format(formatter) + ".html";
			sparkReporter = new ExtentSparkReporter(reportPath + reportName)
					.viewConfigurer().viewOrder().as(new ViewName[] { ViewName.DASHBOARD, ViewName.CATEGORY,
							ViewName.TEST, ViewName.AUTHOR, ViewName.DEVICE, ViewName.EXCEPTION, ViewName.LOG })
					.apply();
			XmlTest test = testContext.getCurrentXmlTest();
			extent = new ExtentReports();
			extent.attachReporter(sparkReporter);
			if (projectName.equals("")) {
				projectName = "Default Project";
			}
			if (executionEnvironment.equals("")) {
				executionEnvironment = "Local";
			}
			if (testEnvironment.equals("")) {
				testEnvironment = "QA";
			}
			extent.setSystemInfo("Project Name", projectName);
			extent.setSystemInfo("Execution Environment", executionEnvironment);
			extent.setSystemInfo("Test Environment", testEnvironment);
			if (test.getParameter("browserName") != null) {
				extent.setSystemInfo("Browser Name", test.getParameter("browserName").toString());
			}
			extent.setSystemInfo("Host Name", InetAddress.getLocalHost().getHostName());
			extent.setSystemInfo("IP address", InetAddress.getLocalHost().getHostAddress());
			extent.setSystemInfo("Operating System", System.getProperty("os.name"));
			sparkReporter.config().setDocumentTitle("Test Automation");
			sparkReporter.config().setReportName("Automation Execution Report");
			sparkReporter.config().setTheme(Theme.DARK);
			sparkReporter.config().setTimeStampFormat("MMM dd, yyyy HH:mm:ss");

			// To clear the Allure Results
			String needAllureReport = new DataHandler().getProperty(AutomationConstants.FRAMEWORK_CONFIG,
					"needAllureReport");
			if (needAllureReport.toLowerCase().equalsIgnoreCase("yes")) {
				new AllureReportCore().clearAllureResults();
			}

		} catch (Exception lException) {
			try {
				Log.exception(lException);
			} catch (AutomationException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Method to collect the test names
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param result
	 */
	public void onTestStart(ITestResult result) {
		try {
			String testName = result.getMethod().getMethodName();
			ExtentTest test = extent.createTest(testName);
			testThreadLocal.set(test);

			// Track the network logs
			needNetworkLogs = new DataHandler().getProperty(AutomationConstants.FRAMEWORK_CONFIG,
					AutomationConstants.NEED_NETWORK_LOGS);
			if (needNetworkLogs.equals("")) {
				needNetworkLogs = "No";
			}
			if (needNetworkLogs.equalsIgnoreCase("yes")) {
				trackNetworkLogs(result, testName);
			}
		} catch (Exception e) {
			try {
				Log.exception(e);
			} catch (AutomationException ex) {
				ex.printStackTrace();
			}
		}

		// For Automation Execution Time Trends Report
		startTime = System.currentTimeMillis();
	}

	/**
	 * Method to track the network logs and generate log files in the project
	 * structure under //Logs//Network_logs folder
	 * 
	 * @author sanoj.swaminathan
	 * @since 27-06-2023
	 * @param result
	 * @param testName
	 * @throws AutomationException
	 */
	private void trackNetworkLogs(ITestResult result, String testName) throws AutomationException {
		try {
			WebDriver driver = null;
			Object currentClass = result.getInstance();
			try {
				driver = ((AutomationBase) currentClass).getDriver();
			} catch (Exception e) {
			}

			DevTools devTools = null;
			if (driver instanceof EdgeDriver) {
				devTools = ((EdgeDriver) driver).getDevTools();
			} else if (driver instanceof ChromeDriver) {
				devTools = ((ChromeDriver) driver).getDevTools();
			} else {
				Log.info("Network logs supported for Edge and Chrome browsers");
			}
			if (devTools != null) {
				devTools.createSession();
				devTools.send(Network.enable(Optional.empty(), Optional.empty(), Optional.empty()));

				if (!new File(System.getProperty("user.dir") + "//Logs//Network_logs").exists()) {
					(new File(System.getProperty("user.dir") + "//Logs")).mkdir();
					(new File(System.getProperty("user.dir") + "//Logs//Network_logs")).mkdir();
				}
				fileWriter = new FileWriter(new File(System.getProperty("user.dir") + "\\Logs\\Network_logs\\"
						+ testName + "_" + getCurrentDateAndTime() + ".txt"));

				devTools.addListener(Network.responseReceived(), responseReceived -> {
					Response response = responseReceived.getResponse();
					String log = "Network Log: " + response.getUrl() + "\n";

					try {
						fileWriter.write(log);
					} catch (IOException e) {
						try {
							Log.exception(e);
						} catch (AutomationException ex) {
							ex.printStackTrace();
						}
					}
					try {
						fileWriter.flush();
					} catch (IOException e) {
						try {
							Log.exception(e);
						} catch (AutomationException exe) {
							exe.printStackTrace();
						}
					}
				});
				Log.info("Network logs for " + testName + " is avaialble at " + System.getProperty("user.dir")
						+ "\\Logs\\Network_logs\\" + testName + "_" + getCurrentDateAndTime() + ".txt");
			}
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to get the current date and time
	 * 
	 * @author sanoj.swaminathan
	 * @since 27-06-2023
	 * @return
	 */
	private static String getCurrentDateAndTime() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		DateFormat timeFormat = new SimpleDateFormat("HH-mm-ss");
		Date date = new Date();
		String currdate = dateFormat.format(date);
		String currtime = timeFormat.format(date);
		return currdate + "_" + currtime;
	}

	/**
	 * Method to get the pass result of the execution
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @throws IOException
	 */
	public void onTestSuccess(ITestResult result) {
		try {
			successCount++;

			WebDriver driver = null;
			ExtentTest test = testThreadLocal.get();
			test.log(Status.PASS,
					MarkupHelper.createLabel(result.getName() + " test case is passed", ExtentColor.GREEN));
			Object currentClass = result.getInstance();
			try {
				driver = ((AutomationBase) currentClass).getDriver();
			} catch (Exception e) {
			}
			if (driver != null) {
				String needScreenshotForTestCasePass = new DataHandler().getProperty(
						AutomationConstants.FRAMEWORK_CONFIG, AutomationConstants.SCREENSHOT_ON_TEST_CASE_PASS);
				if (needScreenshotForTestCasePass.equalsIgnoreCase("yes")) {
					test.addScreenCaptureFromPath(new Utilities().captureScreenshot(driver, result.getName()),
							result.getName());
				}
			}
			Log.message("Test case: " + result.getName() + " is pass");

			// publish the results to TestRail
			String needTestResultPublishToTestRail = new DataHandler().getProperty(AutomationConstants.FRAMEWORK_CONFIG,
					"needTestResultPublishToTestRail");
			if (needTestResultPublishToTestRail.toLowerCase().equals("yes")) {
				TestCaseConfig testCasePolicy = result.getMethod().getConstructorOrMethod().getMethod()
						.getAnnotation(TestCaseConfig.class);
				if (testCasePolicy != null) {
					int testCaseIDValue = testCasePolicy.testRailTestCaseID();
					TestRailManager.addResultsForTestCase(testCaseIDValue, AutomationConstants.TEST_CASE_PASS_STATUS,
							"");
				}
			}

			// Update the test results to Excel when the test case pass
			String updateTestStatusToExcelReport = new DataHandler().getProperty(AutomationConstants.FRAMEWORK_CONFIG,
					AutomationConstants.UPDATE_TEST_STATUS_TO_EXCEL);
			if (updateTestStatusToExcelReport.equalsIgnoreCase("yes")) {
				TestSuiteGeneratorAndExecutor.updateTestResultsToExcel(result.getName(), "PASSED");
			} else {
				Log.info("Test results not updated in the Excel for " + result.getName()
						+ ". Please enable needTestResultPublishToExcelReport in framework_config.properties file.");
			}
		} catch (Exception e) {
			try {
				Log.exception(e);
			} catch (AutomationException ex) {
				ex.printStackTrace();
			}
		}

		// For Automation Execution Time Trends Report
		addExecutionTime(result);
	}

	/**
	 * Method to get the fail result of the execution
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @throws IOException
	 */
	public void onTestFailure(ITestResult result) {
		try {
			failureCount++;

			WebDriver driver = null;
			ExtentTest test = testThreadLocal.get();
			test.log(Status.FAIL, MarkupHelper
					.createLabel(result.getName() + " test case is failed due to below issues:", ExtentColor.RED));
			test.fail(result.getThrowable());
			Object currentClass = result.getInstance();
			try {
				driver = ((AutomationBase) currentClass).getDriver();
			} catch (Exception e) {
			}
			if (driver != null) {
				String screehotPath = new Utilities().captureScreenshot(driver, result.getName());
				test.addScreenCaptureFromPath(screehotPath, result.getName());
				try {
					String needAllureReport = new DataHandler().getProperty(AutomationConstants.FRAMEWORK_CONFIG,
							"needAllureReport");
					if (needAllureReport.toLowerCase().equalsIgnoreCase("yes")) {
						Allure.addAttachment(result.getName() + ".jpg", screehotPath);
					}
				} catch (Exception e) {
					Log.exception(e);
				}
			}
			Log.fail("Test case: " + result.getName() + " is failed");

			// publish the results to TestRail
			String needTestResultPublishToTestRail = new DataHandler().getProperty(AutomationConstants.FRAMEWORK_CONFIG,
					"needTestResultPublishToTestRail");
			if (needTestResultPublishToTestRail.toLowerCase().equals("yes")) {
				TestCaseConfig testCasePolicy = result.getMethod().getConstructorOrMethod().getMethod()
						.getAnnotation(TestCaseConfig.class);
				if (testCasePolicy != null) {
					int testCaseIDValue = testCasePolicy.testRailTestCaseID();
					TestRailManager.addResultsForTestCase(testCaseIDValue, AutomationConstants.TEST_CASE_FAIL_STATUS,
							result.getThrowable().toString());
				}
			}

			// Track bug into JIRA
			String logDefectsToJira = new DataHandler().getProperty(AutomationConstants.FRAMEWORK_CONFIG,
					AutomationConstants.LOG_DEFECTS_TO_JIRA);
			if (logDefectsToJira.equalsIgnoreCase("yes")) {
				new JiraDefectManagement().logDefectToJira(result);
			}

			// Update the test results to Excel when the test case fails
			String updateTestStatusToExcelReport = new DataHandler().getProperty(AutomationConstants.FRAMEWORK_CONFIG,
					AutomationConstants.UPDATE_TEST_STATUS_TO_EXCEL);
			if (updateTestStatusToExcelReport.equalsIgnoreCase("yes")) {
				TestSuiteGeneratorAndExecutor.updateTestResultsToExcel(result.getName(), "FAILED");
			} else {
				Log.info("Test results not updated in the Excel for " + result.getName()
						+ ". Please enable needTestResultPublishToExcelReport in framework_config.properties file.");
			}
		} catch (Exception e) {
			try {
				Log.exception(e);
			} catch (AutomationException ex) {
				ex.printStackTrace();
			}
		}

		// For Automation Execution Time Trends Report
		addExecutionTime(result);
	}

	/**
	 * Method to get the skip result of the execution
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @throws IOException
	 */
	public void onTestSkipped(ITestResult result) {
		try {
			skippedCount++;

			ExtentTest test = testThreadLocal.get();
			test.log(Status.SKIP,
					MarkupHelper.createLabel(result.getName() + " test case is skipped", ExtentColor.ORANGE));
			test.skip(result.getThrowable());
			Log.message("Test case: " + result.getName() + " is skipped");

		} catch (Exception e) {
			try {
				Log.exception(e);
			} catch (AutomationException ex) {
				ex.printStackTrace();
			}
		}

		// For Automation Execution Time Trends Report
		addExecutionTime(result);
	}

	/**
	 * Method to tear down the report and to call the send mail method
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 */
	public void onFinish(ITestContext testContext) {
		try {
			extent.flush();
			testThreadLocal.remove();

			// To send the report as email
			String isMailReportNeed = new DataHandler().getProperty(AutomationConstants.FRAMEWORK_CONFIG,
					"isMailReportNeed");
			if (isMailReportNeed.toLowerCase().equals("yes")) {
				new AutomationMail().sendMailReport();
			}
			Log.info("TEST CASE EXECUTION COMPLETED");

			// publish the test results count to the AutoBots Dashboard
			String needRealtimeDashboardResults = new DataHandler().getProperty(AutomationConstants.FRAMEWORK_CONFIG,
					AutomationConstants.NEED_REALTIME_DASHBOARD_RESULTS);
			if (needRealtimeDashboardResults.toLowerCase().equals("yes")) {
				this.postTestStatusCount();
				Log.info("PUBLISHED RESULTS TO DASHBOARD");
			}

			// Generate Execution Time Report
			String needTimeTrendsReports = new DataHandler().getProperty(AutomationConstants.FRAMEWORK_CONFIG,
					AutomationConstants.NEED_TIME_TRENDS_REPORT);
			if (needTimeTrendsReports.toLowerCase().equals("yes")) {
				generateExecutionTimeReportWithGraph(testContext);
			}

		} catch (Exception e) {
			try {
				Log.exception(e);
			} catch (AutomationException ex) {
				ex.printStackTrace();
			}
		}
	}

	@Override
	public void onExecutionFinish() {

		// Close the network logs
		try {
			needNetworkLogs = new DataHandler().getProperty(AutomationConstants.FRAMEWORK_CONFIG,
					AutomationConstants.NEED_NETWORK_LOGS);
			if (needNetworkLogs.equalsIgnoreCase("yes") && fileWriter != null) {
				fileWriter.close();
			}
		} catch (IOException | AutomationException e) {
			try {
				Log.exception(e);
			} catch (AutomationException ex) {
				ex.printStackTrace();
			}
		}

		// To generate Allure Report
		try {
			String needAllureReport = new DataHandler().getProperty(AutomationConstants.FRAMEWORK_CONFIG,
					"needAllureReport");
			if (needAllureReport.toLowerCase().equalsIgnoreCase("yes")) {
				new AllureReportCore().generateAllureReport();
			} else if (needAllureReport.toLowerCase().equalsIgnoreCase("no")) {
				new AllureReportCore().clearAllureResults();
			}
		} catch (AutomationException e) {
			try {
				Log.exception(e);
			} catch (AutomationException ex) {
				ex.printStackTrace();
			}
		}
	}

	/**
	 * Method to post the test status count
	 * 
	 * @author sanoj.swaminathan
	 * @throws AutomationException
	 * @since 11-07-2023
	 */
	private void postTestStatusCount() throws AutomationException {
		try {
			Point successPoint = Point.measurement("testCount").addField("Passed", successCount)
					.addField("Failed", failureCount).addField("Skipped", skippedCount);
			LiveDashboardConnector.publishResults(successPoint);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to track the steps on the HTML report with screenshot
	 * 
	 * @author sanoj.swaminathan
	 * @since 04-07-2023
	 * @param stepAction
	 * @throws AutomationException
	 */
	public void trackSteps(WebDriver driver, String stepAction) throws AutomationException {
		try {
			ExtentTest test = testThreadLocal.get();
			String needVisualStepsInReport = new DataHandler().getProperty(AutomationConstants.FRAMEWORK_CONFIG,
					"needVisualStepsInReport");
			if (needVisualStepsInReport.toLowerCase().equals("yes") && driver != null && test != null) {
				String screenshotPath = captureScreenshot(driver);
				test.log(Status.INFO, stepAction,
						MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
			} else {
				trackSteps(stepAction);
			}
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to capture the screenshot and return base64 image path
	 * 
	 * @author sanoj.swaminathan
	 * @since 04-07-2023
	 * @param driver
	 * @return
	 * @throws AutomationException
	 */
	private String captureScreenshot(WebDriver driver) throws AutomationException {
		try {
			TakesScreenshot ts = (TakesScreenshot) driver;
			String screenshotBase64 = ts.getScreenshotAs(OutputType.BASE64);
			return "data:image/png;base64," + screenshotBase64;
		} catch (Exception e) {
			Log.exception(e);
			return "";
		}
	}

	/**
	 * Method to track the steps on the HTML report
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param stepAction
	 * @throws AutomationException
	 */
	public void trackSteps(String stepAction) throws AutomationException {
		try {
			ExtentTest test = testThreadLocal.get();
			if (test != null) {
				test.log(Status.INFO, MarkupHelper.createCodeBlock(stepAction));
			}
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to track the category on the HTML report
	 * 
	 * @author sanoj.swaminathan
	 * @since 20-04-2020
	 * @param categoryName
	 * @throws AutomationException
	 */
	public void assignCategory(String categoryName) throws AutomationException {
		try {
			ExtentTest test = testThreadLocal.get();
			test.assignCategory(categoryName);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Method to Automation Execution Time Trends Report
	 * 
	 * @author sanoj.swaminathan
	 * @since 05-11-2024
	 * @throws IOException
	 */
	private void generateExecutionTimeReportWithGraph(ITestContext testContext) throws IOException {
		double totalExecutionTime = 0.0;
		int totalTestCases = individualTestDataset.getColumnCount();
		int successCount = 0;
		int failureCount = 0;
		int skippedCount = 0;

		for (int i = 0; i < totalTestCases; i++) {
			double executionTime = individualTestDataset.getValue(0, i).doubleValue();
			totalExecutionTime += executionTime;

			String testStatus = testStatusMap.get(individualTestDataset.getColumnKey(i).toString());
			if (testStatus.equals("PASSED")) {
				successCount++;
			} else if (testStatus.equals("FAILED")) {
				failureCount++;
			} else if (testStatus.equals("SKIPPED")) {
				skippedCount++;
			}
		}

		String suiteName = testContext.getSuite().getName();
		String dateTimeValue = new SimpleDateFormat("dd-MM-yyyy HH:mm").format(new Date());

		// order in CSV:
		// DateTime,SuiteName,ExecutionTime,TotalTests,Passed,Failed,Skipped
		File reportDirectory = new File("Reports/Execution_Time_Report");
		if (!reportDirectory.exists()) {
			reportDirectory.mkdirs();
		}

		try (FileWriter writer = new FileWriter(new File(reportDirectory, "execution_history.csv"), true)) {
			writer.write(dateTimeValue + "," + suiteName + "," + totalExecutionTime + "," + totalTestCases + ","
					+ successCount + "," + failureCount + "," + skippedCount + "\n");
		} catch (IOException e) {
			e.printStackTrace();
		}

		// Load data for total execution history from CSV
		loadTotalExecutionHistory();

		// Generate the HTML report with inline JavaScript for chart rendering
		generateHtmlReportWithCharts(reportDirectory);
	}

	/**
	 * Generates the Automation Execution Time Trends HTML report with embedded line
	 * and bar charts using Chart.js
	 * 
	 * @author sanoj.swaminathan
	 * @since 04-11-2024
	 * @param reportDirectory
	 * @throws IOException
	 */
	private void generateHtmlReportWithCharts(File reportDirectory) throws IOException {
		loadTotalExecutionHistory();

		try (PrintWriter writer = new PrintWriter(new File(reportDirectory, "AutomationExecutionTimeTrends.html"))) {
			writer.println("<html><head>");
			writer.println("<script src='https://cdn.jsdelivr.net/npm/chart.js'></script>");
			writer.println("<style>canvas { margin: 20px; }</style>");
			writer.println("</head><body>");
			writer.println("<h1>Automation Execution Time Trends Report</h1>");

			writer.println("<div style='margin: 20px;'>");
			writer.println("<h2>Total Execution Time History</h2>");
			writer.println("<canvas id='totalExecutionChart' width='800' height='400'></canvas>");
			writer.println("</div>");

			writer.println("<div style='margin: 20px;'>");
			writer.println("<h2>Individual Test Case Execution Time Trends</h2>");
			writer.println("<canvas id='individualExecutionChart' width='800' height='400'></canvas>");
			writer.println("</div>");

			writer.println("<script>");

			// Single `executionData` definition with unique suite names
			writer.println("const executionData = {");
			for (Map.Entry<String, TestMetrics> entry : testMetricsMap.entrySet()) {
				writer.println("    '" + entry.getKey() + "': {");
				writer.println("        suiteName: '" + entry.getValue().getSuiteName() + "',");
				writer.println("        totalTests: " + entry.getValue().getTotalTests() + ",");
				writer.println("        passed: " + entry.getValue().getPassed() + ",");
				writer.println("        failed: " + entry.getValue().getFailed() + ",");
				writer.println("        skipped: " + entry.getValue().getSkipped());
				writer.println("    },");
			}
			writer.println("};");

			// Generate array of colors for different suites
			writer.println(
					"const colors = ['#8C42AD', '#4CAF50', '#2196F3', '#FFC107', '#FF5722', '#9C27B0', '#3F51B5'];");

			// Create a map to store data points for each suite
			writer.println("const suiteData = {};");
			writer.println("const labels = [");
			for (Object key : totalExecutionHistoryDataset.getColumnKeys()) {
				writer.print("'" + key.toString() + "',");
			}
			writer.println("];");

			// Initialize suiteData structure with unique suite names
			writer.println("const uniqueSuiteNames = new Set();");
			writer.println("Object.values(executionData).forEach(data => {");
			writer.println("    uniqueSuiteNames.add(data.suiteName);");
			writer.println("});");

			// Create dataset for each unique suite
			writer.println("Array.from(uniqueSuiteNames).forEach((suiteName, index) => {");
			writer.println("    suiteData[suiteName] = {");
			writer.println("        label: suiteName,");
			writer.println("        data: new Array(labels.length).fill(null),");
			writer.println("        borderColor: colors[index % colors.length],");
			writer.println("        fill: false,");
			writer.println("        spanGaps: true");
			writer.println("    };");
			writer.println("});");

			// Fill in the data points for each suite
			for (int i = 0; i < totalExecutionHistoryDataset.getColumnCount(); i++) {
				String dateTime = totalExecutionHistoryDataset.getColumnKey(i).toString();
				double value = Math.round(totalExecutionHistoryDataset.getValue(0, i).doubleValue());
				writer.println("if (executionData['" + dateTime + "']) {");
				writer.println("    const suiteName = executionData['" + dateTime + "'].suiteName;");
				writer.println("    if (suiteData[suiteName]) {");
				writer.println("        suiteData[suiteName].data[" + i + "] = " + value + ";");
				writer.println("    }");
				writer.println("}");
			}

			// Create the datasets array from suiteData
			writer.println("const datasets = Object.values(suiteData);");

			// Total Execution Time Chart
			writer.println("new Chart(document.getElementById('totalExecutionChart').getContext('2d'), {");
			writer.println("    type: 'line',");
			writer.println("    data: { labels: labels, datasets: datasets },");
			writer.println("    options: {");
			writer.println("        responsive: true,");
			writer.println("        plugins: {");
			writer.println("            tooltip: {");
			writer.println("                callbacks: {");
			writer.println("                    label: function(context) {");
			writer.println("                        const data = executionData[context.label];");
			writer.println("                        if (data && data.suiteName === context.dataset.label) {");
			writer.println("                            return [");
			writer.println("                                'Suite: ' + data.suiteName,");
			writer.println("                                'Total Execution Time: ' + context.raw + 's',");
			writer.println("                                'Total Tests: ' + data.totalTests,");
			writer.println("                                'Passed: ' + data.passed,");
			writer.println("                                'Failed: ' + data.failed,");
			writer.println("                                'Skipped: ' + data.skipped");
			writer.println("                            ];");
			writer.println("                        }");
			writer.println("                        return null;");
			writer.println("                    }");
			writer.println("                }");
			writer.println("            }");
			writer.println("        },");
			writer.println("        scales: {");
			writer.println("            x: { type: 'category' },");
			writer.println("            y: { beginAtZero: true }");
			writer.println("        }");
			writer.println("    }");
			writer.println("});");

			// *************************************************************************

			// Individual Test Execution Chart Data - Bar Chart
			writer.println("// Create test status mapping for tooltips");
			writer.println("const testStatus = {");
			for (int i = 0; i < individualTestDataset.getColumnCount(); i++) {
				String testName = individualTestDataset.getColumnKey(i).toString();
				writer.println("    '" + testName + "': '" + testStatusMap.get(testName) + "',");
			}
			writer.println("};");

			writer.println("const individualExecutionData = {");
			writer.println("    labels: [");
			for (int i = 0; i < individualTestDataset.getColumnCount(); i++) {
				writer.print("'" + individualTestDataset.getColumnKey(i).toString() + "',");
			}
			writer.println("],");
			writer.println("    datasets: [");
			writer.println("        {");
			writer.println("            label: 'Pass',");
			writer.println("            data: [");
			for (int i = 0; i < individualTestDataset.getColumnCount(); i++) {
				String testName = individualTestDataset.getColumnKey(i).toString();
				double roundedValue = Math.round(individualTestDataset.getValue(0, i).doubleValue());
				if (testStatusMap.get(testName).equals("PASSED")) {
					writer.print(roundedValue + ",");
				} else {
					writer.print("null,");
				}
			}
			writer.println("],");
			writer.println("            backgroundColor: '#4CAF50'");
			writer.println("        },");
			writer.println("        {");
			writer.println("            label: 'Fail',");
			writer.println("            data: [");
			for (int i = 0; i < individualTestDataset.getColumnCount(); i++) {
				String testName = individualTestDataset.getColumnKey(i).toString();
				double roundedValue = Math.round(individualTestDataset.getValue(0, i).doubleValue());
				if (testStatusMap.get(testName).equals("FAILED")) {
					writer.print(roundedValue + ",");
				} else {
					writer.print("null,");
				}
			}
			writer.println("],");
			writer.println("            backgroundColor: '#F44336'");
			writer.println("        },");
			writer.println("        {");
			writer.println("            label: 'Skip',");
			writer.println("            data: [");
			for (int i = 0; i < individualTestDataset.getColumnCount(); i++) {
				String testName = individualTestDataset.getColumnKey(i).toString();
				double roundedValue = Math.round(individualTestDataset.getValue(0, i).doubleValue());
				if (testStatusMap.get(testName).equals("SKIPPED")) {
					writer.print(roundedValue + ",");
				} else {
					writer.print("null,");
				}
			}
			writer.println("],");
			writer.println("            backgroundColor: '#9E9E9E'");
			writer.println("        }");
			writer.println("    ]");
			writer.println("};");

			// Create Individual Test Execution Chart - Bar Chart
			writer.println("new Chart(document.getElementById('individualExecutionChart').getContext('2d'), {");
			writer.println("    type: 'bar',");
			writer.println("    data: individualExecutionData,");
			writer.println("    options: {");
			writer.println("        responsive: true,");
			writer.println("        plugins: {");
			writer.println("            tooltip: {");
			writer.println("                callbacks: {");
			writer.println("                    label: function(context) {");
			writer.println("                        if (context.raw === null) return null;");
			writer.println("                        const testName = context.chart.data.labels[context.dataIndex];");
			writer.println("                        return [");
			writer.println("                            'Time Taken: ' + ': ' + context.raw + 's',");
			writer.println("                            'Status: ' + testStatus[testName]");
			writer.println("                        ];");
			writer.println("                    }");
			writer.println("                }");
			writer.println("            },");
			writer.println("            legend: {");
			writer.println("                display: true,");
			writer.println("                position: 'top'");
			writer.println("            }");
			writer.println("        },");
			writer.println("        scales: {");
			writer.println("            x: { stacked: true },");
			writer.println("            y: { stacked: true }");
			writer.println("        }");
			writer.println("    }");
			writer.println("});");

			writer.println("</script>");
			writer.println("</body></html>");
		}
	}

	private Map<String, TestMetrics> testMetricsMap = new HashMap<>();

	/**
	 * Method to load the total execution history from the execution_history.csv for
	 * Automation Execution Time Trends Report
	 * 
	 * @author sanoj.swaminathan
	 * @since 05-11-2024
	 */
	private void loadTotalExecutionHistory() {
		try {
			List<String> lines = Files.readAllLines(Paths.get("Reports/Execution_Time_Report/execution_history.csv"));
			for (String line : lines) {
				String[] parts = line.split(",");
				String dateTimeData = parts[0];
				String suiteName = parts[1];
				double totalExecutionTime = Double.parseDouble(parts[2]);
				int testCaseCount = Integer.parseInt(parts[3]);
				int testCasePassCount = Integer.parseInt(parts[4]);
				int testCaseFailCount = Integer.parseInt(parts[5]);
				int testCaseSkipCount = Integer.parseInt(parts[6]);

				totalExecutionHistoryDataset.addValue(totalExecutionTime, "Total Execution Time (s)", dateTimeData);
				testMetricsMap.put(dateTimeData, new TestMetrics(testCaseCount, testCasePassCount, testCaseFailCount,
						testCaseSkipCount, suiteName));
			}
		} catch (IOException | NumberFormatException e) {
			e.printStackTrace();
		}
	}

	private Map<String, String> testStatusMap = new HashMap<>();

	/**
	 * Method to add execution time for Automation Execution Time Trends Report
	 * 
	 * @author sanoj.swaminathan
	 * @since 05-11-2024
	 * @param result
	 */
	private void addExecutionTime(ITestResult result) {
		long endTime = System.currentTimeMillis();
		double executionTimeInSeconds = (endTime - startTime) / 1000.0;
		String testName = result.getMethod().getMethodName();
		individualTestDataset.addValue(executionTimeInSeconds, "Execution Time (s)", testName);

		// Store the test status
		String status;
		switch (result.getStatus()) {
		case ITestResult.SUCCESS:
			status = "PASSED";
			break;
		case ITestResult.FAILURE:
			status = "FAILED";
			break;
		case ITestResult.SKIP:
			status = "SKIPPED";
			break;
		default:
			status = "UNKNOWN";
			break;
		}
		testStatusMap.put(testName, status);
	}

	/**
	 * Class to store the test metrics for the Automation Execution Time Trends
	 * Report
	 * 
	 * @author sanoj.swaminathan
	 * @since 05-11-2024
	 */
	private static class TestMetrics {
		private final int totalTests;
		private final int passed;
		private final int failed;
		private final int skipped;
		private final String suiteName;

		public TestMetrics(int totalTests, int passed, int failed, int skipped, String suiteName) {
			this.totalTests = totalTests;
			this.passed = passed;
			this.failed = failed;
			this.skipped = skipped;
			this.suiteName = suiteName;
		}

		/**
		 * To get total test case count
		 * 
		 * @author sanoj.swaminathan
		 * @since 05-11-2024
		 * @return
		 */
		public int getTotalTests() {
			return totalTests;
		}

		/**
		 * Method to get passed test case count
		 * 
		 * @author sanoj.swaminathan
		 * @since 05-11-2024
		 * @return
		 */
		public int getPassed() {
			return passed;
		}

		/**
		 * Method to get failed test case count
		 * 
		 * @author sanoj.swaminathan
		 * @since 05-11-2024
		 * @return
		 */
		public int getFailed() {
			return failed;
		}

		/**
		 * Method to get skipped test case count
		 * 
		 * @author sanoj.swaminathan
		 * @since 05-11-2024
		 * @return
		 */
		public int getSkipped() {
			return skipped;
		}

		/**
		 * Method to get suite name
		 * 
		 * @author sanoj.swaminathan
		 * @since 06-11-2024
		 * @return
		 */
		public String getSuiteName() {
			return suiteName;
		}
	}
}
