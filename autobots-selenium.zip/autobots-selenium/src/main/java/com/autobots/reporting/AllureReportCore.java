package com.autobots.reporting;

import java.io.File;

import com.autobots.exception.AutomationException;
import com.autobots.utils.Log;

public class AllureReportCore {
	/**
	 * Method to generate allure report
	 * 
	 * @author tom.saju
	 * @throws AutomationException 
	 * @since 22-08-2024
	 * 
	 */
	public void generateAllureReport() throws AutomationException {
		try {
			String command;
			String os = System.getProperty("os.name").toLowerCase();

			if (os.contains("win")) {
				command = "cmd.exe /c allure serve target/allure-results";
			} else {
				command = "/bin/bash -c allure serve target/allure-results";
			}
			ProcessBuilder processBuilder = new ProcessBuilder(command.split(" "));
			processBuilder.redirectErrorStream(true);
			Process process = processBuilder.start();
			int exitCode = process.waitFor();
			Log.info("Exited with code: " + exitCode);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * method use to clean the allure report
	 * 
	 * @author tom.saju
	 * @since 23-08-2024
	 */
	public void clearAllureResults() {
		File allureResultsDir = new File(System.getProperty("user.dir") + "/target/allure-results");
		if (allureResultsDir.exists()) {
			for (File file : allureResultsDir.listFiles()) {
				if (!file.isDirectory()) {
					file.delete();
				}
			}
		}
	}
}
