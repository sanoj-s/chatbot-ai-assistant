package com.autobots.reporting;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.jetbrains.annotations.NotNull;
import org.testng.ITestResult;

import com.epam.reportportal.listeners.ItemStatus;
import com.epam.reportportal.service.ReportPortal;
import com.epam.reportportal.testng.BaseTestNGListener;
import com.epam.reportportal.testng.TestMethodType;
import com.epam.reportportal.testng.TestNGService;
import com.epam.ta.reportportal.ws.model.FinishTestItemRQ;
import com.epam.ta.reportportal.ws.model.StartTestItemRQ;
import com.epam.ta.reportportal.ws.model.attribute.ItemAttributesRQ;

/**
 * Class to track the execution results to the Report Portal
 * 
 * @author sanoj.swaminathan
 * @since 16-01-2024
 *
 */
public class AutomationReportPortal extends BaseTestNGListener {

	public AutomationReportPortal() {
		super(new ParamTaggingTestNgService(ReportPortal.builder().build()));
	}

	@Override
	public void onTestStart(ITestResult result) {
		super.onTestStart(result);
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		super.onTestSuccess(result);
	}

	@Override
	public void onTestFailure(ITestResult result) {
		super.onTestFailure(result);
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		super.onTestSkipped(result);
	}

	public static class ParamTaggingTestNgService extends TestNGService {

		public ParamTaggingTestNgService(@NotNull ReportPortal reportPortal) {
			super(reportPortal);
		}

		@Override
		@Nonnull
		protected StartTestItemRQ buildStartStepRq(final @Nonnull ITestResult testResult,
				final @Nonnull TestMethodType type) {
			final StartTestItemRQ rq = super.buildStartStepRq(testResult, type);
			if (testResult.getParameters() != null && testResult.getParameters().length != 0) {
				Set<ItemAttributesRQ> attributes = Optional.ofNullable(rq.getAttributes()).orElse(new HashSet<>());
				for (Object param : testResult.getParameters()) {
					attributes.add(new ItemAttributesRQ(null, param.toString()));
				}
				rq.setAttributes(attributes);

			}
			return rq;
		}

		@Override
		@Nonnull
		protected FinishTestItemRQ buildFinishTestMethodRq(@Nonnull ItemStatus status,
				@Nonnull ITestResult testResult) {
			FinishTestItemRQ finishTestItemRQ = super.buildFinishTestMethodRq(status, testResult);
			if (testResult.getThrowable() != null) {
				String description = "```error\n" + ExceptionUtils.getStackTrace(testResult.getThrowable()) + "\n```";
				description = description + ExceptionUtils.getStackTrace(testResult.getThrowable());
				finishTestItemRQ.setDescription(description);
			}
			return finishTestItemRQ;
		}
	}
}