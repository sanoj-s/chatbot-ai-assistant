package com.autobots.pageobjectscanner;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.reflections.Reflections;
import org.reflections.scanners.SubTypesScanner;
import org.reflections.scanners.TypeAnnotationsScanner;

public class PageObjectScannerUI implements ActionListener {
	static WebDriver driver;
	private static JTextField textFieldURL;
	private static JComboBox<String> pageObjectClassComboBox;
	private static JLabel labelURL;
	private static JLabel labelPageObjectClass;
	private static String editFieldLabelURL = "Enter application URL  ";
	private static String selectPageClassLabel = "Select page class";
	static String panelBackgroundColor = "#A173C0";
	static String labelBackgroundColor = "#FFFFFF";

	/**
	 * Method to start the scanning the object locators
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-10-2024
	 */
	public static void findMissingObjectsUI() {

		// Create a button
		JButton buttonStart = new JButton("Start");
		buttonStart.setBackground(Color.decode("#08B6A2"));
		buttonStart.setForeground(Color.decode("#FFFFFF"));
		textFieldURL = new JTextField("https://");
		textFieldURL.setCaretPosition(textFieldURL.getText().length());

		JButton buttonFindMissingObjects = new JButton("Find Missing Objects");
		buttonFindMissingObjects.setBackground(Color.decode("#08B6A2"));
		buttonFindMissingObjects.setForeground(Color.decode("#FFFFFF"));
		pageObjectClassComboBox = new JComboBox<>();

		// Create a JFrame and set its layout manager
		JFrame frame = new JFrame("Page Object Scanner");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);

		// Layout components
		Container contentPane = frame.getContentPane();
		contentPane.setLayout(new BorderLayout());

		// Create a panel for the new fields
		JPanel fieldsPanel = new JPanel();
		Border create_border = BorderFactory.createTitledBorder("Select Details");
		((TitledBorder) create_border).setTitleColor(Color.decode(labelBackgroundColor));
		fieldsPanel.setBorder(create_border);
		fieldsPanel.setLayout(new GridBagLayout());

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(5, 5, 5, 5);
		gbc.weightx = 0.1;
		gbc.weighty = 0;

		// Row 1: Enter URL
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.anchor = GridBagConstraints.WEST;
		JLabel platformLabel = new JLabel(editFieldLabelURL);
		platformLabel.setForeground(Color.decode(labelBackgroundColor));
		fieldsPanel.add(platformLabel, gbc);

		gbc.gridx = 1;
		gbc.weightx = 1.0;
		textFieldURL.setPreferredSize(new Dimension(300, 25));
		fieldsPanel.add(textFieldURL, gbc);

		gbc.gridx = 2;
		buttonStart.setPreferredSize(new Dimension(150, 25));
		fieldsPanel.add(buttonStart, gbc);

		// Row 2: Select Page Class
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.weightx = 0.1;
		gbc.anchor = GridBagConstraints.WEST;
		JLabel browserLabel = new JLabel(selectPageClassLabel);
		browserLabel.setForeground(Color.decode(labelBackgroundColor));
		fieldsPanel.add(browserLabel, gbc);

		gbc.gridx = 1;
		gbc.weightx = 1.0;
		pageObjectClassComboBox.setPreferredSize(new Dimension(300, 25));
		fieldsPanel.add(pageObjectClassComboBox, gbc);

		gbc.gridx = 2;
		fieldsPanel.add(buttonFindMissingObjects, gbc);

		fieldsPanel.setBackground(Color.decode(panelBackgroundColor));

		// Add top panel Run Configurations to content pane
		contentPane.add(fieldsPanel, BorderLayout.NORTH);

		frame.setSize(690, 132);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);

		// Add action listener to the Start button
		buttonStart.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String appURL = textFieldURL.getText();
				if (appURL.isEmpty() || appURL.equals("https://")) {
					JOptionPane.showMessageDialog(textFieldURL, "Please enter a valid URL");
				} else {
					driver = new ChromeDriver();
					driver.get(appURL);
					driver.manage().window().maximize();
				}

				if (driver != null) {
					JOptionPane.showMessageDialog(textFieldURL,
							"Application loaded successfully. Find missing objects");
				}
			}
		});

		// Add action listener to the Find Missing Objects button
		buttonFindMissingObjects.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				if (driver == null) {
					JOptionPane.showMessageDialog(textFieldURL, "Please load the application by clicking Start button");
				} else {
					try {
						String selectedClassName = pageObjectClassComboBox.getSelectedItem().toString();
						Class<?> selectedClass = Class.forName(selectedClassName);

						// Now you can use the selected Class in the findMissingObjects method
						PageObjectScannerCore pagaClass = new PageObjectScannerCore();
						try {
							boolean isPresent = pagaClass.findMissingObjects(driver, selectedClass);
							if (!isPresent) {
								JOptionPane.showMessageDialog(textFieldURL,
										"Missing objects stored into MissingObjects.xlsx");
							} else {
								JOptionPane.showMessageDialog(textFieldURL, "All the objects are present");
							}
						} catch (NumberFormatException ex) {
							ex.printStackTrace();
						} catch (Exception exx) {
							exx.printStackTrace();
						}
					} catch (ClassNotFoundException ex) {
						JOptionPane.showMessageDialog(textFieldURL, "Error loading selected class");
					}
				}
			}
		});

		List<String> classNames = getPageClassNames();
		pageObjectClassComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(classNames.toArray(new String[0])));
	}

	/**
	 * Method to get all classes in the classpath
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-10-2024
	 * @return
	 */
	private static List<String> getPageClassNames() {
		List<String> classNames = new ArrayList<>();

		// Initialize Reflections with the class loader
		Reflections reflections = new Reflections(new org.reflections.util.ConfigurationBuilder()
				.setScanners(new SubTypesScanner(false), new TypeAnnotationsScanner()).forPackages("")
				.addClassLoaders(ClassLoader.getSystemClassLoader()));

		// Get all classes in the classpath
		Set<Class<?>> allClasses = reflections.getSubTypesOf(Object.class);
		for (Class<?> clazz : allClasses) {
			// Check if the class has any fields annotated with @FindBy
			boolean hasFindByAnnotation = false;
			Field[] fields = clazz.getDeclaredFields();
			for (Field field : fields) {
				if (field.isAnnotationPresent(FindBy.class)) {
					if (!hasFindByAnnotation) {
						classNames.add(clazz.getCanonicalName());
						hasFindByAnnotation = true;
					}
				}
			}
		}
		return classNames;
	}

	// Entry point
	public static void main(String[] args) {
		findMissingObjectsUI();
	}

	@Override
	public void actionPerformed(ActionEvent e) {

	}
}
