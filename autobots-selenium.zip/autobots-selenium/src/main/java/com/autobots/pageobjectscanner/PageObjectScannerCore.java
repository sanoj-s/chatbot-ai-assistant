package com.autobots.pageobjectscanner;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PageObjectScannerCore {

	/**
	 * Method to find the missing objects
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-10-2024
	 * @param driver
	 * @param pageClass
	 * @throws NumberFormatException
	 * @throws Exception
	 */
	public boolean findMissingObjects(WebDriver driver, Class<?> pageClass) throws NumberFormatException, Exception {
		Workbook workbook = null;
		Sheet sheet = null;
		String fileName = "MissingObjects.xlsx";
		File file = new File(fileName);

		// Check if the file already exists
		if (file.exists()) {
			try (FileInputStream fis = new FileInputStream(file)) {
				workbook = new XSSFWorkbook(fis);
			}
		} else {
			workbook = new XSSFWorkbook();
		}

		// Check if a sheet with the pageClass name already exists, or create a new one
		String sheetName = pageClass.getSimpleName() + "Objects";
		sheet = workbook.getSheet(sheetName);
		if (sheet == null) {
			sheet = workbook.createSheet(sheetName);
		}

		// Ensure header row creation for each sheet if it's missing
		Row headerRow = sheet.getRow(0);
		if (headerRow == null || sheet.getPhysicalNumberOfRows() == 0) {
			headerRow = sheet.createRow(0);
			headerRow.createCell(0).setCellValue("Object Name");
			headerRow.createCell(1).setCellValue("Object Value");
			headerRow.createCell(2).setCellValue("Object Type");
		}

		// Clear all rows except the header
		for (int i = sheet.getLastRowNum(); i > 0; i--) {
			sheet.removeRow(sheet.getRow(i));
		}

		// Proceed with adding new data
		Map<String, String[]> xpathCSSMap = new HashMap<>();
		Field[] fields = pageClass.getDeclaredFields();
		for (Field field : fields) {
			if (field.isAnnotationPresent(FindBy.class)) {
				FindBy findBy = field.getAnnotation(FindBy.class);
				String css = findBy.css();
				String xpath = findBy.xpath();

				if (!css.isEmpty()) {
					xpathCSSMap.put(field.getName(), new String[] { css, "CSS" });
				}
				if (!xpath.isEmpty()) {
					xpathCSSMap.put(field.getName(), new String[] { xpath, "XPath" });
				}
			}
		}

		int rowNum = 1; // Start from the first row after the header

		boolean isPresent = true; // assuming all elements are present

		// Validating the value present in the DOM
		for (Map.Entry<String, String[]> entry : xpathCSSMap.entrySet()) {
			String[] valueAndType = entry.getValue();
			WebElement element = null;
			try {
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
				wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.cssSelector("*")));
				waitForPageLoadComplete(driver);

				if (valueAndType[1].equalsIgnoreCase("xpath")) {
					element = driver.findElement(By.xpath(valueAndType[0]));
				} else {
					element = driver.findElement(By.cssSelector(valueAndType[0]));
				}

				if (!element.isDisplayed() || !element.isEnabled()) {
					Row row = sheet.createRow(rowNum++);
					row.createCell(0).setCellValue(entry.getKey());
					row.createCell(1).setCellValue(valueAndType[0]);
					row.createCell(2).setCellValue(valueAndType[1]);
					isPresent = false;
				}
			} catch (NoSuchElementException e) {
				Row row = sheet.createRow(rowNum++);
				row.createCell(0).setCellValue(entry.getKey());
				row.createCell(1).setCellValue(valueAndType[0]);
				row.createCell(2).setCellValue(valueAndType[1]);
				isPresent = false;
			}
		}

		// Feeding data to the Excel file
		try (FileOutputStream fileOut = new FileOutputStream(fileName)) {
			workbook.write(fileOut);
		} catch (IOException e) {
			e.printStackTrace();
		}

		try {
			workbook.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return isPresent;
	}

	/**
	 * Method to wait for the page to load completely
	 * 
	 * @author sanoj.swaminathan
	 * @since 15-10-2024
	 * @param driver
	 * @throws NumberFormatException
	 * @throws Exception
	 */
	private void waitForPageLoadComplete(WebDriver driver) throws NumberFormatException, Exception {
		try {
			new WebDriverWait(driver, Duration.ofSeconds(30)).until(webDriver -> ((JavascriptExecutor) driver)
					.executeScript("return document.readyState").equals("complete"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
