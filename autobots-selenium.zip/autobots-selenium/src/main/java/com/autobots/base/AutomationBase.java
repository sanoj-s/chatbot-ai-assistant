package com.autobots.base;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.AbstractDriverOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;

import com.autobots.exception.AutomationException;
import com.autobots.keywords.DataHandler;
import com.autobots.utils.AutomationConstants;
import com.autobots.utils.Log;

public class AutomationBase {

	protected static ThreadLocal<WebDriver> threadDriver = new ThreadLocal<>();
	public String executionEnvironment;

	/**
	 * Method to start the WebDriver session based on the given browser details.
	 * Supports the local and LambdaTest executions.
	 * 
	 * @author sanoj.swaminathan
	 * @since 22-04-2020
	 * @modified 04-08-2023
	 * @param browserName
	 * @param browserVersion
	 * @throws AutomationException
	 * @throws IOException
	 */
	public WebDriver startSession(String platformName, String browserName, String browserVersion, String gridIP,
			String gridPort) throws AutomationException, InterruptedException, IOException {
		executionEnvironment = new DataHandler().getPropertyFromFilePath(
				AutomationConstants.AUTOMATION_TEST_CONFIG_FILE_PATH, AutomationConstants.EXECUTION_ENVIRONMENT);
		if (executionEnvironment.equals("")) {
			executionEnvironment = "local";
		}
		if (executionEnvironment.equalsIgnoreCase("local")) {
			switch (browserName.toLowerCase()) {
			case "chrome":
			case "headless-chrome":
				if (!gridIP.equalsIgnoreCase("")) {
					startExecutionInGrid(gridIP, gridPort, browserName);
				} else {
					startChrome(browserName, browserVersion);
				}
				break;

			case "firefox":
			case "headless-firefox":
				if (!gridIP.equalsIgnoreCase("")) {
					startExecutionInGrid(gridIP, gridPort, browserName);
				} else {
					startFirefox(browserName);
				}
				break;

			case "ie":
			case "internetexplorer":
				if (!gridIP.equalsIgnoreCase("")) {
					startExecutionInGrid(gridIP, gridPort, browserName);
				} else {
					startInternetExplorer();
				}
				break;

			case "edge":
				if (!gridIP.equalsIgnoreCase("")) {
					startExecutionInGrid(gridIP, gridPort, browserName);
				} else {
					startEdge();
				}
				break;

			case "safari":
				if (!gridIP.equalsIgnoreCase("")) {
					startExecutionInGrid(gridIP, gridPort, browserName);
				} else {
					startSafari();
				}
				break;

			default:
				Log.info(AutomationConstants.CHECKBROWSER_MESSAGE);
				break;
			}
		}
		if (executionEnvironment.equalsIgnoreCase("lambdatest")) {
			startExecutionInLambdaTest(platformName, browserName, browserVersion);
		}
		getDriver().manage().window().maximize();
		return getDriver();
	}

	/**
	 * Retrieve the current thread's WebDriver instance
	 * 
	 * @author sanoj.swaminathan
	 * @since 22-04-2020
	 * @return
	 */
	public WebDriver getDriver() {
		return threadDriver.get();
	}

	/**
	 * Remove the WebDriver instance from ThreadLocal to clean up after test
	 * execution
	 * 
	 * @author sanoj.swaminathan
	 * @since 22-04-2024
	 */
	public void removeDriver() {
		if (getDriver() != null) {
			threadDriver.remove();
		}
	}

	/**
	 * Method to create the connection and session on LambdaTest cloud
	 * 
	 * @author sanojs
	 * @since 25-09-2023
	 * @param platformName
	 * @param browserName
	 * @param browserVersion
	 * @return
	 * @throws AutomationException
	 */
	private WebDriver startExecutionInLambdaTest(String platformName, String browserName, String browserVersion)
			throws AutomationException {
		WebDriver driver = null;
		String lambdaTestUserName, lambdaTestAuthkey, tunnelIdentifier, needLambdaConnect;
		try {
			String hub = "@hub.lambdatest.com/wd/hub";
			lambdaTestUserName = new DataHandler().getProperty(AutomationConstants.LAMBDATEST_CONFIG,
					AutomationConstants.LAMBDATEST_USERNAME);
			lambdaTestAuthkey = new DataHandler().getProperty(AutomationConstants.LAMBDATEST_CONFIG,
					AutomationConstants.LAMBDATEST_AUTHKEY);
			needLambdaConnect = new DataHandler().getProperty(AutomationConstants.LAMBDATEST_CONFIG,
					AutomationConstants.NEED_LAMBDATEST_TUNNEL_CONNECT);
			tunnelIdentifier = new DataHandler().getProperty(AutomationConstants.LAMBDATEST_CONFIG,
					AutomationConstants.LAMBDATEST_TUNNEL_IDENTIFIER);

			if (lambdaTestUserName == null || lambdaTestAuthkey.equals("")) {
				Log.info(AutomationConstants.LAMBDATEST_CREDENTIALS + "\n" + "Execution stopped...");
				System.exit(0);
			}

			String projectName = new DataHandler().getProperty(AutomationConstants.AUTOMATION_TEST_CONFIG,
					AutomationConstants.PROJECTNAME);
			if (projectName.equals("")) {
				projectName = "Default Project";
			}

			@SuppressWarnings("rawtypes")
			AbstractDriverOptions browserOptions = null;
			if (browserName.toLowerCase().contains("chrome")) {
				browserOptions = new ChromeOptions();
			} else if (browserName.toLowerCase().contains("firefox")) {
				browserOptions = new FirefoxOptions();
			} else if (browserName.toLowerCase().contains("edge")) {
				browserOptions = new EdgeOptions();
			} else if (browserName.toLowerCase().contains("safari")) {
				browserOptions = new SafariOptions();
			} else {
				Log.info("No browser selected");
				System.exit(0);
			}

			browserOptions.setPlatformName(platformName);
			browserOptions.setBrowserVersion(browserVersion);
			if (needLambdaConnect.equalsIgnoreCase("yes")) {
				browserOptions.setCapability("tunnel", true);
				browserOptions.setCapability("tunnelIdentifier", tunnelIdentifier);
			}
			HashMap<String, Object> ltOptions = new HashMap<String, Object>();
			ltOptions.put("project", projectName);
			ltOptions.put("w3c", true);
			ltOptions.put("build", projectName);
			browserOptions.setCapability("LT:Options", ltOptions);

			driver = new RemoteWebDriver(new URL("https://" + lambdaTestUserName + ":" + lambdaTestAuthkey + hub),
					browserOptions);
			threadDriver.set(driver);
			Log.info(AutomationConstants.LAMBDATEST_START_MSG);
		} catch (Exception e) {
			Log.exception(e);
		}
		return driver;

	}

	/**
	 * Method to launch Chrome browser with headless and without headless mode
	 * 
	 * @author sanoj.swaminathan
	 * @throws AutomationException
	 * @since 13-04-2020
	 * @modified 16-03-2021
	 * @param browserName
	 * @param browserVersion
	 */
	private WebDriver startChrome(String browserName, String browserVersion) throws AutomationException {
		WebDriver driver = null;
		try {
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--test-type");
			Map<String, Object> prefs = new HashMap<String, Object>();
			prefs.put("credentials_enable_service", false);
			prefs.put("profile.password_manager_enabled", false);
			options.setExperimentalOption("prefs", prefs);
			options.addArguments("--remote-allow-origins=*");
			if (!browserVersion.equals("")) {
				options.setBrowserVersion(browserVersion);
			}
			if (browserName.equalsIgnoreCase("headless-chrome")) {
				options.addArguments("--no-sandbox");
				options.addArguments("--disable-dev-shm-usage");
				options.addArguments("--headless=new");
			}
			driver = new ChromeDriver(options);
			threadDriver.set(driver);
		} catch (Exception e) {
			Log.exception(e);
		}
		return driver;
	}

	/**
	 * Method to launch FireFox browser with headless and without headless mode
	 * 
	 * @author sanoj.swaminathan
	 * @throws AutomationException
	 * @since 13-04-2020
	 * @modified 16-03-2021
	 * @param browserName
	 */
	private void startFirefox(String browserName) throws AutomationException {
		try {
			DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
			FirefoxOptions firefoxOptions = new FirefoxOptions(capabilities);
			if (browserName.equalsIgnoreCase("headless-firefox")) {
				firefoxOptions.addArguments("--no-sandbox");
				firefoxOptions.addArguments("--disable-dev-shm-usage");
				firefoxOptions.addArguments("--headless");
			}
			WebDriver driver = new FirefoxDriver(firefoxOptions);
			threadDriver.set(driver);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Launch Safari browser
	 * 
	 * @author sanoj.swaminathan
	 * @throws InterruptedException
	 * @throws AutomationException
	 * @since 19-05-2021
	 */
	private void startSafari() throws InterruptedException, AutomationException {
		Process process;
		try {
			process = Runtime.getRuntime().exec("killall safaridriver");
			process.waitFor();
			process.destroy();
		} catch (IOException e) {
			Log.exception(e);
		}
		SafariOptions options = new SafariOptions();
		// options.useCleanSession(true);
		options.setAutomaticInspection(true);
		options.setUseTechnologyPreview(true);
		WebDriver driver = new SafariDriver(options);
		threadDriver.set(driver);
	}

	/**
	 * Launch Edge browser
	 * 
	 * @author sanoj.swaminathan
	 * @since 19-05-2021
	 */
	private void startEdge() throws AutomationException {
		try {
			WebDriver driver = new EdgeDriver();
			threadDriver.set(driver);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * Launch Internet Explorer browser
	 * 
	 * @author sanoj.swaminathan
	 * @since 19-05-2021
	 * @throws AutomationException
	 */
	private void startInternetExplorer() throws AutomationException {
		try {
			WebDriver driver = new InternetExplorerDriver();
			threadDriver.set(driver);
		} catch (Exception e) {
			Log.exception(e);
		}
	}

	/**
	 * To start the selenium grid execution in the distributed environment
	 * 
	 * @author sanoj.swaminathan
	 * @since 19-01-2022
	 * @param gridIP
	 * @param gridPort
	 * @param browserName
	 * @return
	 * @throws AutomationException
	 */
	private RemoteWebDriver startExecutionInGrid(String gridIP, String gridPort, String browserName)
			throws AutomationException {
		WebDriver driver = null;
		DesiredCapabilities gridCap = new DesiredCapabilities();
		String nodeURL = "", platformName = "";
		try {
			if (gridIP != "" && gridPort != null && gridIP != null && gridPort != "") {
				nodeURL = ("http://" + gridIP + ":" + gridPort).toString().toLowerCase().trim();
			} else {
				Exception ex = new AutomationException(AutomationConstants.GRIDNODEIP_PORTMISSING);
				throw new AutomationException(ex);
			}

			try {
				if (browserName != "" && browserName != null) {
					if ("firefox".equalsIgnoreCase(browserName))
						gridCap.setBrowserName("firefox");
					if (("internetExplorer".equalsIgnoreCase(browserName)) | ("IE".equalsIgnoreCase(browserName)))
						gridCap.setBrowserName("internet explorer");
					if ("chrome".equalsIgnoreCase(browserName))
						gridCap.setBrowserName("chrome");
					if ("safari".equalsIgnoreCase(browserName))
						gridCap.setBrowserName("safari");
					if ("edge".equalsIgnoreCase(browserName))
						gridCap.setBrowserName("MicrosoftEdge");
				} else {
					throw new AutomationException(AutomationConstants.GRID_BROWSER_MISSING);
				}

				platformName = System.getProperty("os.name");
				if (platformName != "" && platformName != null) {
					if (platformName.equalsIgnoreCase("WINDOWS"))
						gridCap.setPlatform(Platform.WINDOWS);
					if (platformName.equalsIgnoreCase("LINUX"))
						gridCap.setPlatform(Platform.LINUX);
					if (platformName.equalsIgnoreCase("MAC"))
						gridCap.setPlatform(Platform.MAC);
					if (platformName.equalsIgnoreCase("ANY"))
						gridCap.setPlatform(Platform.ANY);
				}
				driver = new RemoteWebDriver(new URL(nodeURL), gridCap);
				threadDriver.set(driver);
			} catch (Exception e) {
				Log.exception(e);
			}
		} catch (Exception e) {
			Log.exception(e);
		}
		return (RemoteWebDriver) driver;
	}

	/**
	 * Method to get the Exception message, to pass the message whenever an
	 * exception is encountered
	 * 
	 * @author sanoj.swaminathan
	 * @throws AutomationException
	 * @since 13-04-2020
	 */
	public String getExceptionMessage() throws AutomationException {
		StringBuffer message = new StringBuffer();
		try {
			message.append("Exception in ");
			message.append(Thread.currentThread().getStackTrace()[2].getClassName());
			message.append(".");
			message.append(Thread.currentThread().getStackTrace()[2].getMethodName());
			message.append("()");
		} catch (Exception e) {
			Log.exception(e);
		}
		return message.toString();
	}
}
