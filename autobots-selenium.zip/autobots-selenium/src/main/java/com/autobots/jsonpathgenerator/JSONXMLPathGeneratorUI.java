package com.autobots.jsonpathgenerator;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class JSONXMLPathGeneratorUI implements ActionListener {

	private static JLabel labelRepository;
	private static String fileTypeLabel = "Select File Type              ";
	private static JLabel labelFileType;
	private static String selectFileLabel = "Select File Name            ";
	private static JLabel labelSelectFile;
	private static String editFieldLabelRepository = "Enter Repository Name";
	private static JTextField textFieldRepository;

	/**
	 * Method to start the scanning the JSON or XML objects
	 * 
	 * @author sanoj.swaminathan
	 * @since 31-07-2023
	 */
	public static void generateJSONXMLPathObjects() {

		labelFileType = new JLabel(fileTypeLabel);
		JRadioButton optionXML = new JRadioButton("XML");
		JRadioButton optionJSON = new JRadioButton("JSON");

		labelSelectFile = new JLabel(selectFileLabel);
		JComboBox<String> fileDropdown = new JComboBox<>();
		fileDropdown.setPreferredSize(new Dimension(170, fileDropdown.getPreferredSize().height));

		labelRepository = new JLabel(editFieldLabelRepository);
		textFieldRepository = new JTextField();
		textFieldRepository.setColumns(15);

		// Create button
		JButton buttonGenerate = new JButton("Generate");

		// To control the selection of one item at a time
		ButtonGroup optionButtonGroup = new ButtonGroup();
		optionButtonGroup.add(optionXML);
		optionButtonGroup.add(optionJSON);

		// Create a JFrame and set its layout manager
		JFrame frame = new JFrame("JSON-XML Path Generator");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);

		// Create three panels for each line
		JPanel panelFileType = new JPanel();
		JPanel panelSelectFile = new JPanel();
		JPanel panelRepositoryFile = new JPanel();

		// Configure layout managers for each panel
		panelFileType.setLayout(new FlowLayout(FlowLayout.LEFT));
		panelSelectFile.setLayout(new FlowLayout(FlowLayout.LEFT));
		panelRepositoryFile.setLayout(new FlowLayout(FlowLayout.LEFT));

		// Add the components to the panel
		panelFileType.add(labelFileType);
		panelFileType.add(optionJSON);
		panelFileType.add(optionXML);

		panelSelectFile.add(labelSelectFile);
		panelSelectFile.add(fileDropdown);

		panelRepositoryFile.add(labelRepository);
		panelRepositoryFile.add(textFieldRepository);
		panelRepositoryFile.add(buttonGenerate);

		frame.add(panelFileType);
		frame.add(panelSelectFile);
		frame.add(panelRepositoryFile);
		frame.pack();
		frame.setVisible(true);

		// Get all JSON and XML files
		String directoryReqPath = JSONXMLPathGeneratorConstants.REQUEST_PAYLOAD_PATH;
		List<String> fileNamesReq = getFileNames(directoryReqPath);
		String directoryRespPath = JSONXMLPathGeneratorConstants.RESPONSE_DATA_PATH;
		List<String> fileNamesResp = getFileNames(directoryRespPath);

		List<String> combinedList = Stream.concat(fileNamesReq.stream(), fileNamesResp.stream())
				.collect(Collectors.toList());

		// File listing all the JSON file in the dropdown based on the JSON radio button
		// selection
		optionJSON.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (optionJSON.isSelected()) {
					fileDropdown.removeAllItems();
					for (String fileName : combinedList) {
						if (fileName.endsWith(".json")) {
							fileDropdown.addItem(fileName);
						}
					}
				}
			}
		});

		// File listing all the XML file in the dropdown based on the XML radio button
		// selection
		optionXML.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (optionXML.isSelected()) {
					fileDropdown.removeAllItems();
					for (String fileName : combinedList) {
						if (fileName.endsWith(".xml")) {
							fileDropdown.addItem(fileName);
						}
					}
				}
			}
		});

		// Generate the JSON and XML object path
		buttonGenerate.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				String repositoryName;
				String repositoryFieldValue = textFieldRepository.getText().replaceAll("\\s+", "");

				if (fileDropdown.getSelectedItem() == null) {
					JButton sourceButton = (JButton) e.getSource();
					JOptionPane.showMessageDialog(sourceButton, "Please select file type");
				} else {
					if (repositoryFieldValue.isEmpty()) {
						JButton sourceButton = (JButton) e.getSource();
						JOptionPane.showMessageDialog(sourceButton, "Please enter a valid repository name");
					} else {
						String fileName = fileDropdown.getSelectedItem().toString();

						String payloadPath = System.getProperty("user.dir") + directoryReqPath + fileName;
						File file = new File(payloadPath);
						String responseDataPath = System.getProperty("user.dir") + directoryRespPath + fileName;
						File responseFile = new File(responseDataPath);
						if (file.exists() || responseFile.exists()) {
							String filePath = null;
							if (file.exists()) {
								filePath = payloadPath;
							}
							if (responseFile.exists()) {
								filePath = responseDataPath;
							}

							// Convert to CamelCase
							String[] words = repositoryFieldValue.split(" ");
							StringBuilder result = new StringBuilder();
							for (String word : words) {
								result.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
							}
							repositoryName = result.toString().replaceAll("[^a-zA-Z0-9]", "");

							// Actual implementation to capture the JSON and XML path
							if (fileName.contains(".json")) {
								new JSONXMLPathGeneratorCore().generateJSONPathObjects(repositoryName, filePath);
								JOptionPane.showMessageDialog((JButton) e.getSource(),
										"JSON path captured and stored successfully");
							} else {
								new JSONXMLPathGeneratorCore().generateXMLPathObjects(repositoryName, filePath);
								JOptionPane.showMessageDialog((JButton) e.getSource(),
										"XML path captured and stored successfully");
							}
							textFieldRepository.setText("");
						}
					}
				}
			}
		});
	}

	/**
	 * Method to get the lists of files from the given directory
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-12-2023
	 * @param directoryPath
	 * @return
	 */
	private static List<String> getFileNames(String directoryPath) {
		List<String> fileNames = new ArrayList<>();
		File directory = new File(System.getProperty("user.dir") + directoryPath);
		if (directory.exists() && directory.isDirectory()) {
			File[] files = directory.listFiles();
			if (files != null) {
				for (File file : files) {
					if (file.isFile()) {
						fileNames.add(file.getName());
					}
				}
			}
		} else {
			System.err.println("Directory does not exist: " + directoryPath);
		}
		return fileNames;
	}

	// Entry point
	public static void main(String[] args) {
		generateJSONXMLPathObjects();
	}

	@Override
	public void actionPerformed(ActionEvent e) {

	}
}
