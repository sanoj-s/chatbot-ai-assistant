package com.autobots.jsonpathgenerator;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JSONXMLPathGeneratorCore {

	/**
	 * Method to generate JSON path objects
	 * 
	 * @author sanoj.swaminathan
	 * @since 09-08-2023
	 * @param repositoryName
	 * @param jsonFilePath
	 */
	public void generateJSONPathObjects(String repositoryName, String jsonFilePath) {
		try {
			File file = new File(jsonFilePath);
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode jsonNode = objectMapper.readTree(file);
			List<String> jsonPaths = createJSONValuePaths(jsonNode, "");
			for (String path : jsonPaths) {
				createJavaFile(repositoryName, convertToCamelCase(path).replaceAll("[^a-zA-Z0-9]", ""), path);
			}
			System.out.println("Object repository " + repositoryName + " updated");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to generate the XML path objects
	 * 
	 * @author sanoj.swaminathan
	 * @since 12-12-2023
	 * @param repositoryName
	 * @param xmlFilePath
	 */
	public void generateXMLPathObjects(String repositoryName, String xmlFilePath) {
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document document = builder.parse(xmlFilePath);

			XPath xPath = XPathFactory.newInstance().newXPath();
			NodeList nodeList = (NodeList) xPath.evaluate("//*", document, XPathConstants.NODESET);
			for (int i = 0; i < nodeList.getLength(); i++) {
				Node node = nodeList.item(i);
				String path = getPath(node).substring(".#document.".length());
				createJavaFile(repositoryName, convertToCamelCase(path).replaceAll("[^a-zA-Z0-9]", ""), path);
			}
			System.out.println("Object repository " + repositoryName + " updated");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to get the XPath of a node
	 * 
	 * @author sanoj.swaminathan
	 * @since 11-12-2023
	 * @param node
	 * @return
	 */
	private static String getPath(Node node) {
		Node parent = node.getParentNode();
		if (parent == null) {
			return "." + node.getNodeName();
		}
		return getPath(parent) + "." + node.getNodeName();
	}

	/**
	 * Method to create the JSON path value
	 * 
	 * @author sanoj.swaminathan
	 * @since 09-08-2023
	 * @param node
	 * @param path
	 * @return
	 */
	private static List<String> createJSONValuePaths(JsonNode node, String path) {
		List<String> jsonPaths = new ArrayList<>();
		try {
			if (node.isValueNode()) {
				jsonPaths.add(path);
			} else if (node.isObject()) {
				node.fields().forEachRemaining(entry -> {
					String key = entry.getKey();
					JsonNode value = entry.getValue();
					String newPath = path.isEmpty() ? key : path + "." + key;
					jsonPaths.addAll(createJSONValuePaths(value, newPath));
				});
			} else if (node.isArray()) {
				for (int i = 0; i < node.size(); i++) {
					jsonPaths.addAll(createJSONValuePaths(node.get(i), path + "[" + i + "]"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonPaths;
	}

	/**
	 * Method to convert path value to camel case
	 * 
	 * @author sanoj.swaminathan
	 * @since 09-08-2023
	 * @param pathValue
	 * @return
	 */
	private static String convertToCamelCase(String pathValue) {
		StringBuilder result = null;
		try {
			String[] parts = pathValue.split("\\.");
			result = new StringBuilder(parts[0]);

			for (int i = 1; i < parts.length; i++) {
				String part = parts[i];
				result.append(Character.toUpperCase(part.charAt(0)));
				result.append(part.substring(1));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result.toString();
	}

	/**
	 * Method to create the java class for object repository
	 * 
	 * @author Sanoj Swaminathan
	 * @since @since 09-08-2023
	 * @param repositoryName
	 * @param objectName
	 * @param jsonPathValue
	 */
	private static void createJavaFile(String repositoryName, String objectName, String jsonPathValue) {
		String packageName = JSONXMLPathGeneratorConstants.OBJECT_PACKAGE;
		String className = repositoryName;

		// Creating the package inside src/test/java
		String rootDirectory = System.getProperty("user.dir") + "/src/test/java";
		String packagePath = rootDirectory + JSONXMLPathGeneratorConstants.OBJECT_PACKAGE_DIRECTORY;
		File packageDirectory = new File(packagePath);
		if (!packageDirectory.exists()) {
			packageDirectory.mkdirs();
		}

		String directory = "src/test/java/" + packageName.replace(".", "/") + "/";
		String fileName = directory + className + ".java";

		// Accept user input for variables
		Map<String, String> variables = new HashMap<>();
		variables.put(objectName, jsonPathValue);

		// Check if the file already exists
		Path filePath = Path.of(fileName);
		StringBuilder code = new StringBuilder();
		if (Files.exists(filePath)) {

			// Read the existing code from the Java file
			try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
				String line;
				while ((line = reader.readLine()) != null) {
					code.append(line).append("\n");
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

			// Check if the last curly brace exists in the code
			int lastCurlyBraceIndex = code.lastIndexOf("}");

			// Update or append the variables in the code
			StringBuilder variablesCode = new StringBuilder();
			for (Map.Entry<String, String> entry : variables.entrySet()) {
				String variableName = entry.getKey();
				String variableValue = entry.getValue();

				// Check if the variable already exists in the code
				boolean variableExists = code.toString().contains("public static final String " + variableName);

				if (variableExists) {
					// Truncate the existing variable and update it with the new value
					code = new StringBuilder(
							code.toString().replaceAll("(public static final String " + variableName + " = \").*(\";)",
									"$1" + variableValue + "\";"));
				}

				if (!variableExists) {
					// Append the new variable to the variables code
					variablesCode.append("\n    public static final String ").append(variableName).append(" = \"")
							.append(variableValue).append("\";");

					// Newly Added here
					// Insert the variables code inside the last curly brace
					if (lastCurlyBraceIndex != -1) {
						code.insert(lastCurlyBraceIndex, variablesCode);
					}
				}
			}
		} else {
			// Generate code for the class and variables
			code.append("package ").append(packageName).append(";\n\n");
			code.append("public class ").append(className).append(" {\n");

			for (Map.Entry<String, String> entry : variables.entrySet()) {
				String variableName = entry.getKey();
				String variableValue = entry.getValue();
				code.append("    public static final String ").append(variableName).append(" = \"")
						.append(variableValue).append("\";\n");
			}
			code.append("}\n");
		}
		// Write the code to the Java file
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
			writer.write(code.toString());
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
