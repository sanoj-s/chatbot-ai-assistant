package com.autobots.jsonpathgenerator;

public class JSONXMLPathGeneratorConstants {
	public static final String REQUEST_PAYLOAD_PATH = "./src/test/resources/APITesting/RequestPayload/";
	public static final String RESPONSE_DATA_PATH = "./src/test/resources/APITesting/ResponseData/";
	public static final String OBJECT_PACKAGE = "com.autobots.testobjects";
	public static final String OBJECT_PACKAGE_DIRECTORY = "/com/autobots/testobjects";
}
