package com.autobots.stepdefgenerator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StepDefinitionGeneratorCore {
	/**
	 * Method to generate the step definition class based on the given feature file.
	 * The feature file should be available at
	 * ./src/test/resources/BDDTesting/Features in the project
	 * 
	 * @author sanoj.swaminathan
	 * @since 05-12-2023
	 * @param featureFileName
	 */
	public void generateStepDefinitions(String featureFileName) {
		try {
			String featureFilesPath = System.getProperty("user.dir")
					+ StepDefinitionGeneratorConstants.FEATURE_FILES_PATH;
			List<String> steps = readFeatureFile(featureFilesPath + "/" + featureFileName);
			String packageName = StepDefinitionGeneratorConstants.STEP_DEF_PACKAGE;

			// Creating the package inside src/test/java
			String rootDirectory = System.getProperty("user.dir") + "/src/test/java";
			String packagePath = rootDirectory + StepDefinitionGeneratorConstants.STEP_DEF_DIRECTORY;
			File packageDirectory = new File(packagePath);
			if (!packageDirectory.exists()) {
				packageDirectory.mkdirs();
			}

			String className = featureFileName + "Steps";
			String[] words = className.split(" ");
			StringBuilder resultValue = new StringBuilder();
			for (String word : words) {
				resultValue.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
			}
			String finalClassName = resultValue.toString().replaceAll("[^a-zA-Z0-9]", "");

			Path filePath = Path.of("src", "test", "java", packageName.replace(".", "/"), finalClassName + ".java");

			StringBuilder code = new StringBuilder();
			code.append("package ").append(packageName).append(";\n\n");
			code.append("import io.cucumber.java.en.Given;\n");
			code.append("import io.cucumber.java.en.When;\n");
			code.append("import io.cucumber.java.en.Then;\n\n");
			code.append("public class ").append(finalClassName).append(" {\n\n");

			for (String step : steps) {
				String action = extractAnnotation(step);
				String stepInAction = extractStep(step).replace(",", "");

				String methodName = null;
				if (stepInAction.contains("{string}")) {
					String result = stepInAction.replaceAll("\\{string\\}", "");
					methodName = result.replaceAll("\\s", "_");
				} else {
					methodName = stepInAction.replaceAll("\\s", "_");
				}

				code.append("    @").append(stepAnnotation(action)).append("(\"" + stepInAction + "\")").append("\n");

				int stringCount = countOccurrencesOfMethodParameters(stepInAction, "{string}");
				if (stringCount > 0) {
					code.append("    public void ").append(methodName).append("(");
					for (int i = 0; i < stringCount; i++) {
						code.append("String string").append(i + 1);
						if (i < stringCount - 1) {
							code.append(", ");
						}
					}
					code.append(") {\n");
				} else {
					code.append("    public void ").append(methodName).append("() {\n");
				}

				code.append("        // Implement your step here\n");
				code.append("    }\n\n");

				System.out.println("Action: " + action);
				System.out.println("Target: " + stepInAction);
			}
			code.append("}\n");
			Files.writeString(filePath, code);
		} catch (Exception e) {
		}
	}

	/**
	 * Method to count number of occurrences of method parameters
	 * 
	 * @author sanoj.swaminathan
	 * @since 06-12-2023
	 * @param input
	 * @param target
	 * @return
	 */
	public static int countOccurrencesOfMethodParameters(String input, String target) {
		int count = 0;
		int index = input.indexOf(target);
		while (index != -1) {
			count++;
			index = input.indexOf(target, index + 1);
		}
		return count;
	}

	/**
	 * Method to return the step annotations
	 * 
	 * @author sanoj.swaminathan
	 * @since 05-12-2023
	 * @param step
	 * @return
	 */
	private static String stepAnnotation(String step) {
		if (step.toLowerCase().startsWith("given")) {
			return "Given";
		} else if (step.toLowerCase().startsWith("when")) {
			return "When";
		} else if (step.toLowerCase().startsWith("then")) {
			return "Then";
		} else {
			return "Given";
		}
	}

	/**
	 * Method to read the feature file contents
	 * 
	 * @author sanoj.swaminathan
	 * @since 05-12-2023
	 * @param featureFilePath
	 * @return
	 * @throws IOException
	 */
	private static List<String> readFeatureFile(String featureFilePath) throws IOException {
		List<String> steps = new ArrayList<>();

		try (BufferedReader reader = new BufferedReader(new FileReader(featureFilePath))) {
			String line;
			while ((line = reader.readLine()) != null) {
				if (line.trim().startsWith("Given") || line.trim().startsWith("When")
						|| line.trim().startsWith("Then")) {
					steps.add(line.trim());
				}
			}
		}
		return steps;
	}

	/**
	 * Method to extract the annotation name from the steps of scenario
	 * 
	 * @author sanoj.swaminathan
	 * @since 05-12-2023
	 * @param step
	 * @return
	 */
	private static String extractAnnotation(String step) {
		Pattern pattern = Pattern.compile("(Given|When|Then) (.+)");
		Matcher matcher = pattern.matcher(step);
		if (matcher.matches()) {
			return matcher.group(1);
		}
		return null;
	}

	/**
	 * Method to extract the step details
	 * 
	 * @author sanoj.swaminathan
	 * @since 05-12-2023
	 * @param step
	 * @return
	 */
	private static String extractStep(String step) {
		Pattern pattern = Pattern.compile("(Given|When|Then) (.+)");
		Matcher matcher = pattern.matcher(step);
		if (matcher.matches()) {
			String target = matcher.group(2).replaceAll("\"([^\"]+)\"", "{string}");
			return target;
		}
		return null;
	}
}
