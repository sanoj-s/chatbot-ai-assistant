package com.autobots.stepdefgenerator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class FeatureFileGeneratorCore {
	/**
	 * Method to generate the feature files
	 * 
	 * @author sanoj.swaminathan
	 * @since 04-12-2023
	 * @param fileName
	 * @throws IOException
	 */
	public List<String> generateFeatureFiles(String fileName) throws IOException {
		List<String> featureFileList = null;
		try {
			FileInputStream excelFile = new FileInputStream(new File(fileName));
			Workbook workbook = new XSSFWorkbook(excelFile);
			featureFileList = new ArrayList<String>();

			for (int sheetIndex = 0; sheetIndex < workbook.getNumberOfSheets(); sheetIndex++) {
				Sheet sheet = workbook.getSheetAt(sheetIndex);
				String sheetName = sheet.getSheetName();

				if (sheet.getLastRowNum() <= 0) {
					continue;
				}

				String featureFilesPath = System.getProperty("user.dir")
						+ StepDefinitionGeneratorConstants.FEATURE_FILES_PATH;

				if (!Files.exists(Paths.get(featureFilesPath))) {
					try {
						Files.createDirectories(Paths.get(featureFilesPath));
					} catch (IOException exe) {
						exe.printStackTrace();
					}
				}

				FileWriter featureFileWriter = new FileWriter(featureFilesPath + "/" + sheetName + ".feature");
				for (int i = 0; i <= sheet.getLastRowNum(); i++) {
					Row row = sheet.getRow(i);

					String cellContent = row.getCell(0).getStringCellValue();

					String[] lines = cellContent.split("\n");

					for (String line : lines) {
						if (line.startsWith("Feature:")) {
							featureFileWriter.write(line + "\n\n");
						} else if (line.startsWith("Scenario:")) {
							featureFileWriter.write(line + "\n");
						} else if (line.trim().startsWith("Given") || line.trim().startsWith("When")
								|| line.trim().startsWith("Then")) {
							featureFileWriter.write("\t" + line.trim() + "\n");
						}
					}
					featureFileWriter.write("\n");
				}
				featureFileWriter.close();

				featureFileList.add(sheetName);
			}
			workbook.close();
			excelFile.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return featureFileList;
	}
}
