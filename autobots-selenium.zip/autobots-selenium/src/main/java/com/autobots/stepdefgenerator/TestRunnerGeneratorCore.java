package com.autobots.stepdefgenerator;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

public class TestRunnerGeneratorCore {

	/**
	 * Method to generate the BDD Test Runner class for the execution of the feature
	 * file
	 * 
	 * @author sanoj.swaminathan
	 * @throws IOException
	 * @throws ParserConfigurationException
	 * @since 08-12-2023
	 */
	public void generateBDDTestRunner() throws ParserConfigurationException, IOException {

		String className = StepDefinitionGeneratorConstants.RUNNER_CLASS_NAME;
		String packageName = StepDefinitionGeneratorConstants.RUNNER_PACKAGE;
		String[] features = { StepDefinitionGeneratorConstants.FEATURE_FILES_PATH };
		String glue = StepDefinitionGeneratorConstants.STEP_DEF_PACKAGE;
		String plugin = "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:";

		File bddTetRunnerFile = new File(System.getProperty("user.dir"),
				"src/test/java" + StepDefinitionGeneratorConstants.RUNNER_DIRECTORY + "/" + className + ".java");

		if (!bddTetRunnerFile.exists()) {
			// Creating the package inside src/test/java
			String rootDirectory = System.getProperty("user.dir") + "/src/test/java";
			String packagePath = rootDirectory + StepDefinitionGeneratorConstants.RUNNER_DIRECTORY;
			File packageDirectory = new File(packagePath);
			if (!packageDirectory.exists()) {
				packageDirectory.mkdirs();
			}

			StringBuilder classContent = new StringBuilder();
			classContent.append("package ").append(packageName).append(";\n\n");
			classContent.append("import io.cucumber.testng.AbstractTestNGCucumberTests;\n");
			classContent.append("import io.cucumber.testng.CucumberOptions;\n\n");
			classContent.append("@CucumberOptions(tags = \"\", features = {");
			for (String feature : features) {
				classContent.append(" \"").append(feature).append("\",");
			}
			classContent.deleteCharAt(classContent.length() - 1);
			classContent.append(" }, glue = {\"").append(glue).append("\"}, plugin = {\"").append(plugin)
					.append("\"})\n");
			classContent.append("public class ").append(className).append(" extends AbstractTestNGCucumberTests {\n}");

			// Writing the content to a Java file
			String filePath = "src/test/java" + StepDefinitionGeneratorConstants.RUNNER_DIRECTORY + "/" + className + ".java";
			try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
				writer.write(classContent.toString());
				System.out.println("Generated " + className + " class successfully at " + filePath);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		// Generate testng.xml file
		new TestNGXMLGeneratorCore().generateTestNGXml(className);
	}
}
