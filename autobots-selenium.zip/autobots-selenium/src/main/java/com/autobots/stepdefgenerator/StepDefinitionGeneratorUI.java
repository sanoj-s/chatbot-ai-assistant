package com.autobots.stepdefgenerator;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.xml.parsers.ParserConfigurationException;

public class StepDefinitionGeneratorUI implements ActionListener {
	private static JLabel labelFeatureInputTemplateFileName;
	private static String editFieldLabelFeatureInputTemplateFile = "Select File Name  ";
	private static JLabel labelSelectFileName;
	private static String fileTypeLabel = "Select File Type  ";

	/**
	 * Method to start the accept the feature file template and process it for
	 * generate the feature files.
	 * 
	 * @author sanoj.swaminathan
	 * @since 04-12-2023
	 */
	public static void generateFeatureFiles() {

		labelSelectFileName = new JLabel(fileTypeLabel);
		JRadioButton optionRequirementDoc = new JRadioButton("Requirement Document");
		JRadioButton optionFeature = new JRadioButton("Feature");
		labelFeatureInputTemplateFileName = new JLabel(editFieldLabelFeatureInputTemplateFile);

		// Create JComboBox
		JComboBox<String> fileDropdown = new JComboBox<>();
		fileDropdown.setPreferredSize(new Dimension(180, fileDropdown.getPreferredSize().height));

		// Create Generate button
		JButton buttonGenerate = new JButton("Generate");

		// To control the selection of one item at a time
		ButtonGroup optionButtonGroup = new ButtonGroup();
		optionButtonGroup.add(optionRequirementDoc);
		optionButtonGroup.add(optionFeature);

		// Create a JFrame and set its layout manager
		JFrame frame = new JFrame("Step Definition Generator");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);

		// Create two panels for each line
		JPanel panelFile = new JPanel();
		JPanel panelFileType = new JPanel();

		// Configure layout managers for each panel
		panelFile.setLayout(new FlowLayout(FlowLayout.LEFT));
		panelFileType.setLayout(new FlowLayout(FlowLayout.LEFT));

		// Add the dropdown, radio buttons and button to the panel
		panelFileType.add(labelSelectFileName);
		panelFileType.add(optionRequirementDoc);
		panelFileType.add(optionFeature);
		panelFile.add(labelFeatureInputTemplateFileName);
		panelFile.add(fileDropdown);
		panelFile.add(buttonGenerate);

		frame.add(panelFileType);
		frame.add(panelFile);
		frame.pack();
		frame.setVisible(true);

		// File listing in the dropdown based on the Requirement Document radio button
		// selection
		optionRequirementDoc.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (optionRequirementDoc.isSelected()) {
					// Get files from the RequirementDoc directory
					String directoryPath = StepDefinitionGeneratorConstants.REQUIREMENT_DOC_PATH;
					List<String> fileNames = getFileNames(directoryPath);
					fileDropdown.removeAllItems();
					for (String fileName : fileNames) {
						fileDropdown.addItem(fileName);
					}
				}
			}
		});

		// File listing in the dropdown based on the Feature radio button selection
		optionFeature.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (optionFeature.isSelected()) {
					// Get files from the Features directory
					String directoryPath = StepDefinitionGeneratorConstants.FEATURE_FILES_PATH;
					List<String> fileNames = getFileNames(directoryPath);
					fileDropdown.removeAllItems();
					for (String fileName : fileNames) {
						fileDropdown.addItem(fileName);
					}
				}
			}
		});

		// Generating the feature files and step definition files
		buttonGenerate.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				if (fileDropdown.getSelectedItem() == null) {
					JButton sourceButton = (JButton) e.getSource();
					JOptionPane.showMessageDialog(sourceButton, "Please select file type");
				} else {
					String featureFileTemplateName = fileDropdown.getSelectedItem().toString();

					String featureFilesPath = System.getProperty("user.dir")
							+ StepDefinitionGeneratorConstants.FEATURE_FILES_PATH;
					if (optionRequirementDoc.isSelected()) {
						String featureRequirementDocInputFile = System.getProperty("user.dir")
								+ StepDefinitionGeneratorConstants.REQUIREMENT_DOC_PATH + featureFileTemplateName;
						File featureRequirementDocFile = new File(featureRequirementDocInputFile);
						if (featureRequirementDocFile.exists()) {

							// Actual implementation to generate the feature files and step definitions
							List<String> fileLists = null;
							try {
								fileLists = new FeatureFileGeneratorCore()
										.generateFeatureFiles(featureRequirementDocInputFile);

								for (int i = 0; i < fileLists.size(); i++) {
									new StepDefinitionGeneratorCore()
											.generateStepDefinitions(fileLists.get(i) + ".feature");
								}
							} catch (IOException exce) {
								exce.printStackTrace();
							}

							JOptionPane.showMessageDialog((JButton) e.getSource(), "Feature files " + fileLists
									+ " and its step definitions are generated successfully");
						}
					} else {
						String featureInputFile = featureFilesPath + "/" + featureFileTemplateName;

						File featureFile = new File(featureInputFile);
						if (featureFile.exists()) {
							new StepDefinitionGeneratorCore().generateStepDefinitions(featureFileTemplateName.trim());

							JOptionPane.showMessageDialog((JButton) e.getSource(),
									"Step definitions for " + featureFileTemplateName + " are generated successfully");
						}
					}

					// Generate the BDD Test Runner class
					try {
						File featureFiles = new File(featureFilesPath);
						if (featureFiles.exists()) {
							File[] files = featureFiles.listFiles((dir, name) -> name.endsWith(".feature"));
							if (files.length > 0) {
								new TestRunnerGeneratorCore().generateBDDTestRunner();
							}
						}
					} catch (ParserConfigurationException ex) {
						ex.printStackTrace();
					} catch (IOException ex) {
						ex.printStackTrace();
					}
				}
			}
		});
	}

	// Entry point
	public static void main(String[] args) {
		generateFeatureFiles();
	}

	@Override
	public void actionPerformed(ActionEvent e) {

	}

	/**
	 * Method to get the lists of files from the given directory
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-12-2023
	 * @param directoryPath
	 * @return
	 */
	private static List<String> getFileNames(String directoryPath) {
		List<String> fileNames = new ArrayList<>();
		File directory = new File(System.getProperty("user.dir") + directoryPath);
		if (directory.exists() && directory.isDirectory()) {
			File[] files = directory.listFiles();
			if (files != null) {
				for (File file : files) {
					if (file.isFile()) {
						fileNames.add(file.getName());
					}
				}
			}
		} else {
			System.err.println("Directory does not exist: " + directoryPath);
		}
		return fileNames;
	}
}
