package com.autobots.stepdefgenerator;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

public class TestNGXMLGeneratorCore {

	/**
	 * Method to generate the testng.xml file to execute the step definitions
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-12-2023
	 * @param className
	 * @throws ParserConfigurationException
	 * @throws IOException
	 */
	public void generateTestNGXml(String className) throws ParserConfigurationException, IOException {

		String testNGFileName = "testng";
		File testNgXmlFile = new File(System.getProperty("user.dir"), testNGFileName + ".xml");
		if (!testNgXmlFile.exists()) {
			String xmlContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
					+ "<!DOCTYPE suite SYSTEM \"https://testng.org/testng-1.0.dtd\">\r\n" + "<suite name=\"Suite\">\r\n"
					+ "	<test thread-count=\"5\" name=\"Execution for BDD Test Suites\">\r\n" + "		<classes>\r\n"
					+ "			<class name=\"" + StepDefinitionGeneratorConstants.RUNNER_PACKAGE + "." + className + "\" />\r\n"
					+ "		</classes>\r\n" + "	</test> <!-- Test -->\r\n" + "</suite> <!-- Suite -->";

			try {
				FileWriter fileWriter = new FileWriter(testNGFileName + ".xml");
				fileWriter.write(xmlContent);
				fileWriter.close();
				System.out.println("testng.xml generated successfully!");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
