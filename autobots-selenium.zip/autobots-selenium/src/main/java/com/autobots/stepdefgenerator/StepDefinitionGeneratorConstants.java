package com.autobots.stepdefgenerator;

public class StepDefinitionGeneratorConstants {
	public static final String FEATURE_FILES_PATH = "./src/test/resources/BDDTesting/Features";
	public static final String REQUIREMENT_DOC_PATH = "./src/test/resources/BDDTesting/RequirementDoc/";
	public static final String RUNNER_PACKAGE = "com.autobots.runner";
	public static final String RUNNER_DIRECTORY = "/com/autobots/runner";
	public static final String RUNNER_CLASS_NAME = "BDDTestRunner";
	public static final String STEP_DEF_PACKAGE = "com.autobots.stepdefinitions";
	public static final String STEP_DEF_DIRECTORY = "/com/autobots/stepdefinitions";
}
