package com.autobots.utils;

public class AutomationConstants {
	// =========> Generic
	public static final String PROJECTNAME = "projectName";
	public static final String TEST_ENVIRONMENT = "testEnvironment";
	public static final String EXECUTION_ENVIRONMENT = "executionEnvironment";
	public static final String SCREENSHOT_ON_TEST_CASE_PASS = "screenshotOnTestCasePass";
	public static final String NEED_NETWORK_LOGS = "needNetworkLogs";
	public static final String RETRY_FAILURE_LIMIT = "RETRY_FAILURE_LIMIT";
	public static final String CAUSE = "Cause of the Exception : ";
	public static final String URLCHECK_LIST_FILE = "//Links_Verification_Results//";
	public static final String API_RESPONSE_DATA = "./src/test/resources/APITesting/ResponseData/";
	public static final String API_REQUEST_PAYLOAD = "./src/test/resources/APITesting/RequestPayload/";
	public static final String API_REQUEST_GRAPHQL = "./src/test/resources/APITesting/GraphQL/";
	public static final String API_JSON_SCHEMA = "./src/test/resources/APITesting/JSONSchema/";
	public static final String AUTOMATION_TEST_CONFIG_FILE_PATH = "./src/test/resources/automation_test_config.properties";
	public static final String FRAMEWORK_CONFIG_FILE_PATH = "./src/main/resources/framework_config.properties";
	public static final String UPDATE_TEST_STATUS_TO_EXCEL = "needTestResultPublishToExcelReport";

	// ==========> Configuration flags
	public static final String NEED_REALTIME_DASHBOARD_RESULTS = "needRealtimeDashboardResults";
	public static final String NEED_TIME_TRENDS_REPORT = "needTimeTrendsReport";

	// ==========> Configuration files
	public static final String FRAMEWORK_CONFIG = "framework_config";
	public static final String DB_CONFIG = "db_config";
	public static final String AUTOMATION_TEST_CONFIG = "automation_test_config";
	public static final String EMAIL_CONFIG = "email_config";
	public static final String LAMBDATEST_CONFIG = "lambdatest_config";
	public static final String LIVE_DASHBOARD = "live_dashboard";
	public static final String JIRA_CONFIG = "jira_config";
	public static final String TEST_RAIL_CONFIG = "testrail_config";

	// ===========> Exception Messages
	public static final String OBJECT_NOT_FOUND = "Unable to locate ";
	public static final String GRIDNODEIP_PORTMISSING = "Grid nodeIP or nodePort missing in testng.xml";
	public static final String GRID_BROWSER_MISSING = "Browser name missing in testng.xml";
	public static final String EXCEPTION_MESSAGE_FAILED_TO_GET_SCREEN = "Failed to get current screen";
	public static final String EXCEPTION_MESSAGE_INPUT_IMAGE_NOT_FOUND = "Specified expected image not found";
	public static final String EXCEPTION_MESSAGE_OUTPUT_IMAGE_NOT_FOUND = "Specified actual image not found";
	public static final String EXCEPTION_MESSAGE_FOR_LOAD_URL = "Cannot navigate to invalid web URL, please specify valid web URL";

	public static final String EXCEPTION_MESSAGE_EXCEL_FILE_PATH = "Specify test data Excel file path in automation_test_config.properties file";
	public static final String EXCEPTIION_EXCEL_SHEETNAME = "Can't read data from specified sheet, check sheet name";
	public static final String EXCEPTIION_EXCEL_COLUMN_NO = "Specify column index greater than zero";
	public static final String EXCEPTIION_EXCEL_ROW_NO = "Specify row index greater than zero";
	public static final String EXCEPTIION_EXCEL_COLUMN_NAME = "Excel column with given name not found, check the name";
	public static final String EXCEPTIION_EXCEL_PATH = "Give excel file path as argument";
	public static final String EXCEPTIION_EXCEL_FILE = "Please provide excel file with .xlsx or .xls format";
	public static final String CHECKBROWSER_MESSAGE = "Given browser is not configured in the automation framework";

	// ==================LambdaTest Details
	public static final String LAMBDATEST_CREDENTIALS = "LambdaTest credentials are missing.";
	public static final String LAMBDATEST_USERNAME = "lambdaTestUserName";
	public static final String LAMBDATEST_AUTHKEY = "lambdaTestAuthkey";
	public static final String LAMBDATEST_START_MSG = "Execution started in LambdaTest";
	public static final String NEED_LAMBDATEST_TUNNEL_CONNECT = "needLambdaConnect";
	public static final String LAMBDATEST_TUNNEL_IDENTIFIER = "lambdaTunnelIdentifier";

	// ==================AutoBots Dashboard Details
	public static final String INFLUX_DB_SERVER_IP = "influxdbServerIP";
	public static final String INFLUX_DB_PORT = "influxdbPort";
	public static final String INFLUX_DB_TOKEN = "influxdbToken";
	public static final String INFLUX_DB_BUCKET = "influxdbBucket";
	public static final String INFLUX_DB_ORGAIZATION_NAME = "influxdbOrganizationName";

	// ============== Defect Management Constants============================
	public static final String LOG_DEFECTS_TO_JIRA = "logDefectsToJira";
	public static final String JIRA_URL = "jiraURL";
	public static final String JIRA_USERNAME = "jiraUsername";
	public static final String JIRA_PASSWORD = "jiraPassword";
	public static final String JIRA_PROJECTID = "jiraProjectID";
	public static final String JIRA_AUTHENTICATION_DETAILS_MISSING_MESSAGE = "You are not provided JIRA URL, credentials or Project ID to connect to JIRA in the jira_config.properties";
	public static final String JIRA_ERROR_LOGS = "//JIRA_Defect_Details//Error_Logs//";
	public static final String JIRA_DEFECT_SCREENSHOTS = "/JIRA_Defect_Details/Defect_Screenshots/";

	// ============== TestRail Constants============================
	public static String TEST_CASE_PASS_STATUS = "1";
	public static String TEST_CASE_FAIL_STATUS = "5";
}
