package com.autobots.utils;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.autobots.exception.AutomationException;
import com.autobots.keywords.DataHandler;
import com.autobots.reporting.AutomationReport;

import io.qameta.allure.Allure;

public class Log {

	private static final ThreadLocal<Logger> threadLogger = ThreadLocal.withInitial(() -> LogManager.getLogger());

	/**
	 * 
	 * 
	 * @author aiswarya.thandassery
	 * @since 20-05-2024
	 * @return
	 */
	private static Logger getLogger() {
		return threadLogger.get();
	}

	/**
	 * Method for trace level
	 * 
	 * @author aiswarya.thandassery
	 * @since 20-05-2024
	 * @param description
	 */
	public static void trace(String description) {
		getLogger().log(Level.TRACE, description);
	}

	/**
	 * Method for event level
	 * 
	 * @author aiswarya.thandassery
	 * @since 20-05-2024
	 * @param description
	 */
	public static void event(String description) {
		getLogger().log(Level.DEBUG, description);
	}

	/**
	 * 
	 * Method for message level. Mostly used to print something in the console and
	 * in the report.
	 * 
	 * @author aiswarya.thandassery
	 * @since 20-05-2024
	 * @param description
	 */
	public static void message(String description) throws AutomationException {
		new AutomationReport().trackSteps(description);
		getLogger().log(Level.INFO, description);
		addToAllureReport(description);
	}

	/**
	 * 
	 * Method for message level. Mostly used to print something in the console and
	 * in the report.
	 * 
	 * 
	 * @author aiswarya.thandassery
	 * @since 24-05-2024
	 * @param driver
	 * @param description
	 */
	public static void message(WebDriver driver, String description) throws AutomationException {
		new AutomationReport().trackSteps(driver, description);
		getLogger().log(Level.INFO, description);
		addToAllureReport(description);
	}

	/**
	 * 
	 * Method for information level. Mostly used to print something in the console.
	 * 
	 * @author aiswarya.thandassery
	 * @since 20-05-2024
	 * @param description
	 */
	public static void info(String description) throws AutomationException {
		getLogger().log(Level.INFO, description);
		addToAllureReport(description);
	}

	/**
	 * 
	 * Method for warning level
	 * 
	 * @author aiswarya.thandassery
	 * @since 20-05-2024
	 * @param description
	 */
	public static void warning(String description) {
		getLogger().log(Level.WARN, description);
	}

	/**
	 * 
	 * Method for error level
	 * 
	 * @author aiswarya.thandassery
	 * @since 20-05-2024
	 * @param description
	 */
	public static void fail(String description) throws AutomationException {
		getLogger().log(Level.ERROR, description);
		addToAllureReport(description);
	}

	/**
	 * 
	 * Method for error level with driver
	 * 
	 * @author aiswarya.thandassery
	 * @since 20-05-2024
	 * @param driver
	 * @param description
	 */
	public static void fail(WebDriver driver, String description) throws AutomationException {
		new AutomationReport().trackSteps(driver, description);
		getLogger().log(Level.ERROR, description);
		addToAllureReport(description);
	}

	/**
	 * 
	 * Method for exception level
	 * 
	 * @author aiswarya.thandassery
	 * @since 20-05-2024
	 * @param e
	 */
	public static void exception(Exception e) throws AutomationException {
		String eMessage = e.getMessage();
		if (eMessage != null && eMessage.contains("\n")) {
			eMessage = eMessage.substring(0, eMessage.indexOf("\n"));
		}
		addToAllureReport(eMessage);
		getLogger().log(Level.FATAL, eMessage, e);
		throw new AutomationException(eMessage, e);
	}

	/**
	 * Method to add to allure report
	 * 
	 * @author sanoj.swaminathan
	 * @since 24-05-2024
	 * @param description
	 * @throws AutomationException
	 */
	private static void addToAllureReport(String description) throws AutomationException {
		try {
			String needAllureReport = new DataHandler().getProperty(AutomationConstants.FRAMEWORK_CONFIG,
					"needAllureReport");
			if (needAllureReport.toLowerCase().equalsIgnoreCase("yes")) {
				Allure.step(description);
			}
		} catch (AutomationException e) {
			exception(e);
		}
	}
}
