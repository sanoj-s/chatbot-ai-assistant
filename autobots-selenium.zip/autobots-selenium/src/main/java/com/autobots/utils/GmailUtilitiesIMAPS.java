package com.autobots.utils;

import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.FetchProfile;
import javax.mail.Flags;
import javax.mail.Flags.Flag;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.MimeMultipart;
import javax.mail.search.FlagTerm;

public class GmailUtilitiesIMAPS {
	Folder inbox;

	/**
	 * To get last mail content from Gmail Account using IMAPS.
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-05-2021
	 * @param emailAddress
	 * @param password
	 * @return
	 */
	public String getMessage(final String emailAddress, final String password) {
		String finalmessagedata = null;
		/* Set the mail properties */
		Properties props = System.getProperties();
		props.setProperty("mail.store.protocol", "imaps");
		try {
			/* Create the session and get the store for read the mail. */
			Session session = Session.getDefaultInstance(props, null);
			Store store = session.getStore("imaps");
			store.connect("imap.gmail.com", emailAddress, password);

			/* Mention the folder name which you want to read. */
			inbox = store.getFolder("Inbox");
			// System.out.println("No of Unread Messages : " +
			// inbox.getUnreadMessageCount());

			/* Open the inbox using store. */
			inbox.open(Folder.READ_ONLY);

			/* Get the messages which is unread in the Inbox */
			Message messages[] = inbox.search(new FlagTerm(new Flags(Flag.USER), true));

			/* Use a suitable FetchProfile */
			FetchProfile fp = new FetchProfile();
			fp.add(FetchProfile.Item.ENVELOPE);
			fp.add(FetchProfile.Item.CONTENT_INFO);
			inbox.fetch(messages, fp);
			try {
				finalmessagedata = printEnvelope(messages[messages.length - 1]);

				inbox.close(true);
				store.close();
			} catch (Exception ex) {
				System.out.println("Exception arise at the time of read mail");
				ex.printStackTrace();
			}
		} catch (NoSuchProviderException e) {
			e.printStackTrace();
			System.exit(1);
		} catch (MessagingException e) {
			e.printStackTrace();
			System.exit(2);
		}
		return finalmessagedata;

	}

	/**
	 * Method to get all mail content from Gmail Account using IMAPS.
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-05-2021
	 * @param user
	 * @param password
	 * @return
	 */
	public String getMessages(final String username, final String password) {
		String finalmessagedata = null;
		/* Set the mail properties */
		Properties props = System.getProperties();
		props.setProperty("mail.store.protocol", "imaps");
		try {
			/* Create the session and get the store for read the mail. */
			Session session = Session.getDefaultInstance(props, null);
			Store store = session.getStore("imaps");
			store.connect("imap.gmail.com", username, password);

			/* Mention the folder name which you want to read. */
			inbox = store.getFolder("Inbox");
			// System.out.println("No of Unread Messages : " +
			// inbox.getUnreadMessageCount());

			/* Open the inbox using store. */
			inbox.open(Folder.READ_ONLY);

			/* Get the messages which is unread in the Inbox */
			Message messages[] = inbox.search(new FlagTerm(new Flags(Flag.USER), true));

			/* Use a suitable FetchProfile */
			FetchProfile fp = new FetchProfile();
			fp.add(FetchProfile.Item.ENVELOPE);
			fp.add(FetchProfile.Item.CONTENT_INFO);
			inbox.fetch(messages, fp);
			try {
				finalmessagedata = printAllMessages(messages);
				inbox.close(true);
				store.close();
			} catch (Exception ex) {
				System.out.println("Exception arise at the time of read mail");
				ex.printStackTrace();
			}
		} catch (NoSuchProviderException e) {
			e.printStackTrace();
			System.exit(1);
		} catch (MessagingException e) {
			e.printStackTrace();
			System.exit(2);
		}
		return finalmessagedata;

	}

	/**
	 * To get the mail subject of latest mail from Gmail account
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-05-2021
	 * @param emailAddress
	 * @param password
	 * @return
	 */
	public String getSubject(final String emailAddress, final String password) {
		String mailSubject = null;
		Message message = null;
		/* Set the mail properties */
		Properties props = System.getProperties();
		props.setProperty("mail.store.protocol", "imaps");
		try {
			/* Create the session and get the store for read the mail. */
			Session session = Session.getDefaultInstance(props, null);
			Store store = session.getStore("imaps");
			store.connect("imap.gmail.com", emailAddress, password);

			/* Mention the folder name which you want to read. */
			inbox = store.getFolder("Inbox");
			// System.out.println("No of Unread Messages : " +
			// inbox.getUnreadMessageCount());

			/* Open the inbox using store. */
			inbox.open(Folder.READ_ONLY);

			/* Get the messages which is unread in the Inbox */
			Message messages[] = inbox.search(new FlagTerm(new Flags(Flag.USER), true));

			/* Use a suitable FetchProfile */
			FetchProfile fp = new FetchProfile();
			fp.add(FetchProfile.Item.ENVELOPE);
			fp.add(FetchProfile.Item.CONTENT_INFO);
			inbox.fetch(messages, fp);
			message = messages[messages.length - 1];
			mailSubject = message.getSubject();
		} catch (NoSuchProviderException e) {
			e.printStackTrace();
			System.exit(1);
		} catch (MessagingException e) {
			e.printStackTrace();
			System.exit(2);
		}
		return mailSubject;
	}

	/**
	 * Method to print all messages
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-05-2021
	 * @param msgs
	 * @return
	 * @throws Exception
	 */
	private String printAllMessages(Message[] msgs) throws Exception {
		String messagedate = null;
		for (int i = msgs.length - 1; i >= 0; i--) {
			System.out.println("MESSAGE #" + (i + 1) + ":");
			messagedate = printEnvelope(msgs[i]);
		}
		return messagedate;
	}

	/**
	 * Method to print all message contents
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-05-2021
	 * @param message
	 * @return
	 * @throws Exception
	 */
	/* Print the envelope(FromAddress,ReceivedDate,Subject) */
	private String printEnvelope(Message message) throws Exception {
		Object content = message.getContent();
		String finalmesage = null;
		if (content instanceof String) {
			String body = (String) content;
			finalmesage = body.replaceAll("\\<.*?>", "");
			// System.out.println(finalmesage);

		} else if (content instanceof MimeMultipart) {
			MimeMultipart mp = (MimeMultipart) content;
			finalmesage = getTextFromMimeMultipart(mp);
			// System.out.println(finalmesage);
		}
		return finalmesage;
	}

	/**
	 * Method to get text from Mime Multipart
	 * 
	 * @author sanoj.swaminathan
	 * @since 08-05-2021
	 * @param mimeMultipart
	 * @return
	 * @throws Exception
	 */
	public String getTextFromMimeMultipart(MimeMultipart mimeMultipart) throws Exception {
		String result = "";
		int count = mimeMultipart.getCount();
		for (int i = 0; i < count; i++) {
			BodyPart bodyPart = mimeMultipart.getBodyPart(i);
			if (bodyPart.isMimeType("text/plain")) {
				result = result + "\n" + bodyPart.getContent();
				break; // without break same text appears twice in my tests
			} else if (bodyPart.isMimeType("text/html")) {
				String html = (String) bodyPart.getContent();
				result = result + "\n" + org.jsoup.Jsoup.parse(html).text();
			} else if (bodyPart.getContent() instanceof MimeMultipart) {
				result = result + getTextFromMimeMultipart((MimeMultipart) bodyPart.getContent());
			}
		}
		return result;
	}
}
