package com.autobots.utils;

import com.autobots.exception.AutomationException;
import com.autobots.keywords.DataHandler;
import com.influxdb.client.InfluxDBClient;
import com.influxdb.client.InfluxDBClientFactory;
import com.influxdb.client.WriteApiBlocking;
import com.influxdb.client.write.Point;

public class LiveDashboardConnector {

	static String influxdbServerIP, influxdbPort, influxdb_token, influxdb_bucket, influxdb_org;
	static InfluxDBClient client;

	/**
	 * Publish test result details to the dashboard
	 * 
	 * @author sanoj.swaminathan
	 * @since 11-07-2023
	 * @param dataPoints
	 * @throws AutomationException
	 */
	public static void publishResults(final Point dataPoints) throws AutomationException {
		influxdbServerIP = new DataHandler().getProperty(AutomationConstants.LIVE_DASHBOARD,
				AutomationConstants.INFLUX_DB_SERVER_IP);
		influxdbPort = new DataHandler().getProperty(AutomationConstants.LIVE_DASHBOARD,
				AutomationConstants.INFLUX_DB_PORT);
		influxdb_token = new DataHandler().getProperty(AutomationConstants.LIVE_DASHBOARD,
				AutomationConstants.INFLUX_DB_TOKEN);
		influxdb_bucket = new DataHandler().getProperty(AutomationConstants.LIVE_DASHBOARD,
				AutomationConstants.INFLUX_DB_BUCKET);
		influxdb_org = new DataHandler().getProperty(AutomationConstants.LIVE_DASHBOARD,
				AutomationConstants.INFLUX_DB_ORGAIZATION_NAME);
		client = InfluxDBClientFactory.create("http://" + influxdbServerIP + ":" + influxdbPort + "",
				influxdb_token.toCharArray());

		WriteApiBlocking writeApi = client.getWriteApiBlocking();
		writeApi.writePoint(influxdb_bucket, influxdb_org, dataPoints);
	}
}
