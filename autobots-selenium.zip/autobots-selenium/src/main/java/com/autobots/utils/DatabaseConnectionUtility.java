package com.autobots.utils;

import com.autobots.base.AutomationBase;
import com.autobots.exception.AutomationException;
import com.autobots.keywords.DataHandler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DatabaseConnectionUtility {
	public String className, dbUrl, dbUsername, dbPassword;
	public Statement stmt = null;
	public Connection con = null;

	AutomationBase baseObj = new AutomationBase();
	DataHandler propertyObject = new DataHandler();

	public DatabaseConnectionUtility() throws AutomationException {
		String databaseSystem = propertyObject.getProperty(AutomationConstants.DB_CONFIG, "databaseSystem");
		if (databaseSystem.equalsIgnoreCase("MySql")) {
			className = "com.mysql.cj.jdbc.Driver";
		} else {
			className = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		}
	}

	/**
	 * Method to create the connection statement
	 * 
	 * @author sanoj.swaminathan
	 * @since 02-03-2023
	 * @return
	 * @throws AutomationException
	 */
	public Statement createConnectionStatement() throws AutomationException {
		try {
			Class.forName(className);
			dbUrl = propertyObject.getProperty(AutomationConstants.DB_CONFIG, "dbUrl");
			dbUsername = propertyObject.getProperty(AutomationConstants.DB_CONFIG, "dbUsername");
			dbPassword = propertyObject.getProperty(AutomationConstants.DB_CONFIG, "dbPassword");
			Log.message("Connecting to the database");
			con = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
			Log.message("Connected database is: " + con.getCatalog());
			Log.message("Creating statement object");
			stmt = con.createStatement();
			Log.message("Created the statement object");
		} catch (Exception e) {
			Log.exception(e);
		}
		return stmt;
	}
}
