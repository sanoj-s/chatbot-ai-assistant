package com.autobots.defectmanagement;

import java.io.File;

import javax.naming.AuthenticationException;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;

import com.autobots.base.AutomationBase;
import com.autobots.exception.AutomationException;
import com.autobots.keywords.DataHandler;
import com.autobots.keywords.Utilities;
import com.autobots.utils.AutomationConstants;

import net.rcarz.jiraclient.BasicCredentials;
import net.rcarz.jiraclient.Issue;
import net.rcarz.jiraclient.JiraClient;

public class JiraDefectManagement {
	/**
	 * This method is used to log defects to JIRA and will attach the error log file
	 * and captured screen shot to the defect logged
	 * 
	 * @author sanoj.swaminathan
	 * @since 01-02-2024
	 * @param result
	 * @throws AuthenticationException
	 * @throws AutomationException
	 */

	public void logDefectToJira(ITestResult result) throws AutomationException {
		String jiraURL = "";
		String jiraUserName = "";
		String jiraPassWord = "";
		String jiraProjectID = "";
		RestAPIClient jrc = null;
		try {
			jiraURL = new DataHandler().getProperty(AutomationConstants.JIRA_CONFIG, AutomationConstants.JIRA_URL);
			jiraUserName = new DataHandler().getProperty(AutomationConstants.JIRA_CONFIG,
					AutomationConstants.JIRA_USERNAME);
			jiraPassWord = new DataHandler().getProperty(AutomationConstants.JIRA_CONFIG,
					AutomationConstants.JIRA_PASSWORD);
			jiraProjectID = new DataHandler().getProperty(AutomationConstants.JIRA_CONFIG,
					AutomationConstants.JIRA_PROJECTID);
		} catch (Exception lException) {
			lException = new Exception(AutomationConstants.JIRA_AUTHENTICATION_DETAILS_MISSING_MESSAGE);
			throw new AutomationException(lException);
		}
		try {
			if ((jiraURL != null || jiraURL == "") && (jiraUserName != null || jiraUserName == "")
					&& (jiraPassWord != null || jiraPassWord == "") && (jiraProjectID != null || jiraProjectID == "")) {
				System.out.println("Test '" + result.getName() + "' FAILED");
				jrc = new RestAPIClient(jiraURL, jiraUserName, jiraPassWord);

				// creating error log file for failed case
				jrc.createErrorLog(result);
				// Capture screen shot
				Object currentClass = result.getInstance();
				WebDriver driver = ((AutomationBase) currentClass).getDriver();

				// Capture screenshot
				new File(new File(System.getProperty("user.dir")), AutomationConstants.JIRA_DEFECT_SCREENSHOTS)
						.mkdirs();
				String filePath = System.getProperty("user.dir") + AutomationConstants.JIRA_DEFECT_SCREENSHOTS;
				String screenshotFile = new Utilities().captureScreenshot(driver, filePath, result.getName());

				Throwable throwable = result.getThrowable();
				String bug_title;
				if (throwable.getCause() != null) {
					if (throwable.getCause().toString().length() >= 25) {
						bug_title = result.getName() + " : " + throwable.getCause().toString();
					} else {
						bug_title = result.getName() + " : " + throwable.getCause().getMessage().toString();
					}
				} else {
					bug_title = result.getName() + " : " + throwable.toString();
				}

				String bug_description = throwable.toString() + "."
						+ "\n\nPlease see the attached error logs to know more details...";

				String testCaseName = result.getMethod().getMethodName().toString();
				String actualdefect;
				if (bug_title.length() >= 145) {
					actualdefect = throwable.toString().substring(0, 143);
				} else {
					String actualBug = throwable.toString();
					actualdefect = actualBug.split(":")[1].trim();
				}
				String defectSummary = "[BUG] - " + testCaseName + " : " + actualdefect;
				BasicCredentials creds = new BasicCredentials(jiraUserName, jiraPassWord);
				JiraClient jira = new JiraClient(jiraURL, creds);
				try {
					Issue issue = null;
					for (int i = 1; i <= 700; i++) {
						issue = jira.getIssue(jiraProjectID + "-" + i);
						if (issue.getSummary().toString().equals(defectSummary)) {
							System.out.println("Issue: " + "'" + defectSummary + "'" + " is already logged into JIRA");
							break;
						}
					}
				} catch (Exception e) {
					jrc.createIssueInJira(jiraProjectID, "Bug", defectSummary, jiraUserName, bug_description, result,
							screenshotFile);
				}
			}
		} catch (Exception lException) {
			throw new AutomationException(lException);
		}
	}
}