package com.autobots.defectmanagement;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.naming.AuthenticationException;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.ITestResult;

import com.autobots.utils.AutomationConstants;
import com.autobots.utils.TestCaseConfig;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class RestAPIClient {
	private final String host;
	private final String authHeader;

	/**
	 * @param host     The server's URL.
	 * @param username User for logging in.
	 * @param password Password for logging in.
	 */
	public RestAPIClient(String host, String username, String password) throws AuthenticationException {
		this.authHeader = getAuth(username, password);
		if (host.endsWith("/")) {
			this.host = host.substring(0, host.length() - 1);
		} else {
			this.host = host;
		}
	}

	/**
	 * Method to get authentication
	 * 
	 * @author sanoj.swaminathan
	 * @since 01-02-2024
	 * @param username
	 * @param password
	 * @return
	 */
	private static String getAuth(String username, String password) {
		try {
			String s = username + ":" + password;
			byte[] byteArray = s.getBytes();
			String auth;
			auth = Base64.encodeBase64String(byteArray);
			return auth;
		} catch (Exception ignore) {
			return "";
		}
	}

	/**
	 * This method is to create an issue in Jira
	 * 
	 * @author sanoj.swaminathan
	 * @since 01-02-2024
	 * @param projectid      The ID of the project.
	 * @param issuetype      The Name if the IssueType.
	 * @param summary        The Summary of the new issue.
	 * @param description    The body of the new issue.
	 * @param screenshotFile
	 * @param defectTitle
	 * @param reporterName
	 * @param testresult
	 * @return JSON serialized message.
	 * @throws Exception
	 */
	public String createIssueInJira(String projectid, String issuetype, String defectTitle, String reporterName,
			String description, ITestResult testresult, String screenshotFile) throws Exception {
		JSONObject fields = new JSONObject();
		fields.put("project", new JSONObject().put("key", projectid));
		fields.put("issuetype", new JSONObject().put("name", issuetype));
		fields.put("summary", defectTitle);
		fields.put("description", description);
		JSONObject issue = new JSONObject();
		issue.put("fields", fields);
		JSONObject result = doREST("POST", "/rest/api/2/issue", issue.toString());
		String issueKey = getLoggedIssueKey(result);
		attachErrorLogAndScreenShotToDefect(issueKey, testresult.getName(), screenshotFile);
		System.out.println("==========================================================");
		System.out.println("SUCCESSFULLY LOGGED A DEFECT TO JIRA FOR FAILED CASE");
		System.out.println("=========================================================");
		System.out.println("Project ID: " + projectid);
		System.out.println("Bug ID: " + issueKey);
		TestCaseConfig testCasePolicy = testresult.getMethod().getConstructorOrMethod().getMethod()
				.getAnnotation(TestCaseConfig.class);
		if (testCasePolicy != null) {
			int testCaseIDValue = testCasePolicy.testRailTestCaseID ();
			System.out.println("Failed Test Case ID: " + testCaseIDValue);
		}
		return result.toString();
	}

	/**
	 * This method is to attach error log file and screen shot captured in the
	 * logged defect
	 * 
	 * @author sanoj.swaminathan
	 * @since 01-02-2024
	 * @param issueKey
	 * @param fileName
	 * @param screenshotFile
	 * @throws Exception
	 */
	public void attachErrorLogAndScreenShotToDefect(String issueKey, String fileName, String screenshotFile)
			throws Exception {
		String filePath = System.getProperty("user.dir") + AutomationConstants.JIRA_ERROR_LOGS;
		doRESTForFileUpload(issueKey, filePath + fileName + ".txt");
		doRESTForFileUpload(issueKey, screenshotFile);
	}

	/**
	 * This method is used to get logged issue key
	 * 
	 * @author sanoj.swaminathan
	 * @since 01-02-2024
	 * @param result
	 * @return key
	 * @throws JSONException
	 */
	private String getLoggedIssueKey(JSONObject result) throws JSONException {

		Object obj = result;
		JSONObject jsonObject = (JSONObject) obj;
		String key = (String) jsonObject.get("key");
		return key;
	}

	/**
	 * This method is used to get logged issue link
	 * 
	 * @author sanoj.swaminathan
	 * @since 01-02-2024
	 * @param result
	 * @return key
	 * @throws JSONException
	 */
	public String getLoggedIssueLink(JSONObject result) throws JSONException {

		Object obj = result;
		JSONObject jsonObject = (JSONObject) obj;
		String link = (String) jsonObject.get("self");
		return link;
	}

	/**
	 * This method is used to get logged issue details
	 * 
	 * @author sanoj.swaminathan
	 * @since 01-02-2024
	 * @param issuekey
	 * @return response
	 * @throws Exception
	 */
	public String getIssueDetails(String issuekey) throws Exception {
		JSONObject result = doREST("GET", "/rest/api/2/issue", issuekey + "?*all,-comment");
		return result.toString();
	}

	/**
	 * This method is used to create an error log file
	 * 
	 * @author sanoj.swaminathan
	 * @since 01-02-2024
	 * @param result
	 */
	public void createErrorLog(ITestResult result) {
		try {
			new File(new File(System.getProperty("user.dir")), AutomationConstants.JIRA_ERROR_LOGS).mkdirs();
			String filePath = System.getProperty("user.dir") + AutomationConstants.JIRA_ERROR_LOGS;
			File file = new File(filePath + result.getName() + ".txt");
			// if file doesn't exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			Throwable throwable = result.getThrowable();
			if (throwable != null) {
				StringBuffer exceptions = new StringBuffer();
				exceptions.append("Failed Class Name : " + result.getTestClass().getName() + "\n\n");
				exceptions.append("Failed Method Name : " + result.getMethod().getMethodName() + "\n\n");
				if (throwable.getCause() != null) {
					if (throwable.getCause().toString().length() >= 25) {
						exceptions.append("Failure log details : " + " \n\n" + throwable.getCause() + " \n\n");
					} else {
						exceptions.append("" + throwable.getCause().getMessage() + "\n\n");
					}
				} else
					exceptions.append("" + throwable + " \n\n");
				fw.write(exceptions.toString());
				fw.close();

			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	/**
	 * This method is used to upload file to JIRA server
	 * 
	 * @author sanoj.swaminathan
	 * @since 01-02-2024
	 * @param issueKey
	 * @param path
	 * @return
	 */
	private boolean doRESTForFileUpload(String issueKey, String path) {
		HttpClient httpclient = HttpClientBuilder.create().build();
		HttpPost httppost = new HttpPost(this.host + "/rest/api/2/issue/" + issueKey + "/attachments");
		httppost.setHeader("X-Atlassian-Token", "nocheck");
		httppost.setHeader("Authorization", "Basic " + this.authHeader);
		MultipartEntityBuilder builder = MultipartEntityBuilder.create();
		builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
		FileBody fileBody = new FileBody(new File(path), ContentType.APPLICATION_OCTET_STREAM);
		builder.addPart("file", fileBody);
		httppost.setEntity(builder.build());
		HttpResponse response = null;
		try {
			response = httpclient.execute(httppost);
		} catch (ClientProtocolException e) {
			return false;
		} catch (IOException e) {
			return false;
		}
		HttpEntity result = response.getEntity();
		System.out.println(result.toString());
		if (response.getStatusLine().getStatusCode() == 200)
			return true;
		else
			return false;
	}

	/**
	 * This method is used do rest action
	 * 
	 * @author sanoj.swaminathan
	 * @since 01-02-2024
	 * @param method  The HTTP method defines if we want to fetch (GET), modify
	 *                (PUT), add (POST), or remove (DELETE) entites.
	 * @param context The Resource you want to access.
	 * @param arg     The Parameter(s) assembled to simply send it.
	 * @return A JSON object depicting the results, OR an exception detailing the
	 *         problem.
	 * @throws Exception
	 */
	private JSONObject doREST(String method, String context, String arg) throws Exception {
		try {
			Client client = Client.create();
			if (!context.endsWith("/")) {
				context = context.concat("/");
			}
			WebResource webResource;
			if ("GET".equalsIgnoreCase(method)) {
				webResource = client.resource(this.host + context + arg);
			} else {
				webResource = client.resource(this.host + context);
			}
			WebResource.Builder builder = webResource.header("Authorization", "Basic " + this.authHeader)
					.type("application/json").accept("application/json");
			ClientResponse response;
			if ("GET".equalsIgnoreCase(method)) {
				response = builder.get(ClientResponse.class);
			} else if ("POST".equalsIgnoreCase(method)) {
				response = builder.post(ClientResponse.class, arg);
			} else {
				response = builder.method(method, ClientResponse.class);
			}
			if (response.getStatus() == 401) {
				throw new AuthenticationException("HTTP 401 received: Invalid Username or Password.");
			}
			String jsonResponse = response.getEntity(String.class);
			JSONObject responseJson = new JSONObject(jsonResponse);
			return responseJson;
		} catch (JSONException ex) {
			throw new Exception("JSON deserializing failed.", ex);
		} catch (AuthenticationException ex) {
			throw new Exception("Login failed.", ex);
		}
	}
}
