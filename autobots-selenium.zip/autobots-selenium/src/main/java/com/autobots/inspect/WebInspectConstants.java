package com.autobots.inspect;

public class WebInspectConstants {
	public static final String WEB_INSPECT_TEMPLATE_PATH = "src/main/resources/Web_Inspect_Template/Template.xlsx";
	public static final String WEB_INSPECT_REPOSITORIES_PATH = "src/test/resources/Repositories/";
	public static final String OBJECT_PACKAGE = "com.autobots.testobjects";
	public static final String OBJECT_PACKAGE_DIRECTORY = "/com/autobots/testobjects";
}
